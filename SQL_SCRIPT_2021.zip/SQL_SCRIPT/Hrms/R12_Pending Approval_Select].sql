SELECT   *
                       FROM   hr_api_transaction_steps
                      WHERE   transaction_id IN
                                    (SELECT   transaction_id
                                       FROM   hr_api_transactions
                                      WHERE   creator_person_id =
                                                 (SELECT   DISTINCT person_id
                                                    FROM   per_all_people_f
                                                   WHERE   employee_number =
                                                              :emp_num)
                                              AND item_key = :item_key);
                                              
                                              
                                              
DELETE FROM   hr_api_transactions
      WHERE   creator_person_id = (SELECT   DISTINCT person_id
                                     FROM   per_all_people_f
                                    WHERE   employee_number = :emp_num)
              AND item_key = :item_key;

DELETE FROM   hr_api_transaction_steps
      WHERE   transaction_id IN
                    (SELECT   transaction_id
                       FROM   hr_api_transactions
                      WHERE   creator_person_id =
                                 (SELECT   DISTINCT person_id
                                    FROM   per_all_people_f
                                   WHERE   employee_number = :emp_num)
                              AND item_key = :item_key);

DELETE FROM   hr_api_transaction_values
      WHERE   transaction_step_id IN
                                                                  