SELECT   LPAD ('|-', (LEVEL - 1) * 2)
             || (SELECT   DISTINCT full_name || ' - ' || employee_number
                   FROM   per_all_people_f papf
                  WHERE   papf.person_id = paf.person_id
                          AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                                  AND  papf.effective_end_date
                          AND current_employee_flag = 'Y')
                name
      FROM   per_all_assignments_f paf
START WITH       paf.person_id = (SELECT   DISTINCT person_id
                                  FROM   per_all_people_f
                                  WHERE   employee_number =
                                  LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0'))
             AND paf.primary_flag = 'Y'
             AND paf.assignment_type = 'E'
             AND SYSDATE BETWEEN paf.effective_start_date
                             AND  paf.effective_end_date
             AND assignment_status_type_id = 1
CONNECT BY       PRIOR paf.supervisor_id = paf.person_id
             AND paf.primary_flag = 'Y'
             AND paf.assignment_type = 'E'
             AND SYSDATE BETWEEN paf.effective_start_date
                             AND  paf.effective_end_date
             AND assignment_status_type_id = 1;

SELECT /*paf.person_id, paf.supervisor_id
, LPAD (' ',  (LEVEL - 1) * 2 )
--|| SYS_CONNECT_BY_PATH (paf.person_id, '/') PATH
|| SYS_CONNECT_BY_PATH (
 (select distinct full_name from per_all_people_f papf where papf.person_id = paf.person_id
AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                          AND papf.effective_end_date
                  AND current_employee_flag = 'Y' ), '->') PATH,*/
LPAD ('  ',  (LEVEL - 1) * 2 )||(select distinct full_name||' - '||employee_number from per_all_people_f papf where papf.person_id = paf.person_id
AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                          AND papf.effective_end_date
                  AND current_employee_flag = 'Y' ) name/*                   
, LEVEL, paf.job_id -- used for linking to hr.per_jobs ,
, paf.effective_start_date, paf.effective_end_date, (select distinct full_name from per_all_people_f papf where papf.person_id = paf.person_id
AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                          AND papf.effective_end_date
                  AND current_employee_flag = 'Y' ) name*/
FROM per_all_assignments_f paf
START WITH paf.person_id = :person_id
AND paf.primary_flag = 'Y'
AND paf.assignment_type = 'E'
AND SYSDATE BETWEEN paf.effective_start_date AND paf.effective_end_date
AND assignment_status_type_id = 1
CONNECT BY PRIOR paf.person_id = paf.supervisor_id
AND paf.primary_flag = 'Y'
AND paf.assignment_type = 'E'
AND SYSDATE BETWEEN paf.effective_start_date AND paf.effective_end_date
AND assignment_status_type_id = 1;

select 
  lpad(' ', (level - 1) * 2) || name as padded_name, 
  slave_id, 
  supervisor_id, 
  level
from corporate_slaves
connect by prior slave_id = supervisor_id
start with slave_id = 1;
