WHENEVER SQLERROR CONTINUE;
/*===========================================================================*
 |                  Copyright (c) 1997 Oracle Corporation                    |
 |                          All rights reserved.                             |
*============================================================================*/
rem $Header: hrahkone.sql 115.0 99/07/17 16:31:21 porting ship $
rem
rem File Name
rem =========
rem hrahkone.sql
rem
rem File Information
rem ================
rem This script creates the hook package body source code for one API
rem module. The SQL*Plus user will need to enter the API_MODULE_ID. This
rem script should be executed in the database account which contains the
rem application package code.
rem
rem It should be executed after the core package headers, package bodies and
rem seed data has been installed. It can be executed by the customer after
rem they have created their specific hook definitions and loaded their extra
rem package logic into the database.
rem
rem Another script (hrahkall.sql) can be used to create all the hook package
rem body source code for all API modules.
rem
rem --------------------------------------------------------------------------
rem
rem Change List
rem ===========
rem
rem Version Date        Author         Comment
rem -------+-----------+--------------+---------------------------------------
rem 70.0    08-APR-1997 P.K.Attwood    Date Created
rem ==========================================================================
rem

declare
  l_api_module_id  number;
begin
  l_api_module_id := &API_MODULE_ID;
  --
  -- Create all hook package body source code for one API module
  --
  hr_api_user_hooks_utility.create_hooks_one_module(l_api_module_id);
  --
  -- Build the report text
  --
  hr_api_user_hooks_utility.write_one_errors_report(l_api_module_id);
end;
/

rem Output the report text
set heading off
set feedback off
select text
  from hr_api_user_hook_reports
 where session_id = userenv('SESSIONID')
 order by line;
 
rem Clear data from report table
execute hr_api_user_hooks_utility.clear_hook_report;
 
--exit;

 
 
 

