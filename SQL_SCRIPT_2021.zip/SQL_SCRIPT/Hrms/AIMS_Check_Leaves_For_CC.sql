SELECT   qael.crcode, vvcc.cc, vvcc.ccdesc, COUNT (1)
    FROM qr_aims_erp_leave qael, qtr.vvcrewcodes vvcc
   WHERE qael.ID = :emp_no
     AND TO_DATE ('01-01-1980', 'dd-mm-rrrr') + qael.DAY BETWEEN :startdt
                                                             AND :enddt
     AND vvcc.ID(+) = qael.crcode
GROUP BY qael.crcode, vvcc.cc, vvcc.ccdesc;


SELECT   qael.id, qael.crcode, vvcc.cc, vvcc.ccdesc,TO_DATE ('01-01-1980', 'dd-mm-rrrr') + qael.DAY Leave_Date 
    FROM qr_aims_erp_leave qael, qtr.vvcrewcodes vvcc
   WHERE qael.ID = :emp_no
     AND TO_DATE ('01-01-1980', 'dd-mm-rrrr') + qael.DAY BETWEEN :startdt
                                                             AND :enddt
     AND vvcc.ID(+) = qael.crcode
     
     
     qr_crew_leave_det