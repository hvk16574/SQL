SELECT *
  FROM qtr.vvcrewcodes
 WHERE cc IN ('NOAV', 'NCTC', 'ELVE', 'UPLV', 'LLVE', 'OFLD', 'NOSW')