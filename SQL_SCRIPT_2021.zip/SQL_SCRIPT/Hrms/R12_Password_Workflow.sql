SELECT *
  FROM (SELECT WorkflowItemEO.ITEM_TYPE,
               WorkflowItemEO.ITEM_KEY,
               apps.wf_fwkmon.getitemstatus (
                  WorkflowItemEO.ITEM_TYPE,
                  WorkflowItemEO.ITEM_KEY,
                  WorkflowItemEO.END_DATE,
                  WorkflowItemEO.ROOT_ACTIVITY,
                  WorkflowItemEO.ROOT_ACTIVITY_VERSION)
                  STATUS_CODE
          FROM WF_ITEMS WorkflowItemEO,
               WF_ITEM_TYPES_VL WorkflowItemTypeEO,
               WF_ACTIVITIES_VL ActivityEO,
               WF_ITEM_ATTRIBUTE_VALUES attrib
         WHERE     WorkflowItemEO.ITEM_TYPE = WorkflowItemTypeEO.NAME
               AND ActivityEO.ITEM_TYPE = WorkflowItemEO.ITEM_TYPE
               AND ActivityEO.NAME = WorkflowItemEO.ROOT_ACTIVITY
               AND ActivityEO.VERSION = WorkflowItemEO.ROOT_ACTIVITY_VERSION
               AND attrib.item_type = WorkflowItemEO.ITEM_TYPE
               AND attrib.item_key = WorkflowItemEO.ITEM_KEY
               AND attrib.name = 'USER_NAME'
               AND attrib.text_value = '07448') QRSLT
 WHERE item_type = 'UMXLHELP';