declare
lx_ovn number;
begin
lx_ovn :=91;
hr_api_hook_call_api.update_api_hook_call
  (p_validate                     =>false,
   p_effective_date               => trunc(sysdate),
   p_api_hook_call_id             => 818,--819 update
   p_enabled_flag                 => 'N',
   p_object_version_number        => lx_ovn
  );
  commit;
end;

module_id = Create= 1743,update=1745

--create absence
select api_hook_call_id,object_version_number,call_package,call_procedure,sequence,enabled_flag from hr_api_hook_calls where api_hook_id = 3843
order by 1 desc

--update absence
select api_hook_call_id,object_version_number,call_package,call_procedure,sequence,enabled_flag from hr_api_hook_calls where api_hook_id = 3848