DELETE      hr_api_transaction_values
      WHERE transaction_step_id IN (
               SELECT transaction_step_id
                 FROM hr_api_transaction_steps
                WHERE item_key IN (
                         SELECT item_key
                           FROM hr_api_transactions hrapi
                          WHERE (   hrapi.selected_person_id =
                                            (SELECT DISTINCT person_id
                                                        FROM per_all_people_f
                                                       WHERE employee_number =
                                                                      :emp_num)
                                 OR hrapi.creator_person_id =
                                            (SELECT DISTINCT person_id
                                                        FROM per_all_people_f
                                                       WHERE employee_number =
                                                                      :emp_num)
                                )
                            AND process_name = 'HR_LOA_JSP_PRC'));

DELETE      hr_api_transaction_steps
      WHERE item_key IN (
               SELECT item_key
                 FROM hr_api_transactions hrapi
                WHERE (   hrapi.selected_person_id =
                                            (SELECT DISTINCT person_id
                                                        FROM per_all_people_f
                                                       WHERE employee_number =
                                                                      :emp_num)
                       OR hrapi.creator_person_id =
                                            (SELECT DISTINCT person_id
                                                        FROM per_all_people_f
                                                       WHERE employee_number =
                                                                      :emp_num)
                      )
                  AND process_name = 'HR_LOA_JSP_PRC');


DELETE      hr_api_transactions hrapi
      WHERE (   hrapi.selected_person_id = (SELECT DISTINCT person_id
                                                       FROM per_all_people_f
                                                      WHERE employee_number =
                                                                      :emp_num)
             OR hrapi.creator_person_id = (SELECT DISTINCT person_id
                                                      FROM per_all_people_f
                                                     WHERE employee_number =
                                                                      :emp_num)
            )
        AND process_name = 'HR_LOA_JSP_PRC';