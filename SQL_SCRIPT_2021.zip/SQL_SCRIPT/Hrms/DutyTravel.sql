SELECT
        ppa.ROWID
       ,papf.employee_number "Employee Number"
       ,INITCAP(papf.TITLE) Title 
       ,papf.LAST_NAME
       ,papf.full_name "Full Name"
       ,papf.email_address
       ,org.name  "Department"
       ,pcak.segment3 "cost center"
       ,SUBSTR(pap.name,1,INSTR(pap.name,'|')-1) "employee designation"
         ,fcl.meaning "purpose of journey"
       ,pac.segment12 "departure sector1"
       ,pac.segment3 "destination sector 1"
       ,pac.segment4 "days sector 1"
       ,TO_CHAR((TO_DATE(pac.segment5,'yyyy/mm/dd hh24:mi:ss'))) "date of departure1"
       ,pac.segment6 "flight number 1"
       ,pac.segment8 "departure sector2"
       ,pac.segment9 "destination sector 2"
       ,pac.segment10 "days sector 2"
       ,TO_CHAR((TO_DATE(pac.segment11,'yyyy/mm/dd hh24:mi:ss'))) "date of departure 2"
       ,pac.segment2 "flight number2"
       ,pac.segment14 "departure sector3"
       ,pac.segment15 "destination sector 3"
       ,pac.segment18 "days sector 3"
       ,TO_CHAR((TO_DATE(pac.segment16,'yyyy/mm/dd hh24:mi:ss'))) "date of departure 3"
       ,pac.segment17 "flight number 3"
       ,TO_CHAR((TO_DATE(pac.segment22,'yyyy/mm/dd hh24:mi:ss'))) "date of return "
       ,pac.segment23 "return flight"
       ,NVL(pac.segment4,0)+NVL(pac.segment10,0)+NVL(pac.segment18,0)   "total days"
,pac.SEGMENT13 "Others"
          ,(SELECT DISTINCT full_name FROM per_all_people_f WHERE person_id=QAG_FINAL_SUPERVISOR.get_sdt_approvers(PAPF.PERSON_ID)
 and current_employee_flag='Y'
 and employee_number is not null
 and trunc(sysdate) between effective_start_date and effective_end_date) "approver name"
       ,(SELECT DISTINCT name FROM per_all_assignments_f paaf, hr_all_organization_units haou
 WHERE person_id=QAG_FINAL_SUPERVISOR.get_sdt_approvers(papf.PERSON_ID)
 AND haou.organization_id=paaf.organization_id
 AND primary_flag='Y'
 AND TRUNC(SYSDATE) BETWEEN paaf.effective_start_date AND paaf.effective_end_date) "approver organization"
       ,(SELECT DISTINCT SUBSTR(pap.name,1,INSTR(name,'|')-1) FROM per_all_positions pap, per_all_assignments_f paaf
 WHERE paaf.position_id= pap.position_id
 AND person_id=QAG_FINAL_SUPERVISOR.get_sdt_approvers(papf.PERSON_ID)
 AND primary_flag='Y'
 AND TRUNC(SYSDATE) BETWEEN paaf.effective_start_date AND paaf.effective_end_date) "approver designation", ppa.date_from
      FROM
PER_ANALYSIS_CRITERIA pac,
per_person_analyses ppa,
per_all_people_f papf,
per_all_assignments_f paf,
hr_all_organization_units org,
per_all_positions pap,
pay_cost_allocation_keyflex pcak,
fnd_common_lookups fcl
WHERE pac.ID_FLEX_NUM = (
SELECT 
ID_FLEX_NUM 
FROM 
FND_ID_FLEX_STRUCTURES 
WHERE ID_FLEX_STRUCTURE_CODE ='QA_SINGLE_DUTY_TRAVEL')
AND ppa.ANALYSIS_CRITERIA_ID=pac.ANALYSIS_CRITERIA_ID
AND papf.person_id=ppa.person_id
AND papf.person_id=paf.person_id
AND org.organization_id=paf.organization_id
AND pap.position_id(+)=paf.position_id
AND papf.current_employee_flag ='Y'
AND org.cost_allocation_keyflex_id=pcak.cost_allocation_keyflex_id(+)
AND TRUNC(SYSDATE) BETWEEN paf.effective_start_date AND paf.effective_end_date
AND TRUNC(SYSDATE) BETWEEN papf.effective_start_date AND papf.effective_end_date
AND fcl.lookup_type = 'QR_DT_TRVL_PURPOSE'
AND fcl.lookup_code = pac.segment1
--and ppa.ROWID ='AAAKovAHDAAARMUAAj'
and papf.employee_number in :emp_num
--and ppa.date_from in ('21-MAY-2009')
order by ppa.date_from desc