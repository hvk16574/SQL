SELECT   employee_number,
           full_name,
           hr_general.DECODE_GRADE (paf.grade_id) grd,
           pps.date_start Hire_date,
           pps.actual_termination_date
    FROM   per_periods_of_service pps, per_all_people_f papf, per_all_assignments_f paf
   WHERE       papf.person_id = paf.person_id
           AND papf.person_id = pps.person_id
           AND TRUNC (SYSDATE) BETWEEN Papf.effective_start_date AND Papf.effective_end_date
           AND TRUNC (SYSDATE) BETWEEN Paf.effective_start_date AND Paf.effective_end_date
           AND pps.ACTUAL_TERMINATION_DATE <= TRUNC (SYSDATE)
           AND pps.date_Start = (SELECT   MAX (date_Start)
                                   FROM   per_periods_of_service
                                  WHERE   person_id = papf.person_id)
           AND employee_number IN (SELECT   user_name
                                     FROM   fnd_user
                                    WHERE   end_date IS NULL)
ORDER BY   pps.actual_termination_date DESC

SELECT   DISTINCT
         papf.employee_number, papf.FULL_NAME, pps.actual_termination_date
  FROM   per_all_people_f papf,
         per_all_assignments_f paaf,
         per_periods_of_service pps
 WHERE       papf.PERSON_ID = paaf.PERSON_ID
         AND pps.PERSON_ID = paaf.PERSON_ID
         AND pps.ACTUAL_TERMINATION_DATE <= TRUNC (SYSDATE);

SELECT   DISTINCT employee_number,
                  full_name,
                  hr_general.DECODE_GRADE (paf.grade_id) grd,
                  pps.DATE_START Hire_date,
                  pps.ACTUAL_TERMINATION_DATE
  FROM   per_periods_of_service pps,
         per_all_people_f papf,
         per_all_assignments_f paf
 WHERE   pps.PERIOD_OF_SERVICE_ID = paf.PERIOD_OF_SERVICE_ID
         AND papf.person_id = paf.person_id
         AND SYSDATE BETWEEN Papf.effective_start_date
                         AND  Papf.effective_end_date
         AND SYSDATE BETWEEN Paf.effective_start_date
                         AND  Paf.effective_end_date
--         AND current_employee_flag = 'Y'      /* need to comment is require */
--         AND payroll_id = 61
         AND pps.ACTUAL_TERMINATION_DATE <= TRUNC (SYSDATE)
         and employee_number  in (select user_name from fnd_user where end_date is  null);