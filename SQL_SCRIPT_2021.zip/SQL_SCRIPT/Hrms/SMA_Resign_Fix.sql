select * FROM   hr_api_transactions
                    where item_key = :item_key;

select * FROM   hr_api_transaction_steps
      WHERE   transaction_id IN
                    (SELECT   transaction_id
                       FROM   hr_api_transactions
                      WHERE   item_key = :item_key);

select *  FROM   hr_api_transaction_values
      WHERE   transaction_step_id IN
                    (SELECT   transaction_step_id
                       FROM   hr_api_transaction_steps
                      WHERE   transaction_id IN
                                    (SELECT   transaction_id
                                       FROM   hr_api_transactions
                                      WHERE   item_key = :item_key));
                                      
                                      
                                      
                                      
                                      
create table hr_api_transaction_steps_sma
as
select * FROM   hr_api_transaction_steps
      WHERE   transaction_id IN
                    (SELECT   transaction_id
                       FROM   hr_api_transactions
                      WHERE   item_key = 871400);
                                      