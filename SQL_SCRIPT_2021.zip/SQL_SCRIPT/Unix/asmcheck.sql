SET ECHO off VER off FEEDBACK off LINES 140 PAGES 0 HEAD OFF
COLUMN GNum      FORMAT 999           HEADING "Group Number"
COLUMN DGName    FORMAT A32           HEADING "ASM Disk Group"
COLUMN TotalMB   FORMAT 9,999,999,999 HEADING "Total Space (MB)"
COLUMN UsedMB    FORMAT 9,999,999,999 HEADING "Used Space (MB)"
COLUMN FreeMB    FORMAT 9,999,999,999 HEADING "|Free Space (MB)"
COLUMN UsableMB  FORMAT 9,999,999,999 HEADING "Usable|Free Space (MB)"
COLUMN UsedPct   FORMAT 999.99        HEADING "Used%"
COLUMN FreePct   FORMAT 999.99        HEADING "Free%"
COLUMN UsablePct FORMAT 999.99        HEADING "Usable|Free%"
COLUMN Msg       FORMAT A5            HEADING "State"
REM SELECT group_number GNum
SELECT name DGName
,total_mb TotalMB
,total_mb-free_mb UsedMB
,free_mb FreeMb
,usable_file_mb UsableMB
,ROUND(((total_mb-free_mb)/total_mb)*100,2) UsedPct
,ROUND((free_mb/total_mb)*100,2) FreePct
,ROUND((usable_file_mb/total_mb)*100,2) UsablePct
FROM v$asm_diskgroup
WHERE group_number = &&1
ORDER BY 8 ASC;
