<RULESET title="Program Structure" version="11.0">
<PROPERTIES>
<SUMMARY>
<RULESET_TYPE>Quest</RULESET_TYPE>
<AUTHOR>Quest Software</AUTHOR>
<CREATED>38447.6759019329</CREATED>
<MODIFIED>38447.6760691898</MODIFIED>
<COMMENTS>This rule set supplies insights and suggestions for restructuring code, identifying redundancy and obsolete items, and locating inconsistencies.</COMMENTS>
<RULESET_TOTAL>41</RULESET_TOTAL>
</SUMMARY>
</PROPERTIES>
  <RULEFILTER>
    <TYPE Type="4" />
  </RULEFILTER>
  <RULES>
    <RULE rid="*" />
  </RULES>
</RULESET>

