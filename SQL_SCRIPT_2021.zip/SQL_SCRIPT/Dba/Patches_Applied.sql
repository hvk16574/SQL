SELECT   aat.applications_system_name "Instance", 
         aat.NAME                     "Machine",
         app.patch_name               "Patch", 
         apr.start_date               "Start", 
         apr.end_date                 "End"
    FROM applsys.ad_applied_patches app,
         applsys.ad_appl_tops aat,
         applsys.ad_patch_drivers apd,
         applsys.ad_patch_runs apr
   WHERE app.applied_patch_id = apd.applied_patch_id
     AND apd.patch_driver_id = apr.patch_driver_id
     AND apr.appl_top_id = aat.appl_top_id
     AND app.creation_date > SYSDATE - 1
ORDER BY apr.start_date DESC