SELECT   DISTINCT
         employee_number,
         full_name,
         papf.person_id,
         SUBSTR (hr_general.DECODE_GRADE (paf.grade_id), 4) Grade,
         (CASE
--             WHEN (paf.payroll_id = 61 AND SUBSTR (hr_general.DECODE_GRADE (paf.grade_id), 4) > 7)
             WHEN (paf.payroll_id = 61 AND nvl(regexp_replace(hr_general.DECODE_GRADE (paf.grade_id), '[A-Za-z.| ]'),0) between 8 and 14)
             THEN
                (SELECT   user_name || ' - QR_MANAGER_DIRECT_ACCESS'
                   FROM   fnd_user
                  WHERE   user_name = employee_number
                          AND user_id NOT IN
                                   (SELECT   DISTINCT user_id
                                      FROM   fnd_user_resp_groups_direct
                                     WHERE       RESPONSIBILITY_ID = 51374
                                             AND RESPONSIBILITY_application_ID = 800
                                             AND TRUNC (SYSDATE) BETWEEN TRUNC (start_date) AND TRUNC (NVL (end_date, SYSDATE))))
             WHEN (paf.payroll_id = 61 AND regexp_replace(hr_general.DECODE_GRADE (paf.grade_id), '[A-Za-z.| ]') < 8 )
             THEN
                (SELECT   user_name || ' - QR_EMPLOYEE_DIRECT_ACCESS'
                   FROM   fnd_user
                  WHERE   user_name = employee_number
                          AND user_id NOT IN
                                   (SELECT   DISTINCT user_id
                                      FROM   fnd_user_resp_groups_direct
                                     WHERE       RESPONSIBILITY_ID = 51375
                                             AND RESPONSIBILITY_application_ID = 800
                                             AND TRUNC (SYSDATE) BETWEEN TRUNC (start_date) AND TRUNC (NVL (end_date, SYSDATE))))
             WHEN (paf.payroll_id = 122 AND nvl(regexp_replace(hr_general.DECODE_GRADE (paf.grade_id), '[A-Za-z.| ]'),0) between 8 and 14)
             THEN
                (SELECT   user_name || ' - DIA_MANAGER_DIRECT_ACCESS'
                   FROM   fnd_user
                  WHERE   user_name = employee_number
                          AND user_id NOT IN
                                   (SELECT   DISTINCT user_id
                                      FROM   fnd_user_resp_groups_direct
                                     WHERE       RESPONSIBILITY_ID = 53137
                                             AND RESPONSIBILITY_application_ID = 800
                                             AND TRUNC (SYSDATE) BETWEEN TRUNC (start_date) AND TRUNC (NVL (end_date, SYSDATE))))
             WHEN (paf.payroll_id = 122 AND regexp_replace(hr_general.DECODE_GRADE (paf.grade_id), '[A-Za-z.| ]') < 8 )
             THEN
                (SELECT   user_name || ' - DIA_EMPLOYEE_DIRECT_ACCESS'
                   FROM   fnd_user
                  WHERE   user_name = employee_number
                          AND user_id NOT IN
                                   (SELECT   DISTINCT user_id
                                      FROM   fnd_user_resp_groups_direct
                                     WHERE       RESPONSIBILITY_ID = 53136
                                             AND RESPONSIBILITY_application_ID = 800
                                             AND TRUNC (SYSDATE) BETWEEN TRUNC (start_date) AND TRUNC (NVL (end_date, SYSDATE))))
             WHEN (paf.payroll_id = 84 AND nvl(regexp_replace(hr_general.DECODE_GRADE (paf.grade_id), '[A-Za-z.| ]'),0) between 8 and 14)
             THEN
                (SELECT   user_name || ' - QC_MANAGER_DIRECT_ACCESS'
                   FROM   fnd_user
                  WHERE   user_name = employee_number
                          AND user_id NOT IN
                                   (SELECT   DISTINCT user_id
                                      FROM   fnd_user_resp_groups_direct
                                     WHERE       RESPONSIBILITY_ID = 53117
                                             AND RESPONSIBILITY_application_ID = 800
                                             AND TRUNC (SYSDATE) BETWEEN TRUNC (start_date) AND TRUNC (NVL (end_date, SYSDATE))))
             WHEN (paf.payroll_id = 84 AND regexp_replace(hr_general.DECODE_GRADE (paf.grade_id), '[A-Za-z.| ]') < 8 )
             THEN
                (SELECT   user_name || ' - QC_EMPLOYEE_DIRECT_ACCESS'
                   FROM   fnd_user
                  WHERE   user_name = employee_number
                          AND user_id NOT IN
                                   (SELECT   DISTINCT user_id
                                      FROM   fnd_user_resp_groups_direct
                                     WHERE       RESPONSIBILITY_ID = 53116
                                             AND RESPONSIBILITY_application_ID = 800
                                             AND TRUNC (SYSDATE) BETWEEN TRUNC (start_date) AND TRUNC (NVL (end_date, SYSDATE))))
             WHEN (paf.payroll_id = 142 AND nvl(regexp_replace(hr_general.DECODE_GRADE (paf.grade_id), '[A-Za-z.| ]'),0) between 8 and 14)
             THEN
                (SELECT   user_name || ' - QD_MANAGER_DIRECT_ACCESS'
                   FROM   fnd_user
                  WHERE   user_name = employee_number
                          AND user_id NOT IN
                                   (SELECT   DISTINCT user_id
                                      FROM   fnd_user_resp_groups_direct
                                     WHERE       RESPONSIBILITY_ID = 53139
                                             AND RESPONSIBILITY_application_ID = 800
                                             AND TRUNC (SYSDATE) BETWEEN TRUNC (start_date) AND TRUNC (NVL (end_date, SYSDATE))))
             WHEN (paf.payroll_id = 142 AND regexp_replace(hr_general.DECODE_GRADE (paf.grade_id), '[A-Za-z.| ]') < 8 )
             THEN
                (SELECT   user_name || ' - QD_EMPLOYEE_DIRECT_ACCESS'
                   FROM   fnd_user
                  WHERE   user_name = employee_number
                          AND user_id NOT IN
                                   (SELECT   DISTINCT user_id
                                      FROM   fnd_user_resp_groups_direct
                                     WHERE       RESPONSIBILITY_ID = 53138
                                             AND RESPONSIBILITY_application_ID = 800
                                             AND TRUNC (SYSDATE) BETWEEN TRUNC (start_date) AND TRUNC (NVL (end_date, SYSDATE))))
             WHEN (paf.payroll_id = 162 AND nvl(regexp_replace(hr_general.DECODE_GRADE (paf.grade_id), '[A-Za-z.| ]'),0) between 8 and 14)
             THEN
                (SELECT   user_name || ' - QF_MANAGER_DIRECT_ACCESS'
                   FROM   fnd_user
                  WHERE   user_name = employee_number
                          AND user_id NOT IN
                                   (SELECT   DISTINCT user_id
                                      FROM   fnd_user_resp_groups_direct
                                     WHERE       RESPONSIBILITY_ID = 53096
                                             AND RESPONSIBILITY_application_ID = 800
                                             AND TRUNC (SYSDATE) BETWEEN TRUNC (start_date) AND TRUNC (NVL (end_date, SYSDATE))))
             WHEN (paf.payroll_id = 162 AND regexp_replace(hr_general.DECODE_GRADE (paf.grade_id), '[A-Za-z.| ]') < 8 )
             THEN
                (SELECT   user_name || ' - QF_EMPLOYEE_DIRECT_ACCESS'
                   FROM   fnd_user
                  WHERE   user_name = employee_number
                          AND user_id NOT IN
                                   (SELECT   DISTINCT user_id
                                      FROM   fnd_user_resp_groups_direct
                                     WHERE       RESPONSIBILITY_ID = 53097
                                             AND RESPONSIBILITY_application_ID = 800
                                             AND TRUNC (SYSDATE) BETWEEN TRUNC (start_date) AND TRUNC (NVL (end_date, SYSDATE))))
             WHEN (paf.payroll_id = 202 AND nvl(regexp_replace(hr_general.DECODE_GRADE (paf.grade_id), '[A-Za-z.| ]'),0) between 8 and 14)
             THEN
                (SELECT   user_name || ' - QS_MANAGER_DIRECT_ACCESS'
                   FROM   fnd_user
                  WHERE   user_name = employee_number
                          AND user_id NOT IN
                                   (SELECT   DISTINCT user_id
                                      FROM   fnd_user_resp_groups_direct
                                     WHERE       RESPONSIBILITY_ID = 53159
                                             AND RESPONSIBILITY_application_ID = 800
                                             AND TRUNC (SYSDATE) BETWEEN TRUNC (start_date) AND TRUNC (NVL (end_date, SYSDATE))))
             WHEN (paf.payroll_id = 202 AND regexp_replace(hr_general.DECODE_GRADE (paf.grade_id), '[A-Za-z.| ]') < 8 )
             THEN
                (SELECT   user_name || ' - QS_EMPLOYEE_DIRECT_ACCESS'
                   FROM   fnd_user
                  WHERE   user_name = employee_number
                          AND user_id NOT IN
                                   (SELECT   DISTINCT user_id
                                      FROM   fnd_user_resp_groups_direct
                                     WHERE       RESPONSIBILITY_ID = 53158
                                             AND RESPONSIBILITY_application_ID = 800
                                             AND TRUNC (SYSDATE) BETWEEN TRUNC (start_date) AND TRUNC (NVL (end_date, SYSDATE))))                                                                                          
          END)
            RESP,
         ROWNUM
  FROM   per_periods_of_service pps,
         per_all_people_f papf,
         per_all_assignments_f paf,
         pay_people_groups ppg
 WHERE       
 pps.PERIOD_OF_SERVICE_ID = paf.PERIOD_OF_SERVICE_ID          AND 
         papf.person_id = paf.person_id
         AND TRUNC (SYSDATE) BETWEEN Papf.effective_start_date AND Papf.effective_end_date
         AND TRUNC (SYSDATE) BETWEEN Paf.effective_start_date AND Paf.effective_end_date
         AND current_employee_flag = 'Y'
         AND pps.ACTUAL_TERMINATION_DATE IS NULL
         AND paf.people_group_id = ppg.people_group_id
         AND paf.primary_flag = 'Y'
         AND employee_number = '36051'
         
         
         
         
         
         
         select distinct regexp_replace(name, '[A-Za-z.| ]') from per_grades