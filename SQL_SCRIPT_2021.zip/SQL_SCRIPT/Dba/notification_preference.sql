select notification_preference from wf_local_roles
 WHERE   orig_system IN ('FND_USR', 'PER');

select preference_value from fnd_user_preferences
 WHERE       preference_name = 'MAILTYPE'
         AND module_name = 'WF'
         AND user_name <> '-WF_DEFAULT-';

--Updates for Users having the preference set to "Disabled" would look like :

select notification_preference from wf_local_roles
 WHERE   orig_system IN ('FND_USR', 'PER')
         AND name IN
                  (SELECT   user_name
                     FROM   fnd_user_preferences
                    WHERE       preference_name = 'MAILTYPE'
                            AND module_name = 'WF'
                            AND preference_value = 'DISABLED');

select preference_value from  fnd_user_preferences
 WHERE       preference_name = 'MAILTYPE'
         AND module_name = 'WF'
         AND preference_value = 'DISABLED';
         
----------------------------
UPDATE   wf_local_roles
   SET   notification_preference = ''
 WHERE   orig_system IN ('FND_USR', 'PER');

UPDATE   fnd_user_preferences
   SET   preference_value = ''
 WHERE       preference_name = 'MAILTYPE'
         AND module_name = 'WF'
         AND user_name <> '-WF_DEFAULT-';

--Updates for Users having the preference set to "Disabled" would look like :

UPDATE   wf_local_roles
   SET   notification_preference = ''
 WHERE   orig_system IN ('FND_USR', 'PER')
         AND name IN
                  (SELECT   user_name
                     FROM   fnd_user_preferences
                    WHERE       preference_name = 'MAILTYPE'
                            AND module_name = 'WF'
                            AND preference_value = 'DISABLED');

UPDATE   fnd_user_preferences
   SET   preference_value = ''
 WHERE       preference_name = 'MAILTYPE'
         AND module_name = 'WF'
         AND preference_value = 'DISABLED';         