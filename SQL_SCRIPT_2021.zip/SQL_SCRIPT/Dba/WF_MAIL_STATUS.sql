SELECT *  FROM wf_notifications WHERE MAIL_STATUS = 'MAIL';

SELECT /*WF_PREF.get_pref(RECIPIENT_ROLE, 'MAILTYPE') es,*/ a.*    FROM wf_notifications a WHERE MAIL_STATUS = 'FAILED' and trunc(BEGIN_DATE) = trunc(sysdate) 
and WF_PREF.get_pref(RECIPIENT_ROLE, 'MAILTYPE') != 'DISABLED' order by BEGIN_DATE desc;

SELECT *  FROM wf_notifications WHERE NOTIFICATION_ID IN (68681946);

SELECT status, mail_status FROM wf_notifications WHERE notification_id = 68683969

SELECT email_address, nvl(WF_PREF.get_pref(name, 'MAILTYPE'),notification_preference) FROM wf_roles WHERE name = upper('&recipient_role');

SELECT email_address, nvl(WF_PREF.get_pref(name, 'MAILTYPE'),notification_preference) FROM wf_roles WHERE name in 
(SELECT distinct RECIPIENT_ROLE FROM wf_notifications WHERE MAIL_STATUS = 'FAILED'
and trunc(BEGIN_DATE) = trunc(sysdate))

select TEXT from WF_RESOURCES where NAME='WF_VERSION';

UPDATE wf_notifications   SET MAIL_STATUS = 'R1213' WHERE MAIL_STATUS = 'MAIL';

SELECT user_name, email_address  FROM fnd_user WHERE user_name IN (SELECT DISTINCT RECIPIENT_ROLE FROM wf_notifications WHERE MAIL_STATUS = 'MAIL');

SELECT papf.email_address,       employee_number,       fu.user_name,       fu.email_address
  FROM per_all_people_f papf, fnd_user fu
 WHERE employee_number = fu.user_name
       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date AND papf.effective_end_date
       AND user_name IN (SELECT DISTINCT RECIPIENT_ROLE FROM wf_notifications WHERE MAIL_STATUS = 'MAIL')
       and papf.email_address is null;
       
---------------------------

UPDATE wf_notifications
   SET MAIL_STATUS = 'R1213'
 WHERE MAIL_STATUS = 'MAIL'
       AND RECIPIENT_ROLE IN
              (SELECT DISTINCT employee_number
                 FROM per_all_people_f papf, fnd_user fu
                WHERE employee_number = fu.user_name
                      AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                              AND papf.effective_end_date
                      AND user_name IN (SELECT DISTINCT RECIPIENT_ROLE
                                          FROM wf_notifications
                                         WHERE MAIL_STATUS = 'MAIL')
                      AND papf.email_address IS NULL)