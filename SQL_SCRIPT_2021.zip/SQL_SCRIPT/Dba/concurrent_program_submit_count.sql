SELECT  trunc(ACTUAL_START_DATE) "Date",
        to_char(ACTUAL_START_DATE, 'Dy') "Day",
        count(1) "Total",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'00',1,0)) "h0",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'01',1,0)) "h1",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'02',1,0)) "h2",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'03',1,0)) "h3",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'04',1,0)) "h4",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'05',1,0)) "h5",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'06',1,0)) "h6",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'07',1,0)) "h7",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'08',1,0)) "h8",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'09',1,0)) "h9",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'10',1,0)) "h10",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'11',1,0)) "h11",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'12',1,0)) "h12",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'13',1,0)) "h13",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'14',1,0)) "h14",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'15',1,0)) "h15",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'16',1,0)) "h16",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'17',1,0)) "h17",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'18',1,0)) "h18",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'19',1,0)) "h19",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'20',1,0)) "h20",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'21',1,0)) "h21",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'22',1,0)) "h22",
        SUM(decode(to_char(ACTUAL_START_DATE, 'hh24'),'23',1,0)) "h23",
        -- for today, use # of hrs so far today to get avg
        -- for past days, use 24 hrs to get avg
        decode(trunc(ACTUAL_START_DATE),
               trunc(sysdate), round(count(1) / (24 * to_number(to_char(sysdate, 'sssss')+1) / 86400),2),
               round(count(1) / 24, 2)) "Avg"
from fnd_concurrent_requests
where ACTUAL_START_DATE >= (sysdate - 51)
group by trunc(ACTUAL_START_DATE), to_char(ACTUAL_START_DATE, 'Dy')
Order by 1;
