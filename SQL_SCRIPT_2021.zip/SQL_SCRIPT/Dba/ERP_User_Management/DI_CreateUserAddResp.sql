DECLARE
   CURSOR c1
   IS
      SELECT DISTINCT employee_number, full_name, a.person_id, email_address,
                      date_of_birth
                 FROM per_all_people_f a, per_all_assignments_f paaf
                WHERE a.person_id = paaf.person_id
                  AND payroll_id = 122
                  AND primary_flag = 'Y'
                  AND 1 >
                         (SELECT COUNT (papf1.employee_number)
                            FROM per_all_people_f papf,
                                 per_all_people_f papf1,
                                 per_all_assignments_f paaf
                           WHERE paaf.supervisor_id = papf.person_id
                             AND papf1.person_id = paaf.person_id
                             AND TRUNC (SYSDATE)
                                    BETWEEN papf.effective_start_date
                                        AND papf.effective_end_date
                             AND papf.current_employee_flag = 'Y'
                             AND paaf.primary_flag = 'Y'
                             AND TRUNC (SYSDATE)
                                    BETWEEN paaf.effective_start_date
                                        AND paaf.effective_end_date
                             AND papf.employee_number = a.employee_number
                             AND papf1.current_employee_flag = 'Y'
                             AND TRUNC (SYSDATE)
                                    BETWEEN papf1.effective_start_date
                                        AND papf1.effective_end_date)
                  AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date
                                          AND paaf.effective_end_date
                  AND TRUNC (SYSDATE) BETWEEN a.effective_start_date
                                          AND a.effective_end_date
                  AND current_employee_flag = 'Y'
                  AND employee_number NOT IN (
                         SELECT user_name
                           FROM fnd_user
                          WHERE user_id IN (
                                   SELECT DISTINCT user_id
                                              FROM fnd_user_resp_groups_direct
                                             WHERE responsibility_application_id =
                                                                           800
                                               AND responsibility_id IN
                                                               (53136, 53137)));

   x_user_name                    VARCHAR2 (200);
   x_owner                        VARCHAR2 (200);
   x_unencrypted_password         VARCHAR2 (200);
   x_session_number               NUMBER         := NULL;
   x_start_date                   DATE           := SYSDATE;
   x_end_date                     DATE           := NULL;
   x_last_logon_date              DATE           := NULL;
   x_description                  VARCHAR2 (200) := NULL;
   x_password_date                DATE           := NULL;
   x_password_accesses_left       NUMBER         := NULL;
   x_password_lifespan_accesses   NUMBER         := NULL;
   x_password_lifespan_days       NUMBER         := NULL;
   x_employee_id                  NUMBER         := NULL;
   x_email_address                VARCHAR2 (200);
   x_fax                          VARCHAR2 (200) := NULL;
   x_customer_id                  NUMBER         := NULL;
   x_supplier_id                  NUMBER         := NULL;
BEGIN
   FOR c1_rec IN c1
   LOOP
      x_user_name := c1_rec.employee_number;
      x_unencrypted_password := TO_CHAR (c1_rec.date_of_birth, 'DD-MM-YYYY');
      apps.fnd_user_pkg.addresp (x_user_name,
                                 'PER',
                                 'DIA_EMPLOYEE_DIRECT_ACCESS',
                                 'STANDARD',
                                 NULL,
                                 SYSDATE,
                                 NULL
                                );
      DBMS_OUTPUT.put_line (   ' Added the Employee Responsibility : '
                            || x_user_name
                           );
   END LOOP;
END;