DECLARE
   CURSOR c1
   IS
   SELECT   distinct user_id,user_name from fnd_user
   where user_name in (select * from a);

   x_user_name                    VARCHAR2 (200);
   x_user_id    number;
   x_owner                        VARCHAR2 (200);
   x_unencrypted_password         VARCHAR2 (200);
   x_session_number               NUMBER         := NULL;
   x_start_date                   DATE           := SYSDATE;
   x_end_date                     DATE           := NULL;
   x_last_logon_date              DATE           := NULL;
   x_description                  VARCHAR2 (200) := NULL;
   x_password_date                DATE           := NULL;
   x_password_accesses_left       NUMBER         := NULL;
   x_password_lifespan_accesses   NUMBER         := NULL;
   x_password_lifespan_days       NUMBER         := NULL;
   x_employee_id                  NUMBER         := NULL;
   x_email_address                VARCHAR2 (200);
   x_fax                          VARCHAR2 (200) := NULL;
   x_customer_id                  NUMBER         := NULL;
   x_supplier_id                  NUMBER         := NULL;
    RetVal BOOLEAN;
BEGIN
   FOR c1_rec IN c1
   LOOP
      x_user_name := c1_rec.user_name;
      x_user_id := c1_rec.user_id;
       RetVal :=   FND_PROFILE.SAVE('POR_DEFAULT_DELIVER_TO_LOCATION_ID',175829,'USER', x_user_id,null,null);
      DBMS_OUTPUT.put_line (
      ' Added the QAG Manager Self Service - SMA Responsibility : '|| x_user_name);
--      DBMS_OUTPUT.put_line (x_user_name);
   END LOOP;
END;