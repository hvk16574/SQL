select sum(dbms_space_admin.segment_number_blocks(ts_number,  s.file#, header_block, segment_type_id, s.cachehint, NVL(s.spare1,0), o.dataobj#, blocks)*blocksize) bytes,
       sum(dbms_space_admin.segment_number_extents(ts_number,  s.file#, header_block, segment_type_id, s.cachehint, NVL(s.spare1,0), o.dataobj#, extents)) extents
from SYS."_CURRENT_EDITION_OBJ" o, sys.ts$ ts,  sys.seg$ s,
    (select decode(bitand(t.property, 8192), 8192, 'NESTED TABLE', 'TABLE') object_type,
                            2 object_type_id,
                            5 segment_type_id,
                            t.obj# object_id,
                            t.file# header_file,
                            t.block# header_block,
                            t.ts# ts_number
                    from sys.tab$ t
                    where bitand(t.property, 1024) = 0
                    union all
                    select decode(lf.fragtype$, 'P', 'LOB PARTITION', 'LOB SUBPARTITION'),
                           decode(lf.fragtype$, 'P', 40, 41), 8,
                           lf.fragobj#, lf.file#, lf.block#, lf.ts#
                    from sys.lobfrag$ lf) so
where s.file# = so.header_file
  and s.block# = so.header_block
  and s.ts# = so.ts_number
  and s.ts# = ts.ts#
  and s.type# = so.segment_type_id
  and o.obj# = so.object_id
  and o.owner# = (select user# from sys.user$ where name = :uname)
  and o.Type# = so.object_type_id
  and o.name = :tname