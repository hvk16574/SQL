select to_date(sysdate-(to_char(sysdate,'dd')-1),'dd.mm.yyyy')+level-1
 from dual 
 connect by level <= TO_CHAR(LAST_DAY(to_date(sysdate,'dd.mm.yyyy')),'DD');
 
 
WITH d AS
  (SELECT TRUNC ( to_date('01.'||:vmonth||'.'||:vyear,'dd.mm.yyyy'), 'MM' ) - 1 AS dt
  FROM dual
  )
SELECT dt + LEVEL 
   FROM d 
  CONNECT BY LEVEL <= ADD_MONTHS (dt, 1) - dt
/