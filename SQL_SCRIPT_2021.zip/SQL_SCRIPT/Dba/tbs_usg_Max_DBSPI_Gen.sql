DECLARE
   CURSOR c1 IS
      Select ts.tablespace_name tbs, to_char(round((((6144) * 100)/ size_info.max),3),'90.00') thold
From
      (
      select  a.tablespace_name,
             round(a.bytes_alloc / 1024 / 1024) megs_alloc,
             round(nvl(b.bytes_free, 0) / 1024 / 1024) megs_free,
             round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024) megs_used,
             round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100) Pct_Free,
            100 - round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100) Pct_used,
             round(maxbytes/1048576) Max
      from  ( select  f.tablespace_name,
                     sum(f.bytes) bytes_alloc,
                     sum(decode(f.autoextensible, 'YES',f.maxbytes,'NO', f.bytes)) maxbytes
              from dba_data_files f
              group by tablespace_name) a,
            (
             select ts.name tablespace_name, sum(fs.blocks) * ts.blocksize bytes_free
             from   DBA_LMT_FREE_SPACE fs, sys.ts$ ts
             where  ts.ts# = fs.tablespace_id
             group by ts.name, ts.blocksize
            ) b
      where a.tablespace_name = b.tablespace_name (+)
      union all
      select h.tablespace_name,
             round(sum(h.bytes_free + h.bytes_used) / 1048576) megs_alloc,
             round(sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / 1048576) megs_free,
             round(sum(nvl(p.bytes_used, 0))/ 1048576) megs_used,
             round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100) Pct_Free,
             100 - round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100) pct_used,
             round(sum(decode(f.autoextensible, 'YES', f.maxbytes, 'NO', f.bytes) / 1048576)) max
      from   sys.v_$TEMP_SPACE_HEADER h, dba_temp_files f,
             (select tablespace_name, file_id, sum(bytes_used) bytes_used
              from gv$temp_extent_pool
              group by tablespace_name, file_id) p
      where  p.file_id(+) = h.file_id
      and    p.tablespace_name(+) = h.tablespace_name
      and    f.file_id = h.file_id
      and    f.tablespace_name = h.tablespace_name
      group by h.tablespace_name
      ) size_info,
      sys.dba_tablespaces ts, sys.dba_tablespace_groups tsg, DBREPORT.QRDBA_TS_FREE_SPACEALERTCONFIG qtfs
where ts.tablespace_name = size_info.tablespace_name
and   ts.tablespace_name = tsg.tablespace_name (+)
and   ts.tablespace_name = qtfs.TSNAME;
   c1rec c1%ROWTYPE;
   x_file_handle                  UTL_FILE.file_type;   
BEGIN
x_file_handle              := UTL_FILE.fopen ('DB_LOG_DIR'
                                               , 'override.cfg'
                                               , 'w'
                                               , 32767
                                                );
      UTL_FILE.put_line (x_file_handle,'MONITOR "DBSPI-0334"
        MINTHRESHOLD
        MSGCONDITIONS
                CONDITION
                        OBJECT "+ASM1:ASM_PROD_DATA_101"
                        THRESHOLD 2.00
                CONDITION
                        OBJECT "+ASM1:ASM_DB001999_FLASH_103"
                        THRESHOLD -1
MONITOR "DBSPI-0206"
        MINTHRESHOLD
        MSGCONDITIONS');
   OPEN c1;
   LOOP
      FETCH c1 INTO c1rec;
      UTL_FILE.put_line (x_file_handle,'                CONDITION
                OBJECT "I0019991:'||c1rec.tbs||'"');
      UTL_FILE.put_line (x_file_handle,'                THRESHOLD '||c1rec.thold);
      EXIT WHEN c1%NOTFOUND;
   END LOOP;
   CLOSE c1;
   UTL_FILE.put_line (x_file_handle,'MONITOR "DBSPI-0203"
        MINTHRESHOLD
        MSGCONDITIONS
                CONDITION
                        OBJECT "I0019991:AHMD"
                        THRESHOLD -1');
   UTL_FILE.fclose (x_file_handle);   
END;