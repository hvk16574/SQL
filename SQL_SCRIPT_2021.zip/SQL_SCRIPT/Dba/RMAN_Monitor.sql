SELECT     /*+RULE */  SID, DECODE (totalwork, 0, 0, ROUND (100 * sofar / totalwork, 2)) "Percent",
           MESSAGE "Message", start_time, round(elapsed_seconds/60,2) elapsed_Minutes, round(time_remaining/60,2) time_remaining, inst_id, last_update_time
    FROM   GV$Session_longops
   WHERE   MESSAGE LIKE 'RMAN%' -- AND MESSAGE like 'RMAN: aggregate input%' 
           AND sid IN (SELECT /*+RULE */ sid FROM   gv$session WHERE   program LIKE 'rman%')
           AND (DECODE (totalwork, 0, 0, ROUND (100 * sofar / totalwork, 2))) <> 0
ORDER BY   2;

--------------------------------------------------------------------------------------------------

SELECT   sid, spid, client_info, event, seconds_in_wait, p1, p2, p3
  FROM   v$process p, v$session s
 WHERE   p.addr = s.paddr AND client_info LIKE 'rman channel=%';

SELECT   sid, start_time, totalwork sofar,(sofar / totalwork) * 100 pct_done
  FROM   v$session_longops
 WHERE       totalwork > sofar
         AND opname NOT LIKE '%aggregate%'
         AND opname LIKE 'RMAN%';

--------------------------------------------------------------------------------------------------
This script will report on all backups � full, incremental and archivelog backups �

col STATUS format a9
col hrs format 999.99
select
SESSION_KEY, INPUT_TYPE, STATUS,
to_char(START_TIME,'mm/dd/yy hh24:mi') start_time,
to_char(END_TIME,'mm/dd/yy hh24:mi')   end_time,
elapsed_seconds/3600                   hrs
from V$RMAN_BACKUP_JOB_DETAILS
order by session_key;

--------------------------------------------------------------------------------------------------

This script will report all on full and incremental backups, not archivelog backups �

col STATUS format a9
col hrs format 999.99
select
SESSION_KEY, INPUT_TYPE, STATUS,
to_char(START_TIME,'mm/dd/yy hh24:mi') start_time,
to_char(END_TIME,'mm/dd/yy hh24:mi')   end_time,
elapsed_seconds/3600                   hrs
from V$RMAN_BACKUP_JOB_DETAILS
where input_type='DB INCR'
order by session_key;
