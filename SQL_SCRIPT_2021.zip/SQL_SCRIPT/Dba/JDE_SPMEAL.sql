CREATE OR REPLACE PROCEDURE jde_spml
AS
   CURSOR c1
   IS
        SELECT   FLTNUM,
                 date2jde (TO_DATE (FLTDATE, 'DDMONYY')) FLTDATE,
                 ORIGIN || '-' || DESTINATION ROUTE,
                 COS || 'C' COS,
                 SUBSTR (MEALCODE, 1, 3) MEALCODE,
                 (COUNT * 100) COUNT
          FROM   QR_SPMEAL_V
      ORDER BY   1;             --  WHERE   FLTNUM = '0001'; -- and rownum <6;

   CURSOR c2 (
      v_flight_no                   VARCHAR2,
      v_flight_date                 NUMBER,
      v_cos                         VARCHAR2,
      v_meal_code                   VARCHAR2
   )
   IS
          SELECT   SLDBLFLT,
                   SLDBLDATE,
                   SLMUFC01,
                   SLSPML01,
                   SLAN01
            FROM   f550040b
           --           WHERE   LPAD (TRIM (SUBSTR (SLDBLFLT, 3)), 4, '0') = '0001' AND SLDBLDATE = 110182
           --           AND SLMUFC01 = 'CC' AND trim(SLSPML01) = v_meal_code ;
           WHERE       LPAD (TRIM (SUBSTR (SLDBLFLT, 3)), 4, '0') = v_flight_no
                   AND SLDBLDATE = v_flight_date
                   AND TRIM (SLMUFC01) = v_cos
                   AND TRIM (SLSPML01) = v_meal_code
      FOR UPDATE   ;

   c1_rec   c1%ROWTYPE;
   c2_rec   c2%ROWTYPE;
   v_done   NUMBER := 0;
BEGIN
   FOR c1_rec IN c1
   LOOP
      DBMS_OUTPUT.put_line(   c1_rec.FLTNUM
                           || '-'
                           || c1_rec.FLTDATE
                           || '-'
                           || c1_rec.ROUTE
                           || '-'
                           || c1_rec.COS
                           || '-'
                           || c1_rec.MEALCODE
                           || '-'
                           || c1_rec.COUNT);

      --begin
      FOR c2_rec IN c2 (c1_rec.FLTNUM,
                        c1_rec.FLTDATE,
                        c1_rec.COS,
                        c1_rec.MEALCODE)
      --   for c2_rec in c2('0001',110182,'CC',c1_rec.MEALCODE)
      LOOP
         --        DBMS_OUTPUT.put_line('IN' ||  c1_rec.FLTNUM|| '-'|| c1_rec.FLTDATE|| '-'|| c1_rec.ROUTE
         --                                  || '-'|| c1_rec.COS|| '-'|| c1_rec.MEALCODE|| '-'|| c1_rec.COUNT);
         DBMS_OUTPUT.put_line(   'IN'
                              || c2_rec.SLDBLFLT
                              || '-'
                              || c2_rec.SLDBLDATE
                              || '-'
                              || c2_rec.SLMUFC01
                              || '-'
                              || c2_rec.SLSPML01
                              || '-'
                              || c2_rec.SLAN01);

         UPDATE   f550040b
            SET   SLAN01 = c1_rec.COUNT
          WHERE   CURRENT OF c2;

         v_done := 1;
      END LOOP;

      /*   exception
            when others then
                  dbms_output.put_line('Error: '||sqlerrm);
      end;*/
      IF v_done = 0
      THEN
         DBMS_OUTPUT.put_line ('Insert');

         INSERT INTO f550040b (
                                  SLDBLFLT,
                                  SLDBLDATE,
                                  SLDBLALPH,
                                  SLMUFC01,
                                  SLSPML01,
                                  SLAN01,
                                  SLUSER,
                                  SLUPMJ,
                                  SLUPMT
                    )
           VALUES   (
                        'QR' || SUBSTR (c1_rec.FLTNUM, 2),
                        c1_rec.FLTDATE,
                        c1_rec.ROUTE,
                        c1_rec.COS,
                        c1_rec.MEALCODE,
                        c1_rec.COUNT,
                        'DCS',
                        date2jde (SYSDATE),
                        date2jde(TO_DATE (TO_CHAR (SYSDATE, 'hh24:mi:ss'),
                                          'hh24:mi:ss'))
                    );
      ELSE
         v_done := 0;
      END IF;
   END LOOP;
END;
/