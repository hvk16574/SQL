  SELECT frt.responsibility_name,
         frg.request_group_name,
         frgu.request_unit_type,
         frgu.request_unit_id,
         fcpt.user_concurrent_program_name
    FROM fnd_Responsibility fr,
         fnd_responsibility_tl frt,
         fnd_request_groups frg,
         fnd_request_group_units frgu,
         fnd_concurrent_programs_tl fcpt
   WHERE     frt.responsibility_id = fr.responsibility_id
         AND frg.request_group_id = fr.request_group_id
         AND frgu.request_group_id = frg.request_group_id
         AND fcpt.concurrent_program_id = frgu.request_unit_id
         AND fcpt.user_concurrent_program_name = '&conc_program_name'
ORDER BY 1,         2,         3,         4

SELECT RG.APPLICATION_ID "Request Group Application ID",
       RG.REQUEST_GROUP_ID "Request Group - Group ID",
       RG.REQUEST_GROUP_NAME,
       RG.DESCRIPTION,
       RGU.UNIT_APPLICATION_ID,
       RGU.REQUEST_UNIT_ID,
       RGU.REQUEST_GROUP_ID "Request Group Unit - Group ID",
       RGU.REQUEST_UNIT_ID,
       CP.CONCURRENT_PROGRAM_ID,
       CP.CONCURRENT_PROGRAM_NAME,
       CPT.USER_CONCURRENT_PROGRAM_NAME,
       DECODE (RGU.REQUEST_UNIT_TYPE,  'P', 'Program',  'S', 'Set',  RGU.REQUEST_UNIT_TYPE) "Unit Type"
  FROM FND_REQUEST_GROUPS RG,
       FND_REQUEST_GROUP_UNITS RGU,
       FND_CONCURRENT_PROGRAMS CP,
       FND_CONCURRENT_PROGRAMS_TL CPT
 WHERE     RG.REQUEST_GROUP_ID = RGU.REQUEST_GROUP_ID
       AND RGU.REQUEST_UNIT_ID = CP.CONCURRENT_PROGRAM_ID
       AND CP.CONCURRENT_PROGRAM_ID = CPT.CONCURRENT_PROGRAM_ID
       AND CPT.USER_CONCURRENT_PROGRAM_NAME = 'Workflow Background Process';

SELECT responsibility_name
  FROM fnd_responsibility_tl rsp_tl,
       fnd_responsibility fr,                                                                                                                                                  --fnd_request_groups frg,
       fnd_request_group_units frgu,
       fnd_concurrent_programs_tl fcpt
 WHERE rsp_tl.responsibility_id = fr.responsibility_id --and frg.request_group_id = fr.request_group_id
       AND fr.request_group_id = frgu.request_group_id AND fcpt.concurrent_program_id = frgu.request_unit_id AND UPPER (fcpt.USER_CONCURRENT_PROGRAM_NAME) = UPPER ('Workflow Background Process');
       
         SELECT frv.responsibility_name, frg.request_group_name, frg.description
    FROM fnd_request_groups frg, fnd_responsibility_vl frv
   WHERE frv.request_group_id = frg.request_group_id
         AND frg.request_group_name IN
                (SELECT DISTINCT frg.request_group_name
                   FROM fnd_Responsibility fr,
                        fnd_responsibility_tl frt,
                        fnd_request_groups frg,
                        fnd_request_group_units frgu,
                        fnd_concurrent_programs_tl fcpt
                  WHERE     frt.responsibility_id = fr.responsibility_id
                        AND frg.request_group_id = fr.request_group_id
                        AND frgu.request_group_id = frg.request_group_id
                        AND fcpt.concurrent_program_id = frgu.request_unit_id
                        AND fcpt.user_concurrent_program_name = 'Workflow Background Process')
ORDER BY responsibility_name;