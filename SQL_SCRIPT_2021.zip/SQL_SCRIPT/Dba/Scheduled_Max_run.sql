BEGIN
   DBMS_SCHEDULER.add_event_queue_subscriber ('LenelAgent');
END;
/

CREATE OR REPLACE PROCEDURE max_shooter_proc (
   MESSAGE IN SYS.scheduler$_event_info)
AS
BEGIN
   -- if this is not a JOB_OVER_MAX_DUR message, error out
   IF MESSAGE.event_type != 'JOB_OVER_MAX_DUR'
   THEN
      RAISE PROGRAM_ERROR;
   END IF;

   -- stop the job
   DBMS_SCHEDULER.stop_job (
      '"' || MESSAGE.object_owner || '"."' || MESSAGE.object_name || '"');
END;
/

BEGIN
   DBMS_SCHEDULER.create_program (program_name          => 'max_shooter_prog',
                                  program_action        => 'max_shooter_proc',
                                  program_type          => 'stored_procedure',
                                  number_of_arguments   => 1,
                                  enabled               => FALSE);

   DBMS_SCHEDULER.define_metadata_argument ('max_shooter_prog',
                                            'event_message',
                                            1);
   DBMS_SCHEDULER.enable ('max_shooter_prog');
END;
/

BEGIN
   DBMS_SCHEDULER.create_job (
      'max_shooter_job',
      program_name      => 'max_shooter_prog',
      event_condition   => 'tab.user_data.event_type = ''JOB_OVER_MAX_DUR''',
      queue_spec        => 'sys.scheduler$_event_queue,LenelAgent',
      enabled           => TRUE);
END;
/


BEGIN
   DBMS_SCHEDULER.set_attribute ('LENEL_MASTER_UPDATE',
                                 'max_run_duration',
                                 INTERVAL '10' MINUTE);
END;
/