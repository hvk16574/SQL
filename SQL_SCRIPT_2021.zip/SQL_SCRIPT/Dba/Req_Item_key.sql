SELECT wf_item_key
  FROM po_requisition_headers_all
 WHERE segment1 = :req_no