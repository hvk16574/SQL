-- Requisition
select wf_item_type ,wf_item_key,ORG_ID, AUTHORIZATION_STATUS from po_requisition_headers_all where segment1 = :Req_no;

update po_requisition_headers_all set AUTHORIZATION_STATUS = 'INCOMPLETE' where segment1 = :Req_no;

-- PO
select wf_item_type, wf_item_key,ORG_ID, AUTHORIZATION_STATUS from po_headers_all where segment1 = :Po_no;

update po_headers_all set AUTHORIZATION_STATUS = 'INCOMPLETE' where segment1 = :Po_no;


delete from ra_interface_lines_all where INTERFACE_LINE_CONTEXT = 'FALCON';

delete from ra_interface_distributions_all where INTERFACE_LINE_CONTEXT = 'FALCON';

truncate table qr_rapid.qr_fal_ar_lines_temp;

truncate table qr_rapid.qr_fal_ar_header_temp;
 
