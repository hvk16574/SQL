CREATE TABLE SYS.AUDIT_IP_EXP
(
  HOST_NAME   VARCHAR2(64 BYTE),
  IP_ADDRESS  VARCHAR2(32 BYTE)
)
TABLESPACE QRDBA;

CREATE TABLE SYSTEM.AUDIT_IP_H
(
  IPADRS_FRM  NUMBER,
  IPADRS_TO   NUMBER,
  OPER        VARCHAR2(1 BYTE),
  USER_NAME   VARCHAR2(30 BYTE),
  IP_ADDRESS  VARCHAR2(100 BYTE),
  OS_USER     VARCHAR2(30 BYTE),
  MODULE      VARCHAR2(200 BYTE),
  LOGON_DATE  DATE
)
TABLESPACE QRDBA;

CREATE OR REPLACE SYNONYM SYS.AUDIT_IP_H FOR SYSTEM.AUDIT_IP_H;


CREATE TABLE SYSTEM.AUDIT_IP
(
  IPADRS_FRM  NUMBER,
  IPADRS_TO   NUMBER
)
TABLESPACE QRDBA;


CREATE OR REPLACE TRIGGER SYSTEM.AUDIT_IP_H_TRG AFTER INSERT OR DELETE OR UPDATE ON "SYSTEM"."AUDIT_IP" FOR EACH ROW
DECLARE
   VOPER   VARCHAR2 (1) := NULL;
BEGIN
   IF INSERTING THEN   VOPER := 'I';
   ELSIF UPDATING THEN VOPER := 'U';
   ELSE                VOPER := 'D';
   END IF;

   IF INSERTING THEN INSERT INTO AUDIT_IP_H VALUES (:new.IPADRS_FRM,:new.IPADRS_TO,VOPER,SYS_CONTEXT ('USERENV', 'SESSION_USER'),NVL (SYS_CONTEXT ('USERENV', 'IP_ADDRESS'),SYS_CONTEXT ('USERENV', 'HOST')),SYS_CONTEXT ('USERENV', 'OS_USER'),SYS_CONTEXT ('USERENV', 'MODULE'),SYSDATE);
   ELSIF UPDATING OR DELETING THEN INSERT INTO AUDIT_IP_H VALUES (:old.IPADRS_FRM,:old.IPADRS_TO,VOPER,SYS_CONTEXT ('USERENV', 'SESSION_USER'),NVL (SYS_CONTEXT ('USERENV', 'IP_ADDRESS'),SYS_CONTEXT ('USERENV', 'HOST')),SYS_CONTEXT ('USERENV', 'OS_USER'),SYS_CONTEXT ('USERENV', 'MODULE'),SYSDATE);
   END IF;
END;
/


CREATE OR REPLACE SYNONYM SYS.AUDIT_IP FOR SYSTEM.AUDIT_IP;


CREATE TABLE SYS.IP_AUDIT
(
   USER_NAME    VARCHAR2 (30 BYTE),
   IP_ADDRESS   VARCHAR2 (100 BYTE),
   OS_USER      VARCHAR2 (30 BYTE),
   MODULE       VARCHAR2 (200 BYTE),
   LOGON_DATE   DATE,
   RESULT       VARCHAR2 (1 BYTE),
   RANGE_FRM    NUMBER,
   RANGE_TO     NUMBER
)
TABLESPACE QRDBA
PARTITION BY RANGE (LOGON_DATE)
   INTERVAL ( NUMTOYMINTERVAL (1, 'MONTH') )
   (PARTITION IP_AUDIT_X_1 VALUES LESS THAN(TO_DATE (' 2007-07-01 00:00:00','SYYYY-MM-DD HH24:MI:SS','NLS_CALENDAR=GREGORIAN')) TABLESPACE QRDBA);

CREATE OR REPLACE TRIGGER SYS.AUDIT_IP_TRG
   AFTER LOGON
   ON DATABASE
DECLARE
   PRAGMA AUTONOMOUS_TRANSACTION;
   allow      NUMBER;
   v_adrs     NUMBER;
   v_adrsto   NUMBER;
   V_IP       NUMBER;
   v_ipadrs   VARCHAR2 (50);
   v_hname    VARCHAR2 (80);
BEGIN
   --v_ipadrs := nvl(SYS_CONTEXT ('USERENV', 'IP_ADDRESS'),UTL_INADDR.get_host_address(SYS_CONTEXT ('USERENV', 'HOST')));
   v_hname := (SYS_CONTEXT ('USERENV', 'HOST'));
--   v_ipadrs := NVL ( SYS_CONTEXT ('USERENV', 'IP_ADDRESS'), UTL_INADDR.get_host_address ( SUBSTR (v_hname, INSTR (v_hname, '\', 1) + 1)));
   BEGIN
      SELECT NVL ( SYS_CONTEXT ('USERENV', 'IP_ADDRESS'), UTL_INADDR.get_host_address ( SUBSTR (v_hname, INSTR (v_hname, '\', 1) + 1))) INTO v_ipadrs FROM DUAL;
   EXCEPTION
      WHEN OTHERS THEN
         IF SQLCODE = '-29257' THEN
            SELECT IP_ADDRESS INTO V_IPADRS FROM AUDIT_IP_EXP WHERE upper(HOST_NAME) = upper(v_hname);
         END IF;
   END;

   select trim(substr(v_ipadrs,1,instr(v_ipadrs,'.',1)-1))||
          lpad(trim(substr(v_ipadrs, instr(v_ipadrs,'.',1,1)+1 ,instr(v_ipadrs,'.',1,2)-instr(v_ipadrs,'.',1,1)-1)),3,'0')||
          lpad(trim(substr(v_ipadrs, instr(v_ipadrs,'.',1,2)+1 ,instr(v_ipadrs,'.',1,3)-instr(v_ipadrs,'.',1,2)-1)),3,'0')||
          lpad(trim(substr(v_ipadrs, instr(v_ipadrs,'.',1,3)+1 , 3)),3,'0') as V_RSLT
   INTO V_IP FROM DUAL;


   SELECT COUNT (1), MIN (IPADRS_FRM), MAX (IPADRS_TO)
     INTO allow, v_adrs, v_adrsto
     FROM audit_ip
    WHERE V_IP BETWEEN IPADRS_FRM AND IPADRS_TO;

   IF allow = 0
   THEN
      INSERT INTO IP_AUDIT VALUES (SYS_CONTEXT ('USERENV', 'SESSION_USER'), nvl(SYS_CONTEXT ('USERENV', 'IP_ADDRESS'),SYS_CONTEXT ('USERENV', 'HOST')), SYS_CONTEXT ('USERENV', 'OS_USER'), SYS_CONTEXT ('USERENV', 'MODULE'), SYSDATE,'E',v_adrs,v_adrsto);
      COMMIT;
--      RAISE_APPLICATION_ERROR(-20003,'You are not allowed to connect to the database');
   ELSE
      INSERT INTO IP_AUDIT VALUES (SYS_CONTEXT ('USERENV', 'SESSION_USER'), nvl(SYS_CONTEXT ('USERENV', 'IP_ADDRESS'),SYS_CONTEXT ('USERENV', 'HOST')), SYS_CONTEXT ('USERENV', 'OS_USER'), SYS_CONTEXT ('USERENV', 'MODULE'), SYSDATE,'S', v_adrs,v_adrsto );
      COMMIT;
   END IF;
END;
/


SELECT    TO_NUMBER (SUBSTR (LPAD (ipadrs_frm, 12, '0'), 1, 3))|| '.'|| 
          TO_NUMBER (SUBSTR (LPAD (ipadrs_frm, 12, '0'), 4, 3))|| '.'|| 
          TO_NUMBER (SUBSTR (LPAD (ipadrs_frm, 12, '0'), 7, 3))|| '.'|| 
          TO_NUMBER (SUBSTR (LPAD (ipadrs_frm, 12, '0'), 10)) ipstart,
          CASE WHEN ipadrs_to - ipadrs_frm > 0 THEN
          TO_NUMBER (SUBSTR (LPAD (ipadrs_to, 12, '0'), 1, 3))|| '.'|| 
          TO_NUMBER (SUBSTR (LPAD (ipadrs_to, 12, '0'), 4, 3))|| '.'|| 
          TO_NUMBER (SUBSTR (LPAD (ipadrs_to, 12, '0'), 7, 3))|| '.'|| 
          TO_NUMBER (SUBSTR (LPAD (ipadrs_to, 12, '0'), 10)) else null end  ipend,
       CASE WHEN ipadrs_to - ipadrs_frm > 0 THEN 'Range ' ELSE 'Single' END Category
  FROM sys.audit_ip
  order by 3, 1