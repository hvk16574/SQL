CREATE USER sysadm_query IDENTIFIED BY sysadmquery
DEFAULT TABLESPACE users
TEMPORARY TABLESPACE temp
PROFILE DEFAULT;

GRANT CONNECT TO sysadm_query;

SELECT    'grant select on ' || object_name || ' to sysadm_query;' || CHR (10) || 'create synonym sysadm_query.' || object_name || ' for sysadm.' || object_name || ';'
  FROM dba_objects
 WHERE owner = 'SYSADM' AND object_type NOT IN        ('INDEX', 'TRIGGER', 'SYNONYM', 'LOB', 'DATABASE LINK')
 and object_name not like '%$%';