select * from fnd_user where user_name = '10000'

select * from fnd_user_hk where user_name = '10000'

truncate table fnd_user_hk;

insert into fnd_user_hk select * from fnd_user where user_name = '10000';


insert into fnd_user select * from fnd_user_hk where user_name = '10000';