BEGIN
  DBMS_NETWORK_ACL_ADMIN.create_acl (
    acl          => 'mailserver.xml', 
    description  => 'Mailserver',
    principal    => 'PRODDTA',
    is_grant     => TRUE, 
    privilege    => 'connect',
    start_date   => SYSTIMESTAMP,
    end_date     => NULL);

  COMMIT;
END;
/


BEGIN
  DBMS_NETWORK_ACL_ADMIN.assign_acl (
    acl         => 'mailserver.xml',
    host        => 'qrsmtp.qatarairways.com.qa', 
    lower_port  => 25,
    upper_port  => NULL); 
  COMMIT;
END;
/


SELECT * --host, lower_port, upper_port, acl
FROM   dba_network_acls;

SELECT acl,
       principal,
       privilege,
       is_grant,
       TO_CHAR(start_date, 'DD-MON-YYYY') AS start_date,
       TO_CHAR(end_date, 'DD-MON-YYYY') AS end_date
FROM   dba_network_acl_privileges;


SELECT dna.acl, dna.HOST, dnap.principal,
       DECODE ( DBMS_NETWORK_ACL_ADMIN.check_privilege_aclid (dna.aclid,dnap.principal, 'connect'), 1, 'GRANTED', 0, 'DENIED', NULL) privilege
  FROM dba_network_acls dna, dba_network_acl_privileges dnap
 WHERE dna.aclid = dnap.aclid;
 
 
 
BEGIN
  DBMS_NETWORK_ACL_ADMIN.delete_privilege ( 
    acl         => 'mailserver.xml', 
    principal   => 'APPS',
    is_grant    => TRUE, 
    privilege   => 'connect');
  COMMIT;
END;
/ 


BEGIN
  DBMS_NETWORK_ACL_ADMIN.add_privilege ( 
    acl         => 'mailserver.xml', 
    principal   => 'QR_MAPP',
    is_grant    => TRUE, 
    privilege   => 'connect');
  COMMIT;
END;
/ 