DECLARE
    vmonth    NUMBER := &vmonth;
    vyear     NUMBER := &vyear;
    vtsname   VARCHAR2 (50) := '&vtsname';
    CURSOR c1 IS WITH d AS (SELECT TRUNC (TO_DATE ('01-' || vmonth || '-' || vyear, 'dd-mm-yyyy'), 'MM') - 1 AS dt FROM DUAL)
            SELECT    'max(decode(to_char(cr_date,''DD-MM-YYYY''),''' || TO_CHAR ((dt + LEVEL), 'dd-mm-yyyy')
            || ''',size_mb)) "' || TO_CHAR ((dt + LEVEL), 'ddmon') || '" ,' SizeMB, '(max(decode(to_char(cr_date,''DD-MM-YYYY''),'''
            || TO_CHAR ((dt + LEVEL), 'dd-mm-yyyy') || ''',size_mb)) - ' || 'max(decode(to_char(cr_date,''DD-MM-YYYY''),'''
            || TO_CHAR ((dt + LEVEL) - 1, 'dd-mm-yyyy') || ''',size_mb))) "growth-' || TO_CHAR ((dt + LEVEL), 'ddmon') || '" ,'  Growth
            FROM d
            CONNECT BY LEVEL <= ADD_MONTHS (dt, 1) - dt;
    c1rec     c1%ROWTYPE;
BEGIN
    OPEN c1;
    DBMS_OUTPUT.put_line ('select segment_name,');
    LOOP
        FETCH c1 INTO c1rec;
        EXIT WHEN c1%NOTFOUND;
        DBMS_OUTPUT.put_line (c1rec.sizeMB || c1rec.growth);
    END LOOP;
    CLOSE c1;
    DBMS_OUTPUT.put_line (' '''' from DBREPORT.QRDBA_SEGMENT_SIZE
 where tablespace_name = ''' || VTSNAME || '''
 group by segment_name;');
END;
/