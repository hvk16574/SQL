select distinct 'Insert into FND_USER_PREFERENCES Values (''' || RECIPIENT_ROLE|| ''', ''WF'', ''MAILTYPE'', ''MAILHTML'');' from wf_notifications 
 WHERE TRUNC (BEGIN_DATE) >= TRUNC (SYSDATE) - 1 
union 
select distinct 'UPDATE   FND_USER_PREFERENCES  SET   PREFERENCE_VALUE = ''MAILHTML'' WHERE USER_NAME = '''
         || RECIPIENT_ROLE || ''' AND MODULE_NAME = ''WF''AND PREFERENCE_NAME = ''MAILTYPE'';' 
from wf_notifications 
 WHERE TRUNC (BEGIN_DATE) >= TRUNC (SYSDATE) - 1          
union 
SELECT distinct 
       'UPDATE WF_LOCAL_ROLES SET notification_preference = ''MAILHTML'' WHERE name = ''' || RECIPIENT_ROLE || ''';'
from wf_notifications 
 WHERE TRUNC (BEGIN_DATE) >= TRUNC (SYSDATE) - 1;
 
 
 
select * from wf_notifications 
 WHERE TRUNC (BEGIN_DATE) >= TRUNC (SYSDATE) - 2; 
 
 
 
 select * from wf_notifications 
