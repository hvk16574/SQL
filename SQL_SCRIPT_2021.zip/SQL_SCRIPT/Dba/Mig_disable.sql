select user_name,end_date,description from fnd_user
where user_name not in (
select a from c );




update fnd_user
set end_date=(sysdate -1),description='Migration Disable'
where user_name not in (
select a from c )