select * from wf_all_user_roles where  trunc(creation_date) = trunc(sysdate) and ROLE_NAME = 'FND_RESP|PER|QR_UNIFORM_REQUISITIONS|STANDARD'

select * from wf_all_user_roles where  trunc(creation_date) = trunc(sysdate) and ROLE_NAME = 'FND_RESP800:53678'

select * from wf_user_role_assignments where trunc(creation_date) = trunc(sysdate) and ROLE_NAME = 'FND_RESP|PER|QR_UNIFORM_REQUISITIONS|STANDARD'

select * from wf_user_role_assignments where trunc(creation_date) = trunc(sysdate) and ROLE_NAME = 'FND_RESP800:53678'



delete from wf_all_user_roles where  trunc(creation_date) = trunc(sysdate) and ROLE_NAME = 'FND_RESP|PER|QR_UNIFORM_REQUISITIONS|STANDARD'

delete from wf_all_user_roles where  trunc(creation_date) = trunc(sysdate) and ROLE_NAME = 'FND_RESP800:53678'

delete from wf_user_role_assignments where trunc(creation_date) = trunc(sysdate) and ROLE_NAME = 'FND_RESP|PER|QR_UNIFORM_REQUISITIONS|STANDARD'

delete from wf_user_role_assignments where trunc(creation_date) = trunc(sysdate) and ROLE_NAME = 'FND_RESP800:53678'