DECLARE
   CURSOR c1 IS
      SELECT PARTITION_NAME,high_value FROM  dba_tab_partitions WHERE table_name = 'IP_AUDIT';
   c1rec c1%ROWTYPE;
   vhigh varchar2(32767);
BEGIN
   dbms_output.put_line('Select * from (');
   OPEN c1;
   LOOP
      FETCH c1 INTO c1rec;
      vhigh := c1rec.high_value;
      vhigh := substr(vhigh,11,10);
      if ( to_date(vhigh,'YYYY-MM-DD') >= sysdate-380 ) then 
      dbms_output.put_line('Select user_name,ip_address From sys.ip_audit partition ('||c1rec.PARTITION_NAME||') Where result = ''S'' Group by user_name,ip_address');
      dbms_output.put_line('Union');
      end if;
      EXIT WHEN c1%NOTFOUND;
   END LOOP;
   dbms_output.put_line(')');
   CLOSE c1;
END;