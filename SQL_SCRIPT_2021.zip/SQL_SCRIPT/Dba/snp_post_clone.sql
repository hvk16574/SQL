  -- +==========================================================================+
  -- |                            QATAR AIRWAYS                                 |
  -- |                                                                          |
  -- +==========================================================================+
  -- |Script            : SNP_POST_CLONE                                        |
  -- |Description       : Post clone script to mask sniper hire access details. |
  -- |                                                                          |
  -- |Change Record:                                                            |
  -- |===============                                                           |
  -- |Version   Date         Author               Remarks                       |
  -- |=======   ==========   =============        ==============================|
  -- | V1.0     24-Oct-2013  Manjunath Bennur     Intial Draft                  |
  -- +==========================================================================+

UPDATE FND_LOOKUP_VALUES
SET LOOKUP_CODE='X'
  ||LOOKUP_CODE
  ||'X',
  MEANING='X'
  ||MEANING
  ||'X',
  ENABLED_FLAG   ='N'
WHERE LOOKUP_TYPE='QAG_SNP_USER';

UPDATE FND_LOOKUP_VALUES
SET LOOKUP_CODE='X'
  ||LOOKUP_CODE
  ||'X',
  MEANING='X'
  ||MEANING
  ||'X',
  ENABLED_FLAG   ='N'
WHERE LOOKUP_TYPE='QAG_SNP_USER_SRF';
UPDATE FND_LOOKUP_VALUES
SET LOOKUP_CODE='X'
  ||LOOKUP_CODE
  ||'X',
  MEANING='X'
  ||MEANING
  ||'X',
  ENABLED_FLAG   ='N'
WHERE LOOKUP_TYPE='QAG_SNP_FEED_ID';

UPDATE FND_CONCURRENT_PROGRAMS
SET SRS_FLAG                   ='N',
  ENABLED_FLAG                 ='N'
WHERE CONCURRENT_PROGRAM_NAME IN ('QAGSNPAPPL_NEW','QAGSNPAPPL','QAGSNPSRFR_NEW','QAGSNPSRFR','QAGSNPHIREEXTRA','QAGSNPHIRE','QAGSNPSRF','QAGSNPSRF_NEW');

commit;
