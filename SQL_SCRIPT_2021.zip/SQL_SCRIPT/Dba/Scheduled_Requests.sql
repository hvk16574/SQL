SELECT   /*+   */
         program_short_name, argument_text, parent_request_id,
         last_update_date, last_updated_by, requested_by, has_sub_request,
         is_sub_request, last_update_login, priority_request_id, enabled,
         requested_start_date, request_id, program, requestor, priority
    FROM fnd_conc_req_summary_v
   WHERE phase_code = 'P'
     AND status_code IN ('I', 'Q')
     AND (NVL (request_type, 'X') != 'S')
     AND (TRUNC (request_date) >= TRUNC (SYSDATE - 7))
ORDER BY requestor DESC