col server_name format a12
col user_name format a30
select
  to_char(first_connect, 'HH24:MI:SS') "TIME",
  user_name,
  decode
   (a.node_id,
   a.node_id,
   (select node_name  
   from fnd_nodes n  
   where a.node_id=n.node_id),a.node_id) server_name
from
  icx_sessions a,
  fnd_user b,
  fnd_nodes svr
where
  first_connect > (sysdate-1/24)
  and (a.user_id=b.user_id
       and a.node_id=svr.node_id)
  and disabled_flag='N'
order by first_connect;