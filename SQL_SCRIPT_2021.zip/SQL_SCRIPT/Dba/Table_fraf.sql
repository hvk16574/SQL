select owner,table_name,avg_row_len,round(((blocks*16/1024)),2)||'MB' "TOTAL_SIZE",
round((num_rows*avg_row_len/1024/1024),2)||'Mb' "ACTUAL_SIZE",
round(((blocks*16/1024)-(num_rows*avg_row_len/1024/1024)),2) ||'MB' "FRAGMENTED_SPACE"
,(round(((blocks*16/1024)-(num_rows*avg_row_len/1024/1024)),2)/decode(round(((blocks*16/1024)),2),0,1,round(((blocks*16/1024)),2)))*100 "percentage"
from dba_tables 
where round(((blocks*16/1024)),2) > 0
and table_name = 'XLA_GLT_21037028'
order by 7 desc;