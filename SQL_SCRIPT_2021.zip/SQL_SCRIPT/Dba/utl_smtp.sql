grant execute on  DBMS_NETWORK_ACL_ADMIN to apps;

CREATE OR REPLACE PROCEDURE apps.mailserver_acl (aacl          VARCHAR2,
                                                    acomment      VARCHAR2,
                                                    aprincipal    VARCHAR2,
                                                    aisgrant      BOOLEAN,
                                                    aprivilege    VARCHAR2,
                                                    aserver       VARCHAR2,
                                                    aport         NUMBER)
IS
BEGIN
   BEGIN
      DBMS_NETWORK_ACL_ADMIN.DROP_ACL (aacl);
      DBMS_OUTPUT.put_line ('ACL dropped...');
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line ('Error dropping ACL: ' || aacl);
         DBMS_OUTPUT.put_line (SQLERRM);
   END;

   BEGIN
      DBMS_NETWORK_ACL_ADMIN.CREATE_ACL (aacl,
                                         acomment,
                                         aprincipal,
                                         aisgrant,
                                         aprivilege);
      DBMS_OUTPUT.put_line ('ACL created...');
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line ('Error creating ACL: ' || aacl);
         DBMS_OUTPUT.put_line (SQLERRM);
   END;

   BEGIN
      DBMS_NETWORK_ACL_ADMIN.ASSIGN_ACL (aacl, aserver, aport);
      DBMS_OUTPUT.put_line ('ACL assigned...');
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line ('Error assigning ACL: ' || aacl);
         DBMS_OUTPUT.put_line (SQLERRM);
   END;

   COMMIT;
   DBMS_OUTPUT.put_line ('ACL commited...');
END;
/

BEGIN
   apps.mailserver_acl ('mailserver_acl.xml',
                           'ACL for used Email Server to connect',
                           'APPS',
                           TRUE,
                           'connect',
                           'qrsmtp.qatarairways.com.qa',
                           25);
END;
/

BEGIN
   DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE ('mailserver_acl.xml',
                                         'APPS',
                                         TRUE,
                                         'connect');
   COMMIT;
END;
/


--================================================================================================
CREATE OR REPLACE PROCEDURE proddta.mailserver_acl (aacl          VARCHAR2,
                                                    acomment      VARCHAR2,
                                                    aprincipal    VARCHAR2,
                                                    aisgrant      BOOLEAN,
                                                    aprivilege    VARCHAR2,
                                                    aserver       VARCHAR2,
                                                    aport         NUMBER)
IS
BEGIN
   BEGIN
      DBMS_NETWORK_ACL_ADMIN.DROP_ACL (aacl);
      DBMS_OUTPUT.put_line ('ACL dropped�..');
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line ('Error dropping ACL: ' || aacl);
         DBMS_OUTPUT.put_line (SQLERRM);
   END;

   BEGIN
      DBMS_NETWORK_ACL_ADMIN.CREATE_ACL (aacl,
                                         acomment,
                                         aprincipal,
                                         aisgrant,
                                         aprivilege);
      DBMS_OUTPUT.put_line ('ACL created�..');
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line ('Error creating ACL: ' || aacl);
         DBMS_OUTPUT.put_line (SQLERRM);
   END;

   BEGIN
      DBMS_NETWORK_ACL_ADMIN.ASSIGN_ACL (aacl, aserver, aport);
      DBMS_OUTPUT.put_line ('ACL assigned�..');
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line ('Error assigning ACL: ' || aacl);
         DBMS_OUTPUT.put_line (SQLERRM);
   END;

   COMMIT;
   DBMS_OUTPUT.put_line ('ACL commited�..');
END;
/

BEGIN
   proddta.mailserver_acl ('mailserver_acl.xml',
                           'ACL for used Email Server to connect',
                           'PRODDTA',
                           TRUE,
                           'connect',
                           'qrsmtp.qatarairways.com.qa',
                           25);
END;
/

BEGIN
   DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE ('mailserver_acl.xml',
                                         'PRODDTA',
                                         TRUE,
                                         'connect');
   COMMIT;
END;
/

-------------------------------------------------------------------------------
select A.OBJECT_ID, ANY_PATH, xdburitype(ANY_PATH).getclob() content, R.* 
 from RESOURCE_VIEW, XDB.XDB$ACL A,
      XMLTABLE(
        xmlNamespaces(
          default 'http://xmlns.oracle.com/xdb/XDBResource.xsd'
        ),
        '$RES/Resource'
        passing RES as "RES"
        COLUMNS
        OWNER               PATH 'Owner',
        CREATOR             PATH 'Creator',
        DATE_CREATED        PATH 'CreationDate',
        MODIFIER            PATH 'LastModifier',
        DATE_LAST_MODIFIED  PATH 'ModificationDate'
      ) R
where ref(A) = XMLCast(
                 XMLQuery(
                   'declare default element namespace "http://xmlns.oracle.com/xdb/XDBResource.xsd"; (: :)
                    fn:data($RES/Resource/XMLRef)'
                    passing RES as "RES"
                    returning content
                 ) as REF XMLType
               );