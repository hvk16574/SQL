SELECT name, 'WLR', notification_preference FROM wf_local_roles WHERE     name = LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0') AND user_flag = 'Y'
UNION
SELECT user_name, 'FUP', preference_value FROM fnd_user_preferences WHERE     module_name = 'WF' AND preference_name = 'MAILTYPE' AND user_name = LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0');

UPDATE wf_local_roles SET notification_preference = 'MAILHTML' WHERE     name = LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0') AND user_flag = 'Y';

UPDATE fnd_user_preferences SET preference_value = 'MAILHTML' WHERE     module_name = 'WF' AND preference_name = 'MAILTYPE' AND user_name = LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0');

-------------------------------------------------------------------------------

SELECT name, nvl(WF_PREF.get_pref(name, 'MAILTYPE'), notification_preference)
         FROM wf_roles
         where name = :emp_no
         
         
select notification_preference from wf_local_roles
where name = :emp_no
union all
select preference_value from fnd_user_preferences
where module_name = 'WF'
and user_name = :emp_no
and preference_name = 'MAILTYPE'




update wf_local_roles
set notification_preference = 'MAILHTML'
where user_flag='Y'

 

2.
update fnd_user_preferences
set preference_value = 'MAILHTML'
where module_name = 'WF'
and preference_name = 'MAILTYPE'





update wf_local_roles
set notification_preference='<wished_preference>'
where orig_system in ('FND_USR','PER');

 

b.
update fnd_user_preferences
set preference_value='<wished_preference>'
where preference_name='MAILTYPE'
and module_name='WF'
and user_name <> '-WF_DEFAULT-'; 

 

4. Updates for Users having the preference set to "Disabled" would look like:


a.
update wf_local_roles
set notification_preference='<wished_preference>'
where orig_system in ('FND_USR','PER')
and name in
(select user_name
from fnd_user_preferences
where preference_name='MAILTYPE'
and module_name='WF'
and preference_value='DISABLED');



b.
update fnd_user_preferences
set preference_value='<wished_preference>'
where preference_name='MAILTYPE'
and module_name='WF'
and preference_value='DISABLED';