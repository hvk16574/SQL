SELECT * FROM TABLE (GV$ (CURSOR ( SELECT i.instance_number,NVL (s.username, 'None') oracle_user, s.osuser client_user,
                         p.username unix_user, s.program, s.machine, TO_CHAR (s.sid) || ',' || TO_CHAR (s.serial#) AS sid_serial,
                         p.spid unix_pid, TO_CHAR (s.logon_time, 'mm/dd/yy hh24:mi:ss') AS login_time,
                         TO_CHAR (SYSDATE - (s.last_call_et) / 86400, 'mm/dd/yy hh24:mi:ss') AS last_txn,
                         t.used_ublk * TO_NUMBER (x.VALUE) / (1024 * 1024) AS undo_mb
                    FROM v$process p, v$session s, v$transaction t, v$parameter x, v$instance i
                   WHERE     s.taddr = t.addr
                         AND s.paddr = p.addr(+)
                         AND x.name = 'db_block_size')))
ORDER BY 11 DESC;

SELECT r.name rbs,
nvl(s.username, 'None') oracle_user,
s.osuser client_user,
p.username unix_user,
to_char(s.sid)||','||to_char(s.serial#) as sid_serial,
p.spid unix_pid,
TO_CHAR(s.logon_time, 'mm/dd/yy hh24:mi:ss') as login_time,
TO_CHAR(sysdate - (s.last_call_et) / 86400,'mm/dd/yy hh24:mi:ss') as last_txn,
t.used_ublk * TO_NUMBER(x.value)/(1024*1024) as undo_mb
FROM gv$process p,
v$rollname r,
gv$session s,
gv$transaction t,
gv$parameter x
WHERE s.taddr = t.addr
AND s.paddr = p.addr(+)
AND r.usn = t.xidusn(+)
AND x.name = 'db_block_size'
and s.inst_id = p.INST_ID
and p.inst_id = t.inst_id
and x.inst_id = p.inst_id
ORDER
BY 9 desc;