  SELECT isess.session_id, fu.user_name,
         DECODE (isess.disabled_flag, 'Y', 'Inactive', 'N', DECODE (SIGN (30 - (SYSDATE - isess.last_connect) * 24 * 60), -1, 'Inactive', 'Active'), isess.disabled_flag) A,
         isess.mode_code, isess.responsibility_id, frt.responsibility_name, isess.org_id, ood.organization_name,
         isess.function_id J, ffft.user_function_name, isess.first_connect, isess.last_connect,
         (isess.last_connect - isess.first_connect) * 24 * 60 * 60, isess.limit_time * 60 * 60,
         isess.counter, isess.limit_connects
    FROM icx.icx_sessions isess,
         applsys.fnd_responsibility_tl frt,
         applsys.fnd_form_functions_tl ffft,
         apps.org_organization_definitions ood,
         fnd_user fu
   WHERE     isess.responsibility_id = frt.responsibility_id(+)
         AND isess.responsibility_application_id = frt.application_id(+)
         AND frt.language(+) = USERENV ('LANG')
         AND isess.function_id = ffft.function_id(+)
         AND ffft.language(+) = USERENV ('LANG')
         AND isess.org_id = ood.organization_id(+)
         --    and isess.user_id = :UserID
         --    and isess.first_connect > trunc(sysdate - :days)
         AND (   (isess.function_id IS NOT NULL)
              OR (isess.function_id IS NULL AND isess.counter > 1))
         AND DECODE (isess.disabled_flag, 'Y', 'Inactive', 'N', DECODE ( SIGN (30 - (SYSDATE - isess.last_connect) * 24 * 60), -1, 'Inactive', 'Active'), isess.disabled_flag) = 'Active'
         AND fu.user_id = isess.user_id
         AND fu.user_name != 'GUEST'
ORDER BY isess.first_connect