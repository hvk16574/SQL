update mtl_material_transactions 
set costed_flag = null, 
error_code = null, 
error_explanation = null 
where costed_flag = 'E' 
and transaction_id in (31737607); 

