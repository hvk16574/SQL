<RULESET title="Variables and Data Structures" version="11.0">
<PROPERTIES>
<SUMMARY>
<RULESET_TYPE>Quest</RULESET_TYPE>
<AUTHOR>Quest Software</AUTHOR>
<CREATED>38069.5512658449</CREATED>
<MODIFIED>38071.6554581944</MODIFIED>
<COMMENTS>Rules in this set identify problems in the declaration or use of your program's variables and data structures.</COMMENTS>
<RULESET_TOTAL>37</RULESET_TOTAL>
</SUMMARY>
</PROPERTIES>
  <RULEFILTER>
    <CATEGORY cat="54" />
	<CATEGORY cat="64" />
  </RULEFILTER>
  <RULES>
    <RULE rid="*" />
  </RULES>
</RULESET>
