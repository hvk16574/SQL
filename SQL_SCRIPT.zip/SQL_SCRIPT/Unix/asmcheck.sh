#!/usr/bin/ksh
#!/bin/bash
UN=$(hostname)
ORACLE_HOME=/oracle/db/tech_st/10.2.0
LD_LIBRARY_PATH=$ORACLE_HOME/lib
PATH=$PATH:.:$ORACLE_HOME/bin
ELOG=$3
#1=No EMS Monitoring and 0=EMS Monitoring
ENABLE_EMS=0
MJ=$4
MI=$5
DGN=$6

SQL_TMP_FILE=/tmp/tmp$$
#sqlplus -s -l /nolog 1>${SQL_TMP_FILE}<<EOF
#connect / AS SYSDBA
sqlplus -s -l "qrnoc/qrnoc@"$1 1>${SQL_TMP_FILE}<<EOF
@/oracle/dbmgmt/scripts/asmcheck $DGN
exit
EOF

#DBA='hkhan@qatarairways.com.qa'
DBA='qrdbagroup@qatarairways.com.qa'
#MAILTO=hkhan@qatarairways.com.qa
#MAILTO=qrdbagroup@qatarairways.com.qa
MAILTO=itnocteam@qatarairways.com.qa
TMP_FILE=/tmp/tmp_df_$$
LOGDIR=/home/oraprod
#Subject: [$(uname -n)] Oracle ASM usage more 80% 
echo "From: oraprod
To: ${MAILTO}
Bcc: $DBA
Subject: Oracle ASM usage ALERT 
Mime-Version: 1.0
Content-Type: text/html
<table border>
<tr BGCOLOR="BLUE">" >> $TMP_FILE
#<tr BGCOLOR="#FF0000">" >> $TMP_FILE
#mailx -s 'Oracle ASM Alert - ['$UN']' hkhan@qatarairways.com.qa < ${SQL_TMP_FILE}
echo "<td>ASM Disk Group</td><td>Total Space (MB)</td><td>Used Space (MB)</td><td>Free Space (MB)</td><td>Used%</td><td>Free%</td><td>State</td></tr>" >> $TMP_FILE
cat ${SQL_TMP_FILE} | while read LINE
do
DG=$(echo $LINE | awk '{print $1}')
TS=$(echo $LINE | awk '{print $2}')
US=$(echo $LINE | awk '{print $3}')
FS=$(echo $LINE | awk '{print $4}')
PU=$(echo $LINE | awk '{print $6}')
PFP=$(echo $LINE | awk '{print $8}' )
PF=$(echo $LINE | awk '{print $8}' |cut -f1 -d. )
#echo $PF

#if [ $PF -lt $MJ ]
if [ $(echo $PF"<"$MJ|bc) -eq 1 ]
then
echo "<tr BGCOLOR="Red">" >> $TMP_FILE
AC="Critical"
echo "<td>"$DG"</td><td>"$TS"</td><td>"$US"</td><td>"$FS"</td><td>"$PU"</td><td>"$PFP"</td><td>"$AC"</td></tr>" >> $TMP_FILE
echo "<tr>ERROR: "$AC" Alert for ASM Diskgroup "$DG" Free : "$PFP"  Total Space (MB): "$TS" Free Space (MB): "$FS "</tr>" >> $TMP_FILE
if [ ${ENABLE_EMS} -eq 0 ]
then
echo "ERROR: "$AC" Alert for ASM Diskgroup "$DG" Free : "$PFP"%  Total Space (MB): "$TS" Free Space (MB): "$FS  >> $ELOG
fi
#elif [ $PF -ge $MJ -a $PF -lt $MI ]
elif [ $(echo $PF">="$MJ" && "$PF"<"$MI|bc) -eq 1 ]
then
echo "<tr BGCOLOR="Yellow">" >> $TMP_FILE
AC="Major"
echo "<td>"$DG"</td><td>"$TS"</td><td>"$US"</td><td>"$FS"</td><td>"$PU"</td><td>"$PFP"</td><td>"$AC"</td></tr>" >> $TMP_FILE
echo "ERROR: "$AC" Alert for ASM Diskgroup "$DG" Free : "$PFP"  Total Space (MB): "$TS" Free Space (MB): "$FS  >> $TMP_FILE
if [ ${ENABLE_EMS} -eq 0 ]
then
echo "ERROR: "$AC" Alert for ASM Diskgroup "$DG" Free : "$PFP"%  Total Space (MB): "$TS" Free Space (MB): "$FS  >> $ELOG
fi
#else
#echo "<tr BGCOLOR="Green">" >> $TMP_FILE
#AC="Information"
fi
done

echo "</tr></table>" >> $TMP_FILE
#cat $2
echo "<table>" >> $TMP_FILE
cat $2 >>  $TMP_FILE
#echo "<br>Major : "$MJ >> $TMP_FILE
#echo "<br>Minor : "$MI >> $TMP_FILE
#echo "<br>Logfile name: "$ELOG >> $TMP_FILE
echo "</tr></table>" >> $TMP_FILE

#cat $TMP_FILE
#wc -l  $TMP_FILE
#if [ $(wc -l < $TMP_FILE) -ge 17 ]
if [ $(wc -l < $TMP_FILE) -ge 16 ]
then
echo /usr/lib/sendmail -t -oi < $TMP_FILE
fi
rm $TMP_FILE $SQL_TMP_FILE
