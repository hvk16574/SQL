SELECT fu.user_name,
       fur.user_id,
       fu.description,
       fu.email_address,
       fur.start_date,
       fur.end_date
  FROM fnd_user_resp_groups fur,
       fnd_user fu
 WHERE fur.user_id = fu.user_id
   and fur.responsibility_application_id = :ApplicationID
   and fur.responsibility_id = :ResponsibilityID
   and (fur.end_date is null
       or fur.end_date > sysdate )
   and (fu.end_date is null
         or fu.end_date > sysdate )
 ORDER by fu.user_name
 
:APPLICATIONID = '200'
:RESPONSIBILITYID = '50414'

select * from fnd_RESPONSIBILITY_vl 
where RESPONSIBILITY_NAME LIKE '%AP%5'