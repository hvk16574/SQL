--insert into audit_ip values('10023150'||:lip,'10023150'||:lip);

CREATE TABLE SYSTEM.IP_AUDIT
(
   USER_NAME   VARCHAR2 (30),
   IP_ADDRESS   VARCHAR2 (20),
   OS_USER    VARCHAR2 (30),
   MODULE     VARCHAR2 (200),
   LOGNON_DATE    DATE
)
TABLESPACE QAIR
PARTITION BY RANGE (LOGNON_DATE)
--   INTERVAL ( NUMTODSINTERVAL (1, 'DAY') )
   ( PARTITION P1_29_04_2013 VALUES LESS THAN (TO_DATE ('2013-04-30 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')));


CREATE OR REPLACE TRIGGER SYSTEM.AUDIT_IP AFTER LOGON ON DATABASE
DECLARE
   PRAGMA AUTONOMOUS_TRANSACTION;
--CREATE OR REPLACE  PROCEDURE SYSTEM.ADD_PARTITION IS
BEGIN
   IF SYS_CONTEXT ('USERENV', 'IP_ADDRESS') NOT IN ('172.27.6.120','172.27.6.121','172.27.6.125','172.27.6.126','172.27.6.127','172.27.6.128','172.27.27.211',
                                                    '172.27.20.164','172.27.20.165','172.27.20.166','172.27.20.167','172.27.24.30','172.27.24.30','172.27.20.79') THEN
       INSERT INTO SYSTEM.IP_AUDIT
        VALUES (SYS_CONTEXT ('USERENV', 'SESSION_USER'), SYS_CONTEXT ('USERENV', 'IP_ADDRESS'), SYS_CONTEXT ('USERENV', 'OS_USER'), SYS_CONTEXT ('USERENV', 'MODULE'), SYSDATE);
       COMMIT;
   END IF;
   
   EXCEPTION WHEN OTHERS THEN
    NULL;
END;
/

select distinct user_name from system.ip_audit where ip_address like '10%'

select * from system.ip_audit where user_name in ('APPS','SYSTEM')

SELECT * FROM SYSTEM.IP_AUDIT ;

set pages 100
break on logon_date
SELECT trunc(logon_date) logon_date,IP_address,count(1) FROM SYSTEM.IP_AUDIT 
group by trunc(logon_date),ip_address
order by 1



CREATE OR REPLACE  procedure SYSTEM.add_partition
is
next_part varchar2(40);
less_than_char varchar2(20);
comando_add varchar2(1000);
BEGIN
select 'P'||to_char(to_number(substr(partition_name,2,instr(partition_name,'_',1)-2))+1)||'_'|| to_char(to_date(substr(partition_name, instr(partition_name,'_',1)+1),'dd_mm_yyyy')+1,'dd_mm_yyyy') PN,
         replace(to_char(to_date(substr(partition_name, instr(partition_name,'_',1)+1),'dd_mm_yyyy')+2,'dd_mm_yyyy'),'_','-') P
into next_part,less_than_char
--select *
from dba_tab_partitions
where table_owner = 'SYSTEM'
and table_name = 'IP_AUDIT'
and partition_position = (select max(partition_position)
from dba_tab_partitions where table_owner = 'SYSTEM'
and table_name = 'IP_AUDIT');

-- Builds the statement string
comando_add :=              'ALTER TABLE SYSTEM.IP_AUDIT ADD PARTITION '||next_part;
comando_add := comando_add||' VALUES LESS THAN (to_date('||chr(39)||less_than_char;
comando_add := comando_add||chr(39)||','||chr(39)||'dd-mm-yyyy'||chr(39)||')) TABLESPACE QAIR';
-- Executes the statement
execute immediate(comando_add);
--dbms_output.put_line(comando_add);
end;
/


select 
trunc(substr(lpad(IPADRS_FRM,12,'0'),1,3)) ||'.'|| 
trunc(substr(lpad(IPADRS_FRM,12,'0'),4,3)) ||'.'||
trunc(substr(lpad(IPADRS_FRM,12,'0'),7,3)) ||'.'||
trunc(substr(lpad(IPADRS_FRM,12,'0'),10,3)) ||
case 
when ipadrs_frm != ipadrs_to then ' - ' ||
trunc(substr(lpad(IPADRS_TO,12,'0'),1,3)) ||'.'|| 
trunc(substr(lpad(IPADRS_TO,12,'0'),4,3)) ||'.'||
trunc(substr(lpad(IPADRS_TO,12,'0'),7,3)) ||'.'||
trunc(substr(lpad(IPADRS_TO,12,'0'),10,3)) 
END IP
from audit_ip