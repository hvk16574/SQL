DECLARE
    CURSOR k1 IS
        SELECT user_id, user_name FROM fnd_user
         WHERE user_name IN ('17191', '89634', '17315',  '91254', '25988', '17874',
                             '78854', '75539', '51235',  '44248', '90073', '18928',
                             '88357', '28352', 'FM5508', '30334', '00881', '32851',
                             '63271', '10100', '64561',  '60764', '34394', '16549',
                             '38595', '39133', '06878');
    c1rec   k1%ROWTYPE;
    stat    BOOLEAN;
BEGIN
    DBMS_OUTPUT.disable;
    DBMS_OUTPUT.enable (100000);
    OPEN k1;
    LOOP
        FETCH k1 INTO c1rec;
        EXIT WHEN k1%NOTFOUND;
        stat := FND_PROFILE.SAVE ('FND_DIAGNOSTICS', NULL, 'USER', c1rec.user_id);
        IF stat THEN
            DBMS_OUTPUT.put_line ('profile updated for :' || c1rec.user_name);
        ELSE
            DBMS_OUTPUT.put_line ('profile NOT updated :' || c1rec.user_name);
        END IF;
        COMMIT;
    END LOOP;
    CLOSE k1;
END;