  SELECT ss.username, se.SID, VALUE / 100 cpu_usage_seconds
    FROM v$session ss, v$sesstat se, v$statname sn
   WHERE     se.STATISTIC# = sn.STATISTIC#
         AND NAME LIKE '%CPU used by this session%'
         AND se.SID = ss.SID
         AND ss.status = 'ACTIVE'
         AND ss.username IS NOT NULL
ORDER BY VALUE DESC;

  SELECT se.username, ss.sid, ROUND (VALUE / 100) "CPU Usage"
    FROM v$session se, v$sesstat ss, v$statname st
   WHERE ss.statistic# = st.statistic# AND name LIKE '%CPU used by this session%' AND se.sid = ss.SID AND se.username IS NOT NULL
ORDER BY VALUE DESC;

  SELECT username, v.sid || ',' || v.serial# sid_session, ROUND ( (s.VALUE / y.VALUE) * 100, 2) cpu_used_percentage
    FROM v$session v, v$sesstat s, v$sysstat y
   WHERE v.username IS NOT NULL AND v.sid = s.sid AND s.statistic# = y.statistic# AND y.name = 'CPU used by this session'
ORDER BY 3 DESC;