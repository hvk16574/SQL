Select ts.tablespace_name , round((((6144) * 100)/ size_info.max),3) max_free_pct_6GB , qtfs.ALERT_PCT
       , size_info.megs_used, size_info.max, (size_info.max - size_info.megs_used) free 
       , round((((size_info.max - size_info.megs_used) * 100)/ size_info.max),3) free_pct
       , ts.status, ts.contents, ts.logging
       , ts.extent_management, ts.allocation_type, ts.plugged_in
       , ts.block_size, ts.segment_space_management
       , ts.force_logging
       , ts.bigfile, ts.def_tab_compression
       , tsg.group_name
       , ts.encrypted
       , ts.compress_for,
       size_info.megs_alloc, size_info.megs_free, size_info.megs_used,
       size_info.pct_free, size_info.pct_used, size_info.max
From
      (
      select  a.tablespace_name,
             round(a.bytes_alloc / 1024 / 1024) megs_alloc,
             round(nvl(b.bytes_free, 0) / 1024 / 1024) megs_free,
             round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024) megs_used,
             round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100) Pct_Free,
            100 - round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100) Pct_used,
             round(maxbytes/1048576) Max
      from  ( select  f.tablespace_name,
                     sum(f.bytes) bytes_alloc,
                     sum(decode(f.autoextensible, 'YES',f.maxbytes,'NO', f.bytes)) maxbytes
              from dba_data_files f
              group by tablespace_name) a,
            (
             select ts.name tablespace_name, sum(fs.blocks) * ts.blocksize bytes_free
             from   DBA_LMT_FREE_SPACE fs, sys.ts$ ts
             where  ts.ts# = fs.tablespace_id
             group by ts.name, ts.blocksize
            ) b
      where a.tablespace_name = b.tablespace_name (+)
      union all
      select h.tablespace_name,
             round(sum(h.bytes_free + h.bytes_used) / 1048576) megs_alloc,
             round(sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / 1048576) megs_free,
             round(sum(nvl(p.bytes_used, 0))/ 1048576) megs_used,
             round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100) Pct_Free,
             100 - round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100) pct_used,
             round(sum(decode(f.autoextensible, 'YES', f.maxbytes, 'NO', f.bytes) / 1048576)) max
      from   sys.v_$TEMP_SPACE_HEADER h, dba_temp_files f,
             (select tablespace_name, file_id, sum(bytes_used) bytes_used
              from gv$temp_extent_pool
              group by tablespace_name, file_id) p
      where  p.file_id(+) = h.file_id
      and    p.tablespace_name(+) = h.tablespace_name
      and    f.file_id = h.file_id
      and    f.tablespace_name = h.tablespace_name
      group by h.tablespace_name
      ) size_info,
      sys.dba_tablespaces ts, sys.dba_tablespace_groups tsg, DBREPORT.QRDBA_TS_FREE_SPACEALERTCONFIG qtfs
where ts.tablespace_name = size_info.tablespace_name
and   ts.tablespace_name = tsg.tablespace_name (+)
and   ts.tablespace_name = qtfs.TSNAME
order by 2