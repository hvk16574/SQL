DECLARE
   CURSOR c1 IS
      SELECT CONCURRENT_PROGRAM_NAME, APPLICATION_SHORT_NAME
        FROM fnd_concurrent_programs_vl fcp, fnd_application fa
       WHERE     fa.APPLICATION_ID = fcp.APPLICATION_ID
             AND USER_CONCURRENT_PROGRAM_NAME IN ('QR Uniform Inventory Update Program');
BEGIN
   FOR c1_rec IN c1
   LOOP
      APPS.FND_PROGRAM.ENABLE_PROGRAM (c1_rec.CONCURRENT_PROGRAM_NAME, c1_rec.APPLICATION_SHORT_NAME, 'Y');
   END LOOP;
   
EXCEPTION
   WHEN OTHERS THEN DBMS_OUTPUT.put_line ('Main Exception : ' || SQLERRM);
END;
/