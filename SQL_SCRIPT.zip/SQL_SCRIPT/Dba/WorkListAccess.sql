SELECT   * FROM   wf_item_types_tl ORDER BY   1;

SELECT   GrantEO.GRANTEE_KEY,
         wf_directory.GetRoleDisplayName (GrantEO.GRANTEE_KEY) AS grantee_display_name,
         GrantEO.PARAMETER1, witt.display_name, GrantEO.PARAMETER2, GrantEO.START_DATE,
         GrantEO.END_DATE, GrantEO.INSTANCE_PK1_VALUE, GrantEO.PROGRAM_NAME,
         GrantEO.CREATED_BY, GrantEO.CREATION_DATE, GrantEO.PARAMETER3,GrantEO.PARAMETER4,
         GrantEO.PARAMETER5, GrantEO.PARAMETER6, GrantEO.PARAMETER7, GrantEO.PARAMETER8,
         GrantEO.PARAMETER9, GrantEO.PARAMETER10
  FROM   FND_GRANTS GrantEO, wf_item_types_tl witt
 WHERE   GrantEO.INSTANCE_TYPE = 'SET' --         AND wf_directory.GetRoleDisplayName (GrantEO.GRANTEE_KEY) LIKE '%Bash%'
         AND witt.name = GrantEO.PARAMETER2