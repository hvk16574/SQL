select
EXTRACTVALUE(XMLType(TEXT),'//file_edition_type') || ' ' || 
extractValue(XMLType(TEXT),'//oa_service_name[@oa_var="s_adminservername"]') || ' ' ||
extractValue(XMLType(TEXT),'//oacore_server_ports') || ' ' ||
extractValue(XMLType(TEXT),'//forms_server_ports') || ' ' ||
extractValue(XMLType(TEXT),'//oafm_server_ports') || ' ' ||
extractValue(XMLType(TEXT),'//forms-c4ws_server_ports') || ' ' ||
extractValue(XMLType(TEXT),'//oaea_server_ports')
from fnd_oam_context_files
where name not in ('TEMPLATE','METADATA')
and (status is null or status !='H')
and EXTRACTVALUE(XMLType(TEXT),'//file_edition_type')='patch'
and CTX_TYPE = 'A'
union
SELECT
EXTRACTVALUE(XMLType(TEXT),'//file_edition_type') || 'ch ' ||
extractValue(XMLType(TEXT),'//oa_service_name[@oa_var="s_adminservername"]') || ' ' ||
extractValue(XMLType(TEXT),'//oacore_server_ports') || ' ' ||
extractValue(XMLType(TEXT),'//forms_server_ports') || ' ' ||
extractValue(XMLType(TEXT),'//oafm_server_ports') || ' ' ||
extractValue(XMLType(TEXT),'//forms-c4ws_server_ports') || ' ' ||
extractValue(XMLType(TEXT),'//oaea_server_ports')
from fnd_oam_context_files
where name not in ('TEMPLATE','METADATA')
and (status is null or status !='H')
and EXTRACTVALUE(XMLType(TEXT),'//file_edition_type')='run'
and CTX_TYPE = 'A';

create table ad_adop_sessions1 as select * from ad_adop_sessions;

--patch AdminServer oacore_server1:7202 forms_server1:7402 oafm_server1:7602 forms-c4ws_server1:7802 
--run   AdminServer oacore_server1:7201 forms_server1:7401 oafm_server1:7601 forms-c4ws_server1:7801 
