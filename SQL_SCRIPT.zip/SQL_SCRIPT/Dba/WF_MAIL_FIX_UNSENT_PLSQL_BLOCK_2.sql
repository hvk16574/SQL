DECLARE
   CURSOR c1
   IS
      SELECT 'Insert into FND_USER_PREFERENCES Values (''' || name|| ''', ''WF'', ''MAILTYPE'', ''MAILHTML'')' cmd  
FROM wf_local_roles where email_address like '%@%'
and NOTIFICATION_PREFERENCE  not in ('DISABLED' ,'QUERY')  and length(name) = 5  
and name not in (
select distinct user_name    from FND_USER_PREFERENCES WHERE PREFERENCE_NAME = 'MAILTYPE' 
and  PREFERENCE_VALUE not in ('DISABLED' ,'QUERY'))
minus 
select distinct user_name    from FND_USER_PREFERENCES WHERE PREFERENCE_NAME = 'MAILTYPE'
;
BEGIN
   FOR c1_rec IN c1
   LOOP
      DBMS_OUTPUT.put_line (c1_rec.cmd);
      EXECUTE IMMEDIATE (c1_rec.cmd);
   END LOOP;
      EXCEPTION
   WHEN OTHERS 
   THEN
      null; 
END;