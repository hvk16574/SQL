  SELECT fr.responsibility_name RN, fcpt.user_concurrent_program_name
    FROM fnd_request_groups frg,
         fnd_request_group_units frgu,
         fnd_concurrent_programs fcp,
         fnd_concurrent_programs_tl fcpt,
         fnd_responsibility_vl fr
   WHERE     frgu.request_unit_type = 'P'
         AND UPPER (fcpt.user_concurrent_program_name) = UPPER ('Journal Entries Report')
         AND frgu.request_group_id = frg.request_group_id
         AND frgu.request_unit_id = fcp.concurrent_program_id
         AND fr.request_group_id = frg.request_group_id
         AND fcp.CONCURRENT_PROGRAM_ID = fcpt.CONCURRENT_PROGRAM_ID
ORDER BY 1