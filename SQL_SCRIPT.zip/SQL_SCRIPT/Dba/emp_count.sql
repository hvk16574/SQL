SELECT   
--           TO_CHAR (pps.date_start, 'MON-YYYY') Month,
--           paaf.organization_id,
--           HR_GENERAL.DECODE_ORGANIZATION (paaf.organization_id) org_name,
           DECODE (ppf.payroll_name,
                   'QC_PAYROLL',
                   'Qatar Aircraft Catering Company',
                   'QD_PAYROLL',
                   'Qatar Distribution Company',
                   'QF_PAYROLL',
                   'Qatar Duty Free Company',
                   'DI_PAYROLL',
                   'Doha International Airport',
                   'QS_PAYROLL',
                   'Qatar Aviation Services',
                   'QR_PAYROLL',
                   'Qatar Airways',
                   'QU_PAYROLL',
                   'Internal Media International')
              Company          , 
              count(distinct papf.employee_number) head_count
    FROM   per_all_people_f papf,
           per_all_assignments_f paaf,
           pay_payrolls_f ppf,
           per_periods_of_service pps,
           hr_all_organization_units haou
   WHERE   NVL(TRUNC(SYSDATE),pps.actual_termination_date) BETWEEN papf.effective_start_date
                                                   AND  papf.effective_end_Date
           AND NVL(TRUNC(SYSDATE),pps.actual_termination_date) BETWEEN paaf.effective_start_date
                                                       AND  paaf.effective_end_Date
           AND papf.person_id = paaf.person_id
           AND primary_flag = 'Y'
           AND paaf.payroll_id = ppf.payroll_id
           AND papf.person_id = pps.person_id
           AND paaf.organization_id = haou.organization_id
           AND pps.date_start = (SELECT   MAX (pps1.date_start)
                                   FROM   per_periods_of_service pps1
                                  WHERE   pps1.person_id = papf.person_id)
           AND ppf.payroll_name 
           IN
                    ('QC_PAYROLL',
                     'QD_PAYROLL',
                     'QF_PAYROLL',
                     'DI_PAYROLL',
                     'QS_PAYROLL',
                     'QR_PAYROLL',
                     'QU_PAYROLL')
           AND papf.employee_number NOT LIKE 'TSS%'
           AND papf.employee_number NOT LIKE 'K%'
           AND papf.employee_number NOT LIKE 'S%'
           AND papf.employee_number NOT IN ('99998', '99999')
          AND  (SELECT MIN (pps1.date_start)
                             FROM per_periods_of_service pps1
                            WHERE pps1.person_id = papf.person_id) between to_date('01-JAN-2015') and to_date('31-DEC-2015')
--                            and upper(HR_GENERAL.DECODE_ORGANIZATION (paaf.organization_id)) like '%CREW%'
group by 
--TO_CHAR (pps.date_start, 'MON-YYYY'),
--paaf.organization_id ,
--HR_GENERAL.DECODE_ORGANIZATION (paaf.organization_id) ,
ppf.payroll_name
