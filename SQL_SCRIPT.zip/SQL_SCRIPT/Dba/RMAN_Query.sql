select db_key, session_key , output from rc_rman_output 
where session_key in ( select max(session_key) from rc_rman_output where db_key in (select db_key from rc_database ))
order by stamp

select output from rc_rman_output 
where session_key = ( select max(session_key) from rc_rman_output where db_key = 9686)
order by stamp