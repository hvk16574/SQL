DECLARE
   CURSOR c1
   IS
      SELECT *
        FROM b;
BEGIN
   FOR c1_rec IN c1
   LOOP
      apps.fnd_user_pkg.updateuser
                                (c1_rec.a,
                                 x_owner            => 0,
                                 x_end_date         => SYSDATE,
                                 x_description      =>    'Resigned, disbaled on '
                                                       || SYSDATE
                                                       || ' - Hamid V. Khan'
                                );
      DBMS_OUTPUT.put_line (c1_rec.a);
   END LOOP;
END;

/*
CREATE TABLE apps.b
(
  a  VARCHAR2(5 BYTE)
);
*/