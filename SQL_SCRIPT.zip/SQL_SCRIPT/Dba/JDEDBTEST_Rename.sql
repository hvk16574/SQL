F986110 , JCEXEHOST

 F00053 , hmmkey, hmdatp, hmdl01

 F000531 , hdmkey

 F000532 , hcmkey

 F98611, F986101

update SY812.f98611 set omsrvr = 'JDEDBTEST' where omsrvr = 'JDEDBTEST';

update SY812.f98611 set omdatp = '1qdjde01' where omdatp = 'JDEDBTEST';

update SY812.f98611 set omdatp = '1qdjde01 - Server Map' where omdatp = 'JDEDBTEST - Server Map';

update SY812.f986101 set omdatp = '1qdjde01' where omdatp = 'JDEDBTEST';

update SY812.f986101 set omdatp = '1qdjde01 - Server Map' where omdatp = 'JDEDBTEST - Server Map';

update SY812.f98611 set omsrvr = '1qdjde01' where omsrvr = 'JDEDBTEST';

update SVM812.f98611 set omsrvr = '1qdjde01' where omsrvr = 'JDEDBTEST';

update SVM812.f98611 set omdatp = '1qdjde01' where omdatp = 'JDEDBTEST';

update SVM812.f986101 set omdatp = '1qdjde01' where omdatp = 'JDEDBTEST';

update SVM812.f986101 set omdatp = '1qdjde01 - Server Map' where omdatp = 'JDEDBTEST -Server Map';


 Check and change the database connect string: omdatb for both the sysb733 and svmb733 owners of F98611 and F986101
 
 
 
 
 /*
 
 update SY812.f98611 set omsrvr = 'JDEDBTEST' where omsrvr = 'JDEDBTEST';

update SY812.f98611 set omdatp = '1qdjde01' where omdatp = 'JDEDBTEST';

update SY812.f98611 set omdatp = '1qdjde01 - Server Map' where omdatp = 'JDEDBTEST - Server Map';

update SY812.f986101 set omdatp = '1qdjde01' where omdatp = 'JDEDBTEST';

update SY812.f986101 set omdatp = '1qdjde01 - Server Map' where omdatp = 'JDEDBTEST - Server Map';

update SY812.f98611 set omsrvr = '1qdjde01' where omsrvr = 'JDEDBTEST';

update SVM812.f98611 set omsrvr = '1qdjde01' where omsrvr = 'JDEDBTEST';

update SVM812.f98611 set omdatp = '1qdjde01' where omdatp = 'JDEDBTEST';

update SVM812.f986101 set omdatp = '1qdjde01' where omdatp = 'JDEDBTEST';

update SVM812.f986101 set omdatp = '1qdjde01 - Server Map' where omdatp = 'JDEDBTEST -Server Map';

*/