SELECT mview_name,last_refresh_date "START_TIME",
       CASE
          WHEN fullrefreshtim <> 0 THEN LAST_REFRESH_DATE + fullrefreshtim / 60 / 60 / 24
          WHEN increfreshtim <> 0 THEN LAST_REFRESH_DATE + increfreshtim / 60 / 60 / 24
          ELSE LAST_REFRESH_DATE
       END "END_TIME",
       ceil(fullrefreshtim/60) Full_Minutes, ceil(increfreshtim /60) Inc_Minutes
  FROM all_mview_analysis
  order by 4 desc, 5 desc