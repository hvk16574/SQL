  SELECT TO_CHAR (ATTNDATE, 'MON-YYYY'), SUM (SHIFTREGHRS), SUM (TOTALATTNHRS), (SUM (SHIFTREGHRS) - SUM (TOTALATTNHRS))
    FROM QRTAS.QRTAS_EMPLOYEE_OT_V@tna_to_erp WHERE     EMPLOYEECODE = :emp_num
         AND OFFDAY != -1 AND HOLIDAY != -1 AND LEAVETYPE IS NULL
         AND attndate NOT IN (WITH cntr AS (    SELECT LEVEL - 1 AS n FROM DUAL CONNECT BY LEVEL <=   (SELECT MAX (date_end - date_start) FROM per_absence_attendances
                                                               WHERE person_id = (SELECT DISTINCT person_id FROM per_all_people_f WHERE employee_number = (LPAD (TRUNC (:emp_num), 5, '0')))) + 1)
                              SELECT x.date_start + c.n AS a_date FROM    per_absence_attendances x
                                     JOIN cntr c ON     c.n <= x.date_end - x.date_start
                                        AND x.person_id = (SELECT DISTINCT person_id FROM per_all_people_f WHERE employee_number = (LPAD (TRUNC (:emp_num), 5, '0'))))
GROUP BY TO_CHAR (ATTNDATE, 'MON-YYYY')
ORDER BY TO_DATE (TO_CHAR (ATTNDATE, 'MON-YYYY'), 'MON-YYYY') DESC