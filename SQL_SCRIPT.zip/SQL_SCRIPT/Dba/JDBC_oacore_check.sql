column module heading "Module Name" format a48;
column machine heading "Machine Name" format a15;
column process heading "Process ID" format a10;
column inst_id heading "Instance ID" format 99;
prompt
prompt Connection Usage Per Module and process

select to_char(sysdate, 'dd-mon-yyyy hh24:mi') Time from dual
/
prompt ~~~~

select count(*), machine, process, module from gv$session
where program like 'JDBC%' group by machine, process, module order by 1 asc
/


SELECT s.process, Count(*) all_count FROM   gv$session s WHERE s.process IN
--('2636', '10668', '10669', '10670', '10671', '10672', '10994', '22578' ) 
( '2509', '2510', '2511', '2512', '2515', '2823', '9646') 
 GROUP BY  s.process

SELECT s.process, Count(*) all_count FROM   gv$session s WHERE s.process IN
('6720', '6721', '6722', '6725', '6726', '6727', '6728', '6730', '11510', '18672', '18673', '18674', '18675', '18676', '18677', '18678', '18679', '20702') 
 GROUP BY  s.process
 order by 2 desc
  
+ To find number of database connections per JVM that were inactive for longer then 30 minutes

SELECT s.process, Count(*) olderConnection_count FROM   gv$session s WHERE  s.process IN ('6720', '6721', '6722', '6725', '6726', '6727', '6728', '6730', '11510', '18672', '18673', '18674', '18675', '18676', '18677', '18678', '18679', '20702')  
and  s.last_call_et>=(30*60) and s.status='INACTIVE' GROUP BY  s.process

+ To find the modules responsible to JDBC connections for a process id

SELECT Count(*), process,machine, program, MODULE FROM gv$session s 
WHERE s.process IN ('&id')GROUP BY process,machine, program, MODULE ORDER BY process,machine, program, MODULE;


select bug_number, decode(bug_number,
         '3043762','JDBC drivers 8.1.7.3',
         '2969248','JDBC drivers 9.2.0.2',
         '3080729','JDBC drivers 9.2.0.4 (OCT-2003)',
         '3423613','JDBC drivers 9.2.0.4 (MAR-2004)',
         '3585217','JDBC drivers 9.2.0.4 (MAY-2004)',
         '3882116','JDBC drivers 9.2.0.5 (OCT-2004)',
         '3966003','JDBC drivers 9.2.0.5 (OCT-2004)',
         '3981178','JDBC drivers 9.2.0.5 (NOV-2004)',
         '4090504','JDBC drivers 9.2.0.5 (JAN-2005)',
         '4201222','JDBC drivers 9.2.0.6 (MAY-2005)') Patch_description
    from ad_bugs
    where bug_number in
         (
         '3043762',
         '2969248',
         '3080729',
         '3423613',
         '3585217',
         '3882116',
         '3966003',
         '3981178',
         '4090504',
         '4201222'
         )
    order by 2;
    
    
    
    
SELECT node_id, TRUNC (FIRST_CONNECT) Adate,  COUNT (1)
    FROM icx_sessions si, fnd_user fu
   WHERE  --TRUNC (FIRST_CONNECT) >= TRUNC (SYSDATE ) --AND RESPONSIBILITY_APPLICATION_ID = 800
    FIRST_CONNECT >= sysdate-(50/1440)  
   --AND si.RESPONSIBILITY_ID != 57701 
   AND fu.user_id = si.user_id AND si.user_id != 0
   and disabled_flag != 'Y'
and PSEUDO_FLAG = 'N'
GROUP BY node_id, TRUNC (FIRST_CONNECT)
ORDER BY TRUNC (FIRST_CONNECT);    

select sysdate-(50/1440) from dual

select *from fnd_nodes


REM start of SQL
set feedback on
set timing on
set echo on
set feedback on
set pagesize 132
set linesize 80
col user_name format a15
col first_connect format a18
col last_connect format a18
col How_many_user_sessions format 9999999999
col How_many_sessions format 9999999999
rem Summary of how many users

select 'Number of user sessions : ' || count( distinct session_id) How_many_user_sessions
from icx_sessions icx
where last_connect > sysdate - (7/24)
and disabled_flag != 'Y'
and PSEUDO_FLAG = 'N'
/

rem sessions per user
select user_name, count(*) How_many_sessions from icx_sessions icx, fnd_user u
where icx.user_id = u.user_id
and last_connect > sysdate - (7/24)
and disabled_flag != 'Y'
and PSEUDO_FLAG = 'N'
group by user_name
order by 2 desc
/
REM end of SQL



select sysdate - (7/24) from dual



select * from dba_dml_locks



http://appsdb.blogspot.com/2010/02/oracle-ebs-number-of-users-logged-into.html
http://avdeo.com/2008/01/28/number-of-users-logged-into-oracle-e-business-suite/
