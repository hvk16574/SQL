select tablespace_name,sum(bytes)/1024/1024
from dba_free_space
where tablespace_name in ('APD', 'APX', 'ARD', 'ARX', 'FAD', 'FAX', 'GLD', 'GLX' ,'ICXD', 'ICXX', 'INVD', 'INVX', 'OATD',
                          'HRD', 'HRX', 'POX', 'POD', 'BOMD', 'BOMX', 'APPLSYSD', 'APPLSYSX', 'SYSTEM' ,'QAIR', 'OATX')
group by tablespace_name
order by 2;