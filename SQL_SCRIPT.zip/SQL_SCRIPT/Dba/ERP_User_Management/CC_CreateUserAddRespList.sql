SELECT DISTINCT employee_number, u.user_id
           FROM per_all_people_f papf,
                per_all_assignments_f paaf,
                per_grades pg,
                fnd_user u
          WHERE papf.person_id = paaf.person_id
            AND organization_id = 574
            AND pg.grade_id = paaf.grade_id
            AND primary_flag = 'Y'
            AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date
                                    AND paaf.effective_end_date
            AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                    AND papf.effective_end_date
            AND current_employee_flag = 'Y'
            AND u.user_name = papf.employee_number
            AND u.user_id NOT IN (SELECT DISTINCT user_id
                                             FROM fnd_user_resp_groups_direct
                                            WHERE user_id NOT IN (
                                                                SELECT user_id
                                                                  FROM hello));


CREATE TABLE hello AS SELECT DISTINCT user_id
                              FROM fnd_user_resp_groups_direct
                             WHERE user_id NOT IN (
                                      SELECT DISTINCT user_id
                                                 FROM fnd_user_resp_groups_direct
                                                WHERE responsibility_application_id =
                                                                           800
                                                  AND responsibility_id =
                                                                         53076)