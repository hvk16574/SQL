DECLARE
   CURSOR c1
   IS
        SELECT FURGD.USER_ID,
               FURGD.RESPONSIBILITY_ID,
               FURGD.RESPONSIBILITY_APPLICATION_ID,
               FURGD.START_DATE,
               NVL (FURGD.END_DATE, EP.END_DATE) END_DATE,
               EP.EMAIL_ADDRESS RES,
               EP.EMPLOYEE_NUMBER,
               EP.description 
          FROM FND_USER_RESP_GROUPS_DIRECT FURGD, EMP_PHOTO EP, FND_USER FU
         WHERE     FU.USER_NAME = EP.EMPLOYEE_NUMBER
               AND FURGD.USER_ID = FU.USER_ID
               AND (RESPONSIBILITY_ID, RESPONSIBILITY_APPLICATION_ID) IN (SELECT RESPONSIBILITY_ID, APPLICATION_ID
                                                                            FROM FND_RESPONSIBILITY
                                                                           WHERE RESPONSIBILITY_ID = (SELECT RESPONSIBILITY_ID
                                                                                                        FROM FND_RESPONSIBILITY_TL
                                                                                                       WHERE RESPONSIBILITY_NAME = EP.EMAIL_ADDRESS))
                                                                                                       and ep.email_address != 'QAG Departmental Clearances'
      ORDER BY 1;

   x_user_name                    VARCHAR2 (200);
   x_owner                        VARCHAR2 (200);
   x_unencrypted_password         VARCHAR2 (200);
   x_session_number               NUMBER := NULL;
   x_start_date                   DATE := SYSDATE;
   x_end_date                     DATE := NULL;
   x_last_logon_date              DATE := NULL;
   x_description                  VARCHAR2 (200) := NULL;
   x_password_date                DATE := NULL;
   x_password_accesses_left       NUMBER := NULL;
   x_password_lifespan_accesses   NUMBER := NULL;
   x_password_lifespan_days       NUMBER := NULL;
   x_employee_id                  NUMBER := NULL;
   x_email_address                VARCHAR2 (200);
   x_fax                          VARCHAR2 (200) := NULL;
   x_customer_id                  NUMBER := NULL;
   x_supplier_id                  NUMBER := NULL;
   x_res_id                       VARCHAR2 (80) := NULL;
   x_ai                           VARCHAR2 (80) := NULL;
BEGIN
   FOR c1_rec IN c1
   LOOP
      --      IF (fnd_user_resp_groups_api.assignment_exists (x.user_id, x.responsibility_id, x.RESPONSIBILITY_APPLICATION_ID))
      --      THEN
      fnd_user_resp_groups_api.update_assignment (user_id                         => c1_rec.user_id,
                                                  responsibility_id               => c1_rec.responsibility_id,
                                                  responsibility_application_id   => c1_rec.responsibility_application_id,
                                                  start_date                      => c1_rec.start_date,
                                                  end_date                        => c1_rec.end_date,
                                                  description                     => c1_rec.description);
      --      END IF;

      DBMS_OUTPUT.put_line ('Responsibility: ' || c1_rec.res || ' Endated to Staff#:' || c1_rec.EMPLOYEE_NUMBER);
   END LOOP;
END;






















--373369.1
--394784.1