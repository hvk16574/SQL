  SELECT   TRUNC (start_time), TAG, SUM (BYTES) / 1024 / 1024 / 1024
    FROM   v$backup_piece
   WHERE   handle LIKE 'level0%'
GROUP BY   TRUNC (start_time), TAG
ORDER BY   TRUNC (start_time);

  SELECT   TRUNC (COMPLETION_TIME),
           INCREMENTAL_LEVEL,
           SUM (BLOCKS * BLOCK_SIZE) / 1024 / 1024 / 1024
    FROM   v$backup_datafile
GROUP BY   TRUNC (COMPLETION_TIME), INCREMENTAL_LEVEL;