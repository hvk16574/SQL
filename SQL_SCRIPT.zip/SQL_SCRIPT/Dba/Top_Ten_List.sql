SELECT fav.application_name, frv.responsibility_name, fudo.function_name,
       fudo.SEQUENCE, fffv.user_function_name
  FROM fnd_user_desktop_objects fudo,
       fnd_form_functions_vl fffv,
       fnd_application_vl fav,
       fnd_responsibility_vl frv
 WHERE fffv.function_name = fudo.function_name
   AND fav.application_id = fudo.application_id
   AND frv.responsibility_id = fudo.responsibility_id
   AND fudo.user_id IN (SELECT user_id
                          FROM fnd_user
                         WHERE user_name = :emp_no)