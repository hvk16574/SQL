rem The following SQL statements can be cut and pasted into SQL*Plus or scripts for
rem for monitoring Streams.  
rem
rem See the MAA white paper "Oracle Streams Performance Performance Tuning Best Practice: Oracle 10g Release 10.2" which will reference this script.
rem
rem The following are for monitoring Streams
rem Capture.
rem
rem Run these SQL statements as the Streams administrator on the database instance running the capture process.

rem The following SQL shows streams pool statistics.  The query
rem only shows rows from v$streams_pool_advice where the size
rem factor is 1 or greater.  This limits the output to only 
rem the estimated spill count at the current size and size 
rem factors that would reduce estimated spill counts.

select inst_id, streams_pool_size_for_estimate,
streams_pool_size_factor,estd_spill_count
from gv$streams_pool_advice
where streams_pool_size_factor >= 1;


rem LogMiner Stats -- the statistics "bytes paged out" should be zero, if not a logminer spill has occurred.  

select inst_id, session_id,name,value 
from gv$logmnr_stats;

rem Capture Stats. 

select to_char(sysdate,'DD-MON-YY hh24:mi:ss') current_time,
       inst_id,
       capture_name,state,
       total_messages_captured,
       total_messages_created,
       total_messages_enqueued,
       total_full_evaluations,
       ELAPSED_REDO_WAIT_TIME
from gv$streams_capture;

rem Streams transaction as seen on the Capture database.
rem Several rows are returned for each open transaction that
rem capture is processing.

select to_char(sysdate,'DD-MON-YY hh24:mi:ss') current_time,
       inst_id,
       streams_name,
       streams_type,
       XIDUSN || '.' ||
       XIDSLT || '.' ||
       XIDSQN,
       CUMULATIVE_MESSAGE_COUNT,
       TOTAL_MESSAGE_COUNT, 
       to_char(FIRST_MESSAGE_TIME,'DD-MON-YY hh24:mi:ss') FIRST_MESSAGE_TIME,
                         FIRST_MESSAGE_NUMBER,
       to_char(LAST_MESSAGE_TIME,'DD-MON-YY hh24:mi:ss') LAST_MESSAGE_TIME,
                         LAST_MESSAGE_NUMBER
from gv$streams_transaction;


rem Propagation Sender Stats.  Check that the column schedule_status is "SCHEDULE ENABLED".  

select to_char(sysdate,'DD-MON-YY hh24:mi:ss') current_time,
       inst_id,
       queue_schema, 
       queue_name,
       dst_queue_schema,
       dst_queue_name,
       high_water_mark,
       ACKNOWLEDGEMENT,
       schedule_status,
       total_msgs,
       total_bytes
from gv$propagation_sender;

rem Use the following query to view the Streams buffered queues.  This
rem query should be run on databases where buffered queues are used by
rem Streams. This query shows messages in memory, spilled messages and 
rem total messages in the queue.


COLUMN QUEUE_SCHEMA HEADING 'Queue Owner' FORMAT A15
COLUMN QUEUE_NAME HEADING 'Queue Name' FORMAT A15
COLUMN MEM_MSG HEADING 'Messages|in Memory' FORMAT 99999999
COLUMN SPILL_MSGS HEADING 'Messages|Spilled' FORMAT 99999999
COLUMN NUM_MSGS HEADING 'Total Messages|in Buffered Queue' FORMAT 99999999

SELECT to_char(sysdate,'DD-MON-YY hh24:mi:ss') current_time,
       inst_id,
       QUEUE_SCHEMA,
       QUEUE_NAME,
       (NUM_MSGS - SPILL_MSGS) MEM_MSG,
       SPILL_MSGS,
       NUM_MSGS
  FROM GV$BUFFERED_QUEUES;


