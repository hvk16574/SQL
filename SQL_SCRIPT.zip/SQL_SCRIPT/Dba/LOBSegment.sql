SELECT *
  FROM dba_lobs
 WHERE segment_name = :segment_name;

SELECT owner, segment_name, tablespace_name, extents, initial_extent,
       next_extent, min_extents, max_extents
  FROM dba_segments
 WHERE segment_name = :segment_name;

ALTER TABLE "APPLSYS"."FND_LOBS"
     MODIFY LOB("<LOB_OBJECT_NAME>") ( STORAGE ( NEXT 3 m MAXEXTENTS 3000 PCTINCREASE 0));



SELECT owner||'.'||SEGMENT_NAME NAME, SEGMENT_TYPE TYPE,
       EXTENTS, MAX_EXTENTS, MAX_EXTENTS - EXTENTS LEFT_EXTENTS,
       NEXT_EXTENT/1024 next_kb, bytes/1024 bytes_kb
       FROM DBA_SEGMENTS
       WHERE tablespace_name = 'APPLSYSD'
       
SELECT  MAX(bytes/1024/1024) 
      FROM  dba_free_space 
      WHERE  tablespace_name = 'APPLSYSD';
      
ALTER TABLE "APPLSYS"."FND_LOBS"
     MODIFY LOB("<LOB_OBJECT_NAME>") ( STORAGE ( NEXT 3M maxextents 3000 PCTINCREASE 0));