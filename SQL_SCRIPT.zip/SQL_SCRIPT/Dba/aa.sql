SELECT "ROW_ID",
       "SRF_HEADER_ID",
       "SRF_LINE_ID",
       "POSITION_REF_ID",
       "BUDGET_YEAR",
       "FY_YEAR",
       "BUDGETED",
       "COST_CENTER",
       "SRF_NUMBER",
       "POSITION_REFERENCE_NO",
       "POSITION_TITLE",
       "GRADE",
       "DEPARTMENT_NAME",
       "DIVISION_NAME",
       "BUSINESS_UNIT_NAME",
       "SOURCING_INITIATION_DATE",
       "ONBOARDING_EFFECTIVE_DATE",
       "SRF_IVN_NUMBER",
       "SRF_XVN_NUMBER",
       "SMA_NUMBER",
       "REPORTING_TO",
       "REPORTING_PERSON_ID",
       "REPORTING_STAFF_NUMBER",
       "STAFF_NUMBER",
       "STATUS",
       "POSITION_STATUS",
       "JD_VAL_REQUIRED_FLG",
       "JD_APPROVED",
       "JD_APPROVED_DATE",
       "IS_UPDATE_SUCESS",
       "LAST_UPDATE_DATE",
       "APPLICANT_NUMBER",
       "APPLICANT_NAME",
       "EMPLOYEE_NAME",
       "SNP_XVN_NUMBER",
       "SNP_IVN_NUMBER",
       "SRF_STATUS_DESCRIPTION",
       "SRF_STATUS_USED",
       "SRF_TYPE",
       "SRF_POS_DISCRIPTION",
       "REPLACE_STAFF_NO",
       "REPLACE_STAFF_NAME",
       "REPLACE_FLAG",
       "BUDGET_PERIOD",
       "COMMENTS",
       "ACTUAL_SOUR_DATE",
       "DEPARTMENT_ID",
       "DIVISION_ID",
       "COMPANY_ID",
       "JOB_CODE",
       "POSITION_ID",
       "GRADE_ID",
       "HIRING_STAFF",
       "HIRING_PERSON_ID",
       "HIRING_STAFF_NUMBER"
  FROM (SELECT qsht.ROWID row_id,
               qsht.srf_header_id,
               qslt.srf_line_id,
               qsprt.position_ref_id,
               qsht.budget_year,
               (SELECT tag
                  FROM fnd_lookup_values flv
                 WHERE     flv.lookup_type = 'QAG_GEMS-SRF_FY_VAL'
                       AND enabled_flag = 'Y'
                       AND lookup_code = qsht.budget_year)
                  fy_year,
               DECODE (qsht.budgeted, 'Y', 'Yes', 'No') budgeted,
               qsht.cost_center,
               qsht.srf_number,
               ppei.poei_information1 position_reference_no,
               qag_srf_utilities.get_position_name (qslt.position_id)
                  position_title,
               (SELECT pg.NAME
                  FROM per_grades pg
                 WHERE     TRUNC (SYSDATE) BETWEEN TRUNC (pg.date_from)
                                               AND TRUNC (
                                                      NVL (pg.date_to,
                                                           SYSDATE + 1))
                       AND pg.grade_id = qslt.grade_id)
                  grade,
               qag_srf_utilities.get_department (qsht.department_id)
                  department_name,
               ( (SELECT DISTINCT haou1.NAME
                    FROM hr_all_organization_units haou1
                   WHERE haou1.organization_id =
                            get_org_id (qsht.department_id, 'DIV'))
                UNION
                (SELECT DISTINCT haou1.NAME
                   FROM hr_all_organization_units haou1
                  WHERE     1 = 1
                        AND ROWNUM = 1
                        AND haou1.organization_id =
                               get_org_id (qsht.department_id, 'STN')))
                  division_name,
               ( (SELECT DISTINCT haou1.NAME
                    FROM hr_all_organization_units haou1
                   WHERE haou1.organization_id =
                            get_org_id (qsht.department_id, 'BU'))
                UNION
                (SELECT DISTINCT haou1.NAME
                   FROM hr_all_organization_units haou1
                  WHERE     1 = 1
                        AND ROWNUM = 1
                        AND haou1.organization_id =
                               get_org_id (qsht.department_id, 'CTY')))
                  business_unit_name,
               qslt.sourcing_initiation_date,
               qslt.boarding_effective_date onboarding_effective_date,
               ppei.poei_information4 srf_ivn_number,
               ppei.poei_information5 srf_xvn_number,
               UPPER (ppei.poei_information6) sma_number,
               INITCAP (qag_srf_utilities.get_person_name (
                           NVL (
                              (SELECT ppx.person_id
                                 FROM per_all_people_f ppx
                                WHERE     ppx.employee_number =
                                             qsht.attribute9
                                      AND ROWNUM < 2),
                              qslt.reporting_to_person_id)))
                  reporting_to,
               NVL (
                  (SELECT ppx.person_id
                     FROM per_all_people_f ppx
                    WHERE     ppx.employee_number = qsht.attribute9
                          AND ROWNUM < 2),
                  qslt.reporting_to_person_id)
                  reporting_person_id,
               (SELECT employee_number
                  FROM per_all_people_f
                 WHERE     TRUNC (SYSDATE) BETWEEN effective_start_date
                                               AND effective_end_date
                       AND current_employee_flag = 'Y'
                       AND person_id =
                              NVL (
                                 (SELECT ppx.person_id
                                    FROM per_all_people_f ppx
                                   WHERE     ppx.employee_number =
                                                qsht.attribute9
                                         AND ROWNUM < 2),
                                 qslt.reporting_to_person_id))
                  reporting_staff_number,
               (SELECT papf.employee_number
                  FROM qag_hr_sma_transaction_tab qst, per_people_x papf
                 WHERE     qst.person_id = papf.person_id
                       AND qst.pos_ref_number = qsprt.position_ref_num
                       AND qst.person_type = 'EMPLOYEE'
                       AND qst.status != 'REJECTED')
                  staff_number,
               --qsht.status,
               DECODE (
                  NVL (
                     (SELECT DECODE (
                                qst.person_type,
                                'EMPLOYEE', DECODE (
                                               qst.status,
                                               'APPROVED', 'EMP_PROMOTED',
                                               'NEW', 'SMA_INITIATED'),
                                'APPLICANT', DECODE (
                                                qst.status,
                                                'APPROVED', 'EMP_JOINED',
                                                'NEW', 'SMA_INITIATED'))
                        FROM qag_hr_sma_transaction_tab qst
                       WHERE     qst.pos_ref_number = qsprt.position_ref_num
                             AND qst.status != 'REJECTED'),
                     qag_srf_gems_general_pkg.hdr_status (
                        qslt.srf_header_id,
                        qslt.srf_line_id,
                        qsprt.position_ref_id)),
                  'REPLACED', 'SWAPPED',
                  NVL (
                     (SELECT DECODE (
                                qst.person_type,
                                'EMPLOYEE', DECODE (
                                               qst.status,
                                               'APPROVED', 'EMP_PROMOTED',
                                               'NEW', 'SMA_INITIATED'),
                                'APPLICANT', DECODE (
                                                qst.status,
                                                'APPROVED', 'EMP_JOINED',
                                                'NEW', 'SMA_INITIATED'))
                        FROM qag_hr_sma_transaction_tab qst
                       WHERE     qst.pos_ref_number = qsprt.position_ref_num
                             AND qst.status != 'REJECTED'),
                     qag_srf_gems_general_pkg.hdr_status (
                        qslt.srf_header_id,
                        qslt.srf_line_id,
                        qsprt.position_ref_id)))
                  status,
               -- DECODE (hold_status, 'Y', 'ON_HOLD', NULL) position_status,
               NVL (
                  qsprt.attribute5,
                  qag_srf_gems_general_pkg.pos_status (qslt.srf_header_id,
                                                       qslt.srf_line_id,
                                                       qsprt.position_ref_id))
                  position_status,
               DECODE (UPPER (NVL (hap.attribute4, 'Y')),
                       'YES', 'Y',
                       'NO', 'N',
                       'Y', 'Y',
                       'N', 'N')
                  jd_val_required_flg,
               DECODE (UPPER (NVL (hap.attribute1, 'Y')),
                       'YES', 'Y',
                       'NO', 'N',
                       'Y', 'Y',
                       'N', 'N')
                  jd_approved,
               --hap.attribute2 jd_approved_date1,
               (TO_CHAR (
                   CASE
                      WHEN fnd_date.canonical_to_date (hap.attribute2) <
                              (SYSDATE - 730)
                      THEN
                         TO_DATE ('2012/01/01 00:00:00',
                                  'yyyy/mm/dd hh24:mi:ss')
                      WHEN hap.attribute2 IS NULL
                      THEN
                         TO_DATE ('2012/01/01 00:00:00',
                                  'yyyy/mm/dd hh24:mi:ss')
                      ELSE
                         fnd_date.canonical_to_date (hap.attribute2)
                   END,
                   'YYYY/MM/DD HH24:MI:SS'))
                  jd_approved_date,
               --qag_srf_utilities.GET_PERSON_NAME(ppei.POEI_INFORMATION3) REP_PERSON_NAME
               qag_srf_gems_general_pkg.is_update_status (
                  qslt.srf_header_id,
                  qslt.srf_line_id,
                  qsprt.position_ref_id)
                  is_update_sucess,
               qsht.last_update_date,
               (SELECT DISTINCT papf.applicant_number
                  FROM qag_hr_sma_transaction_tab qst, per_all_people_f papf
                 WHERE     qst.person_id = papf.person_id
                       AND qst.person_type = 'APPLICANT'
                       AND qst.status = 'NEW'
                       AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND qst.pos_ref_number = qsprt.position_ref_num)
                  applicant_number,
               (SELECT INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                          full_name
                  FROM qag_hr_sma_transaction_tab qst, per_all_people_f papf
                 WHERE     qst.person_id = papf.person_id
                       AND qst.person_type = 'APPLICANT'
                       AND qst.status != 'REJECTED'
                       AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                       AND qst.pos_ref_number = qsprt.position_ref_num
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date)
                  applicant_name,
               (SELECT INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                          full_name
                  FROM qag_hr_sma_transaction_tab qst, per_people_x papf
                 WHERE     qst.person_id = papf.person_id
                       AND qst.pos_ref_number = qsprt.position_ref_num
                       AND qst.person_type = 'EMPLOYEE'
                       AND qst.status != 'REJECTED')
                  employee_name,
               '' snp_xvn_number,
               '' snp_ivn_number,
               (SELECT meaning
                  FROM fnd_lookup_values
                 WHERE     lookup_type = 'QAG_SRF_STATUS'
                       AND enabled_flag = 'Y'
                       AND lookup_code =
                              DECODE (
                                 NVL (
                                    (SELECT DECODE (
                                               qst.person_type,
                                               'EMPLOYEE', DECODE (
                                                              qst.status,
                                                              'APPROVED', 'EMP_PROMOTED',
                                                              'NEW', 'SMA_INITIATED'),
                                               'APPLICANT', DECODE (
                                                               qst.status,
                                                               'APPROVED', 'EMP_JOINED',
                                                               'NEW', 'SMA_INITIATED'))
                                       FROM qag_hr_sma_transaction_tab qst
                                      WHERE     qst.pos_ref_number =
                                                   qsprt.position_ref_num
                                            AND qst.status != 'REJECTED'),
                                    qag_srf_gems_general_pkg.hdr_status (
                                       qslt.srf_header_id,
                                       qslt.srf_line_id,
                                       qsprt.position_ref_id)),
                                 'REPLACED', 'SWAPPED',
                                 NVL (
                                    (SELECT DECODE (
                                               qst.person_type,
                                               'EMPLOYEE', DECODE (
                                                              qst.status,
                                                              'APPROVED', 'EMP_PROMOTED',
                                                              'NEW', 'SMA_INITIATED'),
                                               'APPLICANT', DECODE (
                                                               qst.status,
                                                               'APPROVED', 'EMP_JOINED',
                                                               'NEW', 'SMA_INITIATED'))
                                       FROM qag_hr_sma_transaction_tab qst
                                      WHERE     qst.pos_ref_number =
                                                   qsprt.position_ref_num
                                            AND qst.status != 'REJECTED'),
                                    qag_srf_gems_general_pkg.hdr_status (
                                       qslt.srf_header_id,
                                       qslt.srf_line_id,
                                       qsprt.position_ref_id))))
                  srf_status_description,
               (SELECT tag
                  FROM fnd_lookup_values
                 WHERE     lookup_type = 'QAG_SRF_STATUS'
                       AND enabled_flag = 'Y'
                       AND meaning =
                              (SELECT meaning
                                 FROM fnd_lookup_values
                                WHERE     lookup_type = 'QAG_SRF_STATUS'
                                      AND enabled_flag = 'Y'
                                      AND lookup_code =
                                             DECODE (
                                                NVL (
                                                   (SELECT DECODE (
                                                              qst.person_type,
                                                              'EMPLOYEE', DECODE (
                                                                             qst.status,
                                                                             'APPROVED', 'EMP_PROMOTED',
                                                                             'NEW', 'SMA_INITIATED'),
                                                              'APPLICANT', DECODE (
                                                                              qst.status,
                                                                              'APPROVED', 'EMP_JOINED',
                                                                              'NEW', 'SMA_INITIATED'))
                                                      FROM qag_hr_sma_transaction_tab qst
                                                     WHERE     qst.pos_ref_number =
                                                                  qsprt.position_ref_num
                                                           AND qst.status !=
                                                                  'REJECTED'),
                                                   qag_srf_gems_general_pkg.hdr_status (
                                                      qslt.srf_header_id,
                                                      qslt.srf_line_id,
                                                      qsprt.position_ref_id)),
                                                'REPLACED', 'SWAPPED',
                                                NVL (
                                                   (SELECT DECODE (
                                                              qst.person_type,
                                                              'EMPLOYEE', DECODE (
                                                                             qst.status,
                                                                             'APPROVED', 'EMP_PROMOTED',
                                                                             'NEW', 'SMA_INITIATED'),
                                                              'APPLICANT', DECODE (
                                                                              qst.status,
                                                                              'APPROVED', 'EMP_JOINED',
                                                                              'NEW', 'SMA_INITIATED'))
                                                      FROM qag_hr_sma_transaction_tab qst
                                                     WHERE     qst.pos_ref_number =
                                                                  qsprt.position_ref_num
                                                           AND qst.status !=
                                                                  'REJECTED'),
                                                   qag_srf_gems_general_pkg.hdr_status (
                                                      qslt.srf_header_id,
                                                      qslt.srf_line_id,
                                                      qsprt.position_ref_id)))))
                  srf_status_used,
               qsht.srf_type srf_type,
               DECODE (
                  (SELECT DECODE (
                             qst.person_type,
                             'EMPLOYEE', DECODE (qst.status,
                                                 'APPROVED', 'PROMOTED',
                                                 'NEW', 'SMA'),
                             'APPLICANT', DECODE (qst.status,
                                                  'APPROVED', 'ONBOARDED',
                                                  'NEW', 'SMA'))
                     FROM qag_hr_sma_transaction_tab qst
                    WHERE     qst.pos_ref_number = qsprt.position_ref_num
                          AND qst.status != 'REJECTED'),
                  'REPLACED', 'SWAPPED',
                  (SELECT DECODE (
                             qst.person_type,
                             'EMPLOYEE', DECODE (qst.status,
                                                 'APPROVED', 'PROMOTED',
                                                 'NEW', 'SMA'),
                             'APPLICANT', DECODE (qst.status,
                                                  'APPROVED', 'ONBOARDED',
                                                  'NEW', 'SMA'))
                     FROM qag_hr_sma_transaction_tab qst
                    WHERE     qst.pos_ref_number = qsprt.position_ref_num
                          AND qst.status != 'REJECTED'))
                  srf_pos_discription,
               (SELECT papf.employee_number
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_no,
               (SELECT INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_name,
               NVL (qslt.replacement, 'N') replace_flag,
               qsht.budget_period,
               qsht.remarks comments,
               qspht.last_update_date actual_sour_date,
               qsht.department_id,
               qsht.division_id,
               qsht.company_id,
               qslt.job_code,
               qslt.position_id,
               qslt.grade_id,
               INITCAP (
                  qag_srf_utilities.get_person_name (
                     qslt.reporting_to_person_id))
                  hiring_staff,
               qslt.reporting_to_person_id hiring_person_id,
               (SELECT employee_number
                  FROM per_all_people_f
                 WHERE     TRUNC (SYSDATE) BETWEEN effective_start_date
                                               AND effective_end_date
                       AND current_employee_flag = 'Y'
                       AND person_id = qslt.reporting_to_person_id)
                  hiring_staff_number
          FROM qag_srf_headers_t qsht,
               qr_srf.qag_srf_posting_headers_t qspht,
               qag_srf_lines_t qslt,
               qag_srf_position_ref_t qsprt,
               per_position_extra_info ppei,
               hr_all_positions_f hap
         WHERE     qsht.srf_header_id = qslt.srf_header_id
               AND qsprt.position_ref_id = qspht.position_ref_id(+)
               AND qsprt.srf_line_id = qslt.srf_line_id
               AND hap.position_id = ppei.position_id
               AND ppei.information_type = 'QAG_POS_EXTRA_INFO'
               AND ppei.position_extra_info_id = qsprt.position_extra_info_id
               AND qsht.status NOT IN ('CEASED') -- Ceased records filter condition due to budget block period
               AND ppei.poei_information7 IS NULL
               AND qsprt.position_ref_num NOT IN
                      (SELECT paaf2.ass_attribute16
                         FROM per_all_assignments_f paaf2
                        WHERE     paaf2.assignment_status_type_id IN (132, 6)
                              AND paaf2.ass_attribute17 IS NOT NULL
                              AND paaf2.ass_attribute16 IS NOT NULL)
               AND qsprt.position_ref_num NOT IN
                      (SELECT qst2.ass_attribute16
                         FROM qair.qag_msma_all_assignments_t qst2
                        WHERE     qst2.status != 'REJECTED'
                              AND qst2.ass_attribute16 IS NOT NULL)
               AND TRUNC (SYSDATE) BETWEEN hap.effective_start_date
                                       AND hap.effective_end_date
               AND (   NVL (qslt.replacement, 'N') = 'Y'
                    OR (   qsht.budget_year
                        || '-'
                        || UPPER (
                              ( (SELECT DISTINCT haou1.NAME
                                   FROM hr_all_organization_units haou1
                                  WHERE haou1.organization_id =
                                           get_org_id (qsht.department_id,
                                                       'DIV'))
                               UNION
                               (SELECT DISTINCT haou1.NAME
                                  FROM hr_all_organization_units haou1
                                 WHERE     1 = 1
                                       AND ROWNUM = 1
                                       AND haou1.organization_id =
                                              get_org_id (qsht.department_id,
                                                          'STN'))))) NOT IN
                          (    SELECT    NVL (REGEXP_SUBSTR (description,
                                                             '[^,]+',
                                                             1,
                                                             LEVEL),
                                              0)
                                      || '-'
                                      || UPPER (meaning)
                                         div_name
                                 FROM (SELECT (description), meaning
                                         FROM fnd_lookup_values
                                        WHERE lookup_type =
                                                 'QAG_SRF_DIVISION_DISPLAY_FY')
                           CONNECT BY LEVEL <=
                                           LENGTH (description)
                                         - LENGTH (
                                              REPLACE (description, ','))
                                         + 1))
        UNION
        SELECT qsht.ROWID row_id,
               qsht.srf_header_id,
               qslt.srf_line_id,
               qsprt.position_ref_id,
               qsht.budget_year,
               (SELECT tag
                  FROM fnd_lookup_values flv
                 WHERE     flv.lookup_type = 'QAG_GEMS-SRF_FY_VAL'
                       AND enabled_flag = 'Y'
                       AND lookup_code = qsht.budget_year)
                  fy_year,
               DECODE (qsht.budgeted, 'Y', 'Yes', 'No') budgeted,
               qsht.cost_center,
               qsht.srf_number,
               NULL,
               qag_srf_utilities.get_position_name (qslt.position_id)
                  position_title,
               (SELECT pg.NAME
                  FROM per_grades pg
                 WHERE     TRUNC (SYSDATE) BETWEEN TRUNC (pg.date_from)
                                               AND TRUNC (
                                                      NVL (pg.date_to,
                                                           SYSDATE + 1))
                       AND pg.grade_id = qslt.grade_id)
                  grade,
               qag_srf_utilities.get_department (qsht.department_id)
                  department_name,
               ( (SELECT DISTINCT haou1.NAME
                    FROM hr_all_organization_units haou1
                   WHERE haou1.organization_id =
                            get_org_id (qsht.department_id, 'DIV'))
                UNION
                (SELECT DISTINCT haou1.NAME
                   FROM hr_all_organization_units haou1
                  WHERE     1 = 1
                        AND ROWNUM = 1
                        AND haou1.organization_id =
                               get_org_id (qsht.department_id, 'STN')))
                  division_name,
               ( (SELECT DISTINCT haou1.NAME
                    FROM hr_all_organization_units haou1
                   WHERE haou1.organization_id =
                            get_org_id (qsht.department_id, 'BU'))
                UNION
                (SELECT DISTINCT haou1.NAME
                   FROM hr_all_organization_units haou1
                  WHERE     1 = 1
                        AND ROWNUM = 1
                        AND haou1.organization_id =
                               get_org_id (qsht.department_id, 'CTY')))
                  business_unit_name,
               qslt.sourcing_initiation_date,
               qslt.boarding_effective_date onboarding_effective_date,
               NULL,
               NULL,
               NULL,
               INITCAP (qag_srf_utilities.get_person_name (
                           NVL (
                              (SELECT ppx.person_id
                                 FROM per_all_people_f ppx
                                WHERE     ppx.employee_number =
                                             qsht.attribute9
                                      AND ROWNUM < 2),
                              qslt.reporting_to_person_id)))
                  reporting_to,
               NVL (
                  (SELECT ppx.person_id
                     FROM per_all_people_f ppx
                    WHERE     ppx.employee_number = qsht.attribute9
                          AND ROWNUM < 2),
                  qslt.reporting_to_person_id)
                  reporting_person_id,
               (SELECT employee_number
                  FROM per_all_people_f
                 WHERE     TRUNC (SYSDATE) BETWEEN effective_start_date
                                               AND effective_end_date
                       AND current_employee_flag = 'Y'
                       AND person_id =
                              NVL (
                                 (SELECT ppx.person_id
                                    FROM per_all_people_f ppx
                                   WHERE     ppx.employee_number =
                                                qsht.attribute9
                                         AND ROWNUM < 2),
                                 qslt.reporting_to_person_id))
                  reporting_staff_number,
               NULL,
               DECODE (
                  NVL (
                     (SELECT DECODE (
                                qst.person_type,
                                'EMPLOYEE', DECODE (
                                               qst.status,
                                               'APPROVED', 'EMP_PROMOTED',
                                               'NEW', 'SMA_INITIATED'),
                                'APPLICANT', DECODE (
                                                qst.status,
                                                'APPROVED', 'EMP_JOINED',
                                                'NEW', 'SMA_INITIATED'))
                        FROM qag_hr_sma_transaction_tab qst
                       WHERE     qst.pos_ref_number = qsprt.position_ref_num
                             AND qst.status != 'REJECTED'),
                     NVL (
                        (SELECT DECODE (
                                   qst.status,
                                   'HIRED', 'EMP_JOINED',
                                   'APPROVED', 'SMA_INITIATED',
                                   'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                           FROM qair.qag_msma_all_assignments_t qst
                          WHERE     qst.ass_attribute16 =
                                       qsprt.position_ref_num
                                AND qst.status != 'REJECTED'),
                        qsht.status)),
                  'REPLACED', 'SWAPPED',
                  NVL (
                     (SELECT DECODE (
                                qst.person_type,
                                'EMPLOYEE', DECODE (
                                               qst.status,
                                               'APPROVED', 'EMP_PROMOTED',
                                               'NEW', 'SMA_INITIATED'),
                                'APPLICANT', DECODE (
                                                qst.status,
                                                'APPROVED', 'EMP_JOINED',
                                                'NEW', 'SMA_INITIATED'))
                        FROM qag_hr_sma_transaction_tab qst
                       WHERE     qst.pos_ref_number = qsprt.position_ref_num
                             AND qst.status != 'REJECTED'),
                     NVL (
                        (SELECT DECODE (
                                   qst.status,
                                   'HIRED', 'EMP_JOINED',
                                   'APPROVED', 'SMA_INITIATED',
                                   'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                           FROM qair.qag_msma_all_assignments_t qst
                          WHERE     qst.ass_attribute16 =
                                       qsprt.position_ref_num
                                AND qst.status != 'REJECTED'),
                        qsht.status)))
                  status,
               NVL (qsprt.attribute5,
                    DECODE (hold_status, 'Y', 'ON_HOLD', NULL))
                  position_status,
               NULL,
               NULL,
               NULL,
               --qag_srf_utilities.GET_PERSON_NAME(ppei.POEI_INFORMATION3) REP_PERSON_NAME
               1 is_update_sucess,
               qsht.last_update_date,
               NVL (
                  (SELECT DISTINCT papf.applicant_number
                     FROM qag_hr_sma_transaction_tab qst,
                          per_all_people_f papf
                    WHERE     qst.person_id = papf.person_id
                          AND qst.person_type = 'APPLICANT'
                          AND qst.status = 'NEW'
                          AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                          AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                                  AND papf.effective_end_date
                          AND qst.pos_ref_number = qsprt.position_ref_num),
                  (SELECT DISTINCT papf.applicant_number
                     FROM qair.qag_msma_all_assignments_t qst,
                          per_all_people_f papf
                    WHERE     qst.person_id = papf.person_id
                          AND qst.status != 'REJECTED'
                          AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                          AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                                  AND papf.effective_end_date
                          AND qst.ass_attribute16 = qsprt.position_ref_num))
                  applicant_number,
               NVL (
                  (SELECT INITCAP (
                                papf.title
                             || ' '
                             || papf.first_name
                             || ' '
                             || papf.middle_names
                             || ' '
                             || papf.last_name)
                             full_name
                     FROM qag_hr_sma_transaction_tab qst,
                          per_all_people_f papf
                    WHERE     qst.person_id = papf.person_id
                          AND qst.person_type = 'APPLICANT'
                          AND qst.status != 'REJECTED'
                          AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                          AND qst.pos_ref_number = qsprt.position_ref_num
                          AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                                  AND papf.effective_end_date),
                  (SELECT INITCAP (
                                papf.title
                             || ' '
                             || papf.first_name
                             || ' '
                             || papf.middle_names
                             || ' '
                             || papf.last_name)
                             full_name
                     FROM qair.qag_msma_all_assignments_t qst,
                          per_all_people_f papf
                    WHERE     qst.person_id = papf.person_id
                          AND qst.status != 'REJECTED'
                          AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                          AND qst.ass_attribute16 = qsprt.position_ref_num
                          AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                                  AND papf.effective_end_date))
                  applicant_name,
               NVL (
                  (SELECT INITCAP (
                                papf.title
                             || ' '
                             || papf.first_name
                             || ' '
                             || papf.middle_names
                             || ' '
                             || papf.last_name)
                             full_name
                     FROM qag_hr_sma_transaction_tab qst, per_people_x papf
                    WHERE     qst.person_id = papf.person_id
                          AND qst.pos_ref_number = qsprt.position_ref_num
                          AND qst.person_type = 'EMPLOYEE'
                          AND qst.status != 'REJECTED'),
                  (SELECT INITCAP (
                                papf.title
                             || ' '
                             || papf.first_name
                             || ' '
                             || papf.middle_names
                             || ' '
                             || papf.last_name)
                             full_name
                     FROM qair.qag_msma_all_assignments_t qst,
                          per_people_x papf
                    WHERE     qst.person_id = papf.person_id
                          AND qst.ass_attribute16 = qsprt.position_ref_num
                          AND papf.employee_number IS NOT NULL
                          AND qst.status != 'REJECTED'))
                  employee_name,
               '' snp_xvn_number,
               '' snp_ivn_number,
               (SELECT meaning
                  FROM fnd_lookup_values
                 WHERE     lookup_type = 'QAG_SRF_STATUS'
                       AND enabled_flag = 'Y'
                       AND lookup_code =
                              DECODE (
                                 NVL (
                                    (SELECT DECODE (
                                               qst.person_type,
                                               'EMPLOYEE', DECODE (
                                                              qst.status,
                                                              'APPROVED', 'EMP_PROMOTED',
                                                              'NEW', 'SMA_INITIATED'),
                                               'APPLICANT', DECODE (
                                                               qst.status,
                                                               'APPROVED', 'EMP_JOINED',
                                                               'NEW', 'SMA_INITIATED'))
                                       FROM qag_hr_sma_transaction_tab qst
                                      WHERE     qst.pos_ref_number =
                                                   qsprt.position_ref_num
                                            AND qst.status != 'REJECTED'),
                                    NVL (
                                       (SELECT DECODE (
                                                  qst.status,
                                                  'HIRED', 'EMP_JOINED',
                                                  'APPROVED', 'SMA_INITIATED',
                                                  'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                                          FROM qair.qag_msma_all_assignments_t qst
                                         WHERE     qst.ass_attribute16 =
                                                      qsprt.position_ref_num
                                               AND qst.status != 'REJECTED'),
                                       qsht.status)),
                                 'REPLACED', 'SWAPPED',
                                 NVL (
                                    (SELECT DECODE (
                                               qst.person_type,
                                               'EMPLOYEE', DECODE (
                                                              qst.status,
                                                              'APPROVED', 'EMP_PROMOTED',
                                                              'NEW', 'SMA_INITIATED'),
                                               'APPLICANT', DECODE (
                                                               qst.status,
                                                               'APPROVED', 'EMP_JOINED',
                                                               'NEW', 'SMA_INITIATED'))
                                       FROM qag_hr_sma_transaction_tab qst
                                      WHERE     qst.pos_ref_number =
                                                   qsprt.position_ref_num
                                            AND qst.status != 'REJECTED'),
                                    NVL (
                                       (SELECT DECODE (
                                                  qst.status,
                                                  'HIRED', 'EMP_JOINED',
                                                  'APPROVED', 'SMA_INITIATED',
                                                  'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                                          FROM qair.qag_msma_all_assignments_t qst
                                         WHERE     qst.ass_attribute16 =
                                                      qsprt.position_ref_num
                                               AND qst.status != 'REJECTED'),
                                       qsht.status))))
                  srf_status_description,
               (SELECT tag
                  FROM fnd_lookup_values
                 WHERE     lookup_type = 'QAG_SRF_STATUS'
                       AND enabled_flag = 'Y'
                       AND meaning =
                              (SELECT meaning
                                 FROM fnd_lookup_values
                                WHERE     lookup_type = 'QAG_SRF_STATUS'
                                      AND enabled_flag = 'Y'
                                      AND lookup_code =
                                             DECODE (
                                                NVL (
                                                   (SELECT DECODE (
                                                              qst.person_type,
                                                              'EMPLOYEE', DECODE (
                                                                             qst.status,
                                                                             'APPROVED', 'EMP_PROMOTED',
                                                                             'NEW', 'SMA_INITIATED'),
                                                              'APPLICANT', DECODE (
                                                                              qst.status,
                                                                              'APPROVED', 'EMP_JOINED',
                                                                              'NEW', 'SMA_INITIATED'))
                                                      FROM qag_hr_sma_transaction_tab qst
                                                     WHERE     qst.pos_ref_number =
                                                                  qsprt.position_ref_num
                                                           AND qst.status !=
                                                                  'REJECTED'),
                                                   NVL (
                                                      (SELECT DECODE (
                                                                 qst.status,
                                                                 'HIRED', 'EMP_JOINED',
                                                                 'APPROVED', 'SMA_INITIATED',
                                                                 'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                                                         FROM qair.qag_msma_all_assignments_t qst
                                                        WHERE     qst.ass_attribute16 =
                                                                     qsprt.position_ref_num
                                                              AND qst.status !=
                                                                     'REJECTED'),
                                                      qsht.status)),
                                                'REPLACED', 'SWAPPED',
                                                NVL (
                                                   (SELECT DECODE (
                                                              qst.person_type,
                                                              'EMPLOYEE', DECODE (
                                                                             qst.status,
                                                                             'APPROVED', 'EMP_PROMOTED',
                                                                             'NEW', 'SMA_INITIATED'),
                                                              'APPLICANT', DECODE (
                                                                              qst.status,
                                                                              'APPROVED', 'EMP_JOINED',
                                                                              'NEW', 'SMA_INITIATED'))
                                                      FROM qag_hr_sma_transaction_tab qst
                                                     WHERE     qst.pos_ref_number =
                                                                  qsprt.position_ref_num
                                                           AND qst.status !=
                                                                  'REJECTED'),
                                                   NVL (
                                                      (SELECT DECODE (
                                                                 qst.status,
                                                                 'HIRED', 'EMP_JOINED',
                                                                 'APPROVED', 'SMA_INITIATED',
                                                                 'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                                                         FROM qair.qag_msma_all_assignments_t qst
                                                        WHERE     qst.ass_attribute16 =
                                                                     qsprt.position_ref_num
                                                              AND qst.status !=
                                                                     'REJECTED'),
                                                      qsht.status)))))
                  srf_status_used,
               qsht.srf_type srf_type,
               '' srf_pos_discription,
               (SELECT papf.employee_number
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_no,
               (SELECT INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_name,
               NVL (qslt.replacement, 'N') replace_flag,
               qsht.budget_period,
               qsht.remarks comments,
               qspht.last_update_date actual_sour_date,
               qsht.department_id,
               qsht.division_id,
               qsht.company_id,
               qslt.job_code,
               qslt.position_id,
               qslt.grade_id,
               INITCAP (
                  qag_srf_utilities.get_person_name (
                     qslt.reporting_to_person_id))
                  hiring_staff,
               qslt.reporting_to_person_id hiring_person_id,
               (SELECT employee_number
                  FROM per_all_people_f
                 WHERE     TRUNC (SYSDATE) BETWEEN effective_start_date
                                               AND effective_end_date
                       AND current_employee_flag = 'Y'
                       AND person_id = qslt.reporting_to_person_id)
                  hiring_staff_number
          FROM qag_srf_headers_t qsht,
               qr_srf.qag_srf_posting_headers_t qspht,
               qag_srf_lines_t qslt,
               qag_srf_position_ref_t qsprt
         WHERE     qsht.srf_header_id = qslt.srf_header_id
               AND qsprt.position_ref_id = qspht.position_ref_id(+)
               AND qsprt.srf_line_id(+) = qslt.srf_line_id
               AND qsht.status = 'APPROVAL_IN_PROGRESS'
               AND (   NVL (qslt.replacement, 'N') = 'Y'
                    OR (   qsht.budget_year
                        || '-'
                        || UPPER (
                              ( (SELECT DISTINCT haou1.NAME
                                   FROM hr_all_organization_units haou1
                                  WHERE haou1.organization_id =
                                           get_org_id (qsht.department_id,
                                                       'DIV'))
                               UNION
                               (SELECT DISTINCT haou1.NAME
                                  FROM hr_all_organization_units haou1
                                 WHERE     1 = 1
                                       AND ROWNUM = 1
                                       AND haou1.organization_id =
                                              get_org_id (qsht.department_id,
                                                          'STN'))))) NOT IN
                          (    SELECT    NVL (REGEXP_SUBSTR (description,
                                                             '[^,]+',
                                                             1,
                                                             LEVEL),
                                              0)
                                      || '-'
                                      || UPPER (meaning)
                                         div_name
                                 FROM (SELECT (description), meaning
                                         FROM fnd_lookup_values
                                        WHERE lookup_type =
                                                 'QAG_SRF_DIVISION_DISPLAY_FY')
                           CONNECT BY LEVEL <=
                                           LENGTH (description)
                                         - LENGTH (
                                              REPLACE (description, ','))
                                         + 1))
        UNION
        SELECT qsht.ROWID row_id,
               qsht.srf_header_id,
               qslt.srf_line_id,
               qsprt.position_ref_id,
               qsht.budget_year,
               (SELECT tag
                  FROM fnd_lookup_values flv
                 WHERE     flv.lookup_type = 'QAG_GEMS-SRF_FY_VAL'
                       AND enabled_flag = 'Y'
                       AND lookup_code = qsht.budget_year)
                  fy_year,
               DECODE (qsht.budgeted, 'Y', 'Yes', 'No') budgeted,
               qsht.cost_center,
               qsht.srf_number,
               ppei.poei_information1 position_reference_no,
               qag_srf_utilities.get_position_name (qslt.position_id)
                  position_title,
               (SELECT pg.NAME
                  FROM per_grades pg
                 WHERE     TRUNC (SYSDATE) BETWEEN TRUNC (pg.date_from)
                                               AND TRUNC (
                                                      NVL (pg.date_to,
                                                           SYSDATE + 1))
                       AND pg.grade_id = qslt.grade_id)
                  grade,
               qag_srf_utilities.get_department (qsht.department_id)
                  department_name,
               ( (SELECT DISTINCT haou1.NAME
                    FROM hr_all_organization_units haou1
                   WHERE haou1.organization_id =
                            get_org_id (qsht.department_id, 'DIV'))
                UNION
                (SELECT DISTINCT haou1.NAME
                   FROM hr_all_organization_units haou1
                  WHERE     1 = 1
                        AND ROWNUM = 1
                        AND haou1.organization_id =
                               get_org_id (qsht.department_id, 'STN')))
                  division_name,
               ( (SELECT DISTINCT haou1.NAME
                    FROM hr_all_organization_units haou1
                   WHERE haou1.organization_id =
                            get_org_id (qsht.department_id, 'BU'))
                UNION
                (SELECT DISTINCT haou1.NAME
                   FROM hr_all_organization_units haou1
                  WHERE     1 = 1
                        AND ROWNUM = 1
                        AND haou1.organization_id =
                               get_org_id (qsht.department_id, 'CTY')))
                  business_unit_name,
               qslt.sourcing_initiation_date,
               qslt.boarding_effective_date onboarding_effective_date,
               ppei.poei_information4 srf_ivn_number,
               ppei.poei_information5 srf_xvn_number,
               UPPER (ppei.poei_information6) sma_number,
               INITCAP (qag_srf_utilities.get_person_name (
                           NVL (
                              (SELECT ppx.person_id
                                 FROM per_all_people_f ppx
                                WHERE     ppx.employee_number =
                                             qsht.attribute9
                                      AND ROWNUM < 2),
                              qslt.reporting_to_person_id)))
                  reporting_to,
               NVL (
                  (SELECT ppx.person_id
                     FROM per_all_people_f ppx
                    WHERE     ppx.employee_number = qsht.attribute9
                          AND ROWNUM < 2),
                  qslt.reporting_to_person_id)
                  reporting_person_id,
               (SELECT employee_number
                  FROM per_all_people_f
                 WHERE     TRUNC (SYSDATE) BETWEEN effective_start_date
                                               AND effective_end_date
                       AND current_employee_flag = 'Y'
                       AND person_id =
                              NVL (
                                 (SELECT ppx.person_id
                                    FROM per_all_people_f ppx
                                   WHERE     ppx.employee_number =
                                                qsht.attribute9
                                         AND ROWNUM < 2),
                                 qslt.reporting_to_person_id))
                  reporting_staff_number,
               (SELECT employee_number
                  FROM per_people_x
                 WHERE person_id = qst.person_id)
                  --ppei.poei_information7)
                  staff_number,
               --qsht.status,
               DECODE (
                  NVL (
                     (SELECT DECODE (
                                qst1.person_type,
                                'EMPLOYEE', DECODE (
                                               qst1.status,
                                               'APPROVED', 'EMP_PROMOTED',
                                               'NEW', 'SMA_INITIATED'),
                                'APPLICANT', DECODE (
                                                qst1.status,
                                                'APPROVED', 'EMP_JOINED',
                                                'NEW', 'SMA_INITIATED'))
                        FROM qag_hr_sma_transaction_tab qst1
                       WHERE qst1.sma_id = qst.sma_id),
                     qag_srf_gems_general_pkg.hdr_status (
                        qslt.srf_header_id,
                        qslt.srf_line_id,
                        qsprt.position_ref_id)),
                  'REPLACED', 'SWAPPED',
                  NVL (
                     (SELECT DECODE (
                                qst1.person_type,
                                'EMPLOYEE', DECODE (
                                               qst1.status,
                                               'APPROVED', 'EMP_PROMOTED',
                                               'NEW', 'SMA_INITIATED'),
                                'APPLICANT', DECODE (
                                                qst1.status,
                                                'APPROVED', 'EMP_JOINED',
                                                'NEW', 'SMA_INITIATED'))
                        FROM qag_hr_sma_transaction_tab qst1
                       WHERE qst1.sma_id = qst.sma_id),
                     qag_srf_gems_general_pkg.hdr_status (
                        qslt.srf_header_id,
                        qslt.srf_line_id,
                        qsprt.position_ref_id)))
                  status,
               -- DECODE (hold_status, 'Y', 'ON_HOLD', NULL) position_status,
               NVL (
                  qsprt.attribute5,
                  qag_srf_gems_general_pkg.pos_status (qslt.srf_header_id,
                                                       qslt.srf_line_id,
                                                       qsprt.position_ref_id))
                  position_status,
               DECODE (UPPER (NVL (hap.attribute4, 'Y')),
                       'YES', 'Y',
                       'NO', 'N',
                       'Y', 'Y',
                       'N', 'N')
                  jd_val_required_flg,
               DECODE (UPPER (NVL (hap.attribute1, 'Y')),
                       'YES', 'Y',
                       'NO', 'N',
                       'Y', 'Y',
                       'N', 'N')
                  jd_approved,
               --hap.attribute2 jd_approved_date1,
               (TO_CHAR (
                   CASE
                      WHEN fnd_date.canonical_to_date (hap.attribute2) <
                              (SYSDATE - 730)
                      THEN
                         TO_DATE ('2012/01/01 00:00:00',
                                  'yyyy/mm/dd hh24:mi:ss')
                      WHEN hap.attribute2 IS NULL
                      THEN
                         TO_DATE ('2012/01/01 00:00:00',
                                  'yyyy/mm/dd hh24:mi:ss')
                      ELSE
                         fnd_date.canonical_to_date (hap.attribute2)
                   END,
                   'YYYY/MM/DD HH24:MI:SS'))
                  jd_approved_date,
               --qag_srf_utilities.GET_PERSON_NAME(ppei.POEI_INFORMATION3) REP_PERSON_NAME
               qag_srf_gems_general_pkg.is_update_status (
                  qslt.srf_header_id,
                  qslt.srf_line_id,
                  qsprt.position_ref_id)
                  is_update_sucess,
               qst.last_update_date,
               (SELECT DISTINCT papf.applicant_number
                  FROM qag_hr_sma_transaction_tab qst, per_all_people_f papf
                 WHERE     qst.person_id = papf.person_id
                       AND qst.person_type = 'APPLICANT'
                       AND qst.status = 'NEW'
                       AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND qst.pos_ref_number = qsprt.position_ref_num)
                  applicant_number,
               (SELECT INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                          full_name
                  FROM qag_hr_sma_transaction_tab qst, per_all_people_f papf
                 WHERE     qst.person_id = papf.person_id
                       AND qst.person_type = 'APPLICANT'
                       AND qst.status != 'REJECTED'
                       AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                       AND qst.pos_ref_number = qsprt.position_ref_num
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date)
                  applicant_name,
               (SELECT INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                          full_name
                  FROM per_people_x papf
                 WHERE     papf.person_id = qst.person_id
                       AND papf.employee_number IS NOT NULL)
                  employee_name,
               '' snp_xvn_number,
               '' snp_ivn_number,
               (SELECT meaning
                  FROM fnd_lookup_values
                 WHERE     lookup_type = 'QAG_SRF_STATUS'
                       AND enabled_flag = 'Y'
                       AND lookup_code =
                              DECODE (
                                 NVL (
                                    (SELECT DECODE (
                                               qst1.person_type,
                                               'EMPLOYEE', DECODE (
                                                              qst1.status,
                                                              'APPROVED', 'EMP_PROMOTED',
                                                              'NEW', 'SMA_INITIATED'),
                                               'APPLICANT', DECODE (
                                                               qst1.status,
                                                               'APPROVED', 'EMP_JOINED',
                                                               'NEW', 'SMA_INITIATED'))
                                       FROM qag_hr_sma_transaction_tab qst1
                                      WHERE qst1.sma_id = qst.sma_id),
                                    qag_srf_gems_general_pkg.hdr_status (
                                       qslt.srf_header_id,
                                       qslt.srf_line_id,
                                       qsprt.position_ref_id)),
                                 'REPLACED', 'SWAPPED',
                                 NVL (
                                    (SELECT DECODE (
                                               qst1.person_type,
                                               'EMPLOYEE', DECODE (
                                                              qst1.status,
                                                              'APPROVED', 'EMP_PROMOTED',
                                                              'NEW', 'SMA_INITIATED'),
                                               'APPLICANT', DECODE (
                                                               qst1.status,
                                                               'APPROVED', 'EMP_JOINED',
                                                               'NEW', 'SMA_INITIATED'))
                                       FROM qag_hr_sma_transaction_tab qst1
                                      WHERE qst1.sma_id = qst.sma_id),
                                    qag_srf_gems_general_pkg.hdr_status (
                                       qslt.srf_header_id,
                                       qslt.srf_line_id,
                                       qsprt.position_ref_id))))
                  srf_status_description,
               (SELECT tag
                  FROM fnd_lookup_values
                 WHERE     lookup_type = 'QAG_SRF_STATUS'
                       AND enabled_flag = 'Y'
                       AND meaning =
                              (SELECT meaning
                                 FROM fnd_lookup_values
                                WHERE     lookup_type = 'QAG_SRF_STATUS'
                                      AND enabled_flag = 'Y'
                                      AND lookup_code =
                                             DECODE (
                                                NVL (
                                                   (SELECT DECODE (
                                                              qst1.person_type,
                                                              'EMPLOYEE', DECODE (
                                                                             qst1.status,
                                                                             'APPROVED', 'EMP_PROMOTED',
                                                                             'NEW', 'SMA_INITIATED'),
                                                              'APPLICANT', DECODE (
                                                                              qst1.status,
                                                                              'APPROVED', 'EMP_JOINED',
                                                                              'NEW', 'SMA_INITIATED'))
                                                      FROM qag_hr_sma_transaction_tab qst1
                                                     WHERE qst1.sma_id =
                                                              qst.sma_id),
                                                   qag_srf_gems_general_pkg.hdr_status (
                                                      qslt.srf_header_id,
                                                      qslt.srf_line_id,
                                                      qsprt.position_ref_id)),
                                                'REPLACED', 'SWAPPED',
                                                NVL (
                                                   (SELECT DECODE (
                                                              qst1.person_type,
                                                              'EMPLOYEE', DECODE (
                                                                             qst1.status,
                                                                             'APPROVED', 'EMP_PROMOTED',
                                                                             'NEW', 'SMA_INITIATED'),
                                                              'APPLICANT', DECODE (
                                                                              qst1.status,
                                                                              'APPROVED', 'EMP_JOINED',
                                                                              'NEW', 'SMA_INITIATED'))
                                                      FROM qag_hr_sma_transaction_tab qst1
                                                     WHERE qst1.sma_id =
                                                              qst.sma_id),
                                                   qag_srf_gems_general_pkg.hdr_status (
                                                      qslt.srf_header_id,
                                                      qslt.srf_line_id,
                                                      qsprt.position_ref_id)))))
                  srf_status_used,
               qsht.srf_type srf_type,
               DECODE (
                  DECODE (
                     qst.person_type,
                     'EMPLOYEE', DECODE (qst.status,
                                         'APPROVED', 'PROMOTED',
                                         'NEW', 'SMA'),
                     'APPLICANT', DECODE (qst.status,
                                          'APPROVED', 'ONBOARDED',
                                          'NEW', 'SMA')),
                  'REPLACED', 'SWAPPED',
                  DECODE (
                     qst.person_type,
                     'EMPLOYEE', DECODE (qst.status,
                                         'APPROVED', 'PROMOTED',
                                         'NEW', 'SMA'),
                     'APPLICANT', DECODE (qst.status,
                                          'APPROVED', 'ONBOARDED',
                                          'NEW', 'SMA')))
                  srf_pos_discription,
               (SELECT papf.employee_number
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_no,
               (SELECT INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_name,
               NVL (qslt.replacement, 'N') replace_flag,
               qsht.budget_period,
               qsht.remarks comments,
               qspht.last_update_date actual_sour_date,
               -- ,(select STATUS from QAG_HR_SMA_TRANSACTION_TAB QST WHERE QST.POS_REF_NUMBER = QSPRT.POSITION_REF_NUM ) srf_pos_discription
               qsht.department_id,
               qsht.division_id,
               qsht.company_id,
               qslt.job_code,
               qslt.position_id,
               qslt.grade_id,
               INITCAP (
                  qag_srf_utilities.get_person_name (
                     qslt.reporting_to_person_id))
                  hiring_staff,
               qslt.reporting_to_person_id hiring_person_id,
               (SELECT employee_number
                  FROM per_all_people_f
                 WHERE     TRUNC (SYSDATE) BETWEEN effective_start_date
                                               AND effective_end_date
                       AND current_employee_flag = 'Y'
                       AND person_id = qslt.reporting_to_person_id)
                  hiring_staff_number
          FROM qag_srf_headers_t qsht,
               qr_srf.qag_srf_posting_headers_t qspht,
               qag_srf_lines_t qslt,
               qag_srf_position_ref_t qsprt,
               per_position_extra_info ppei,
               hr_all_positions_f hap,
               qair.qag_hr_sma_transaction_tab qst
         WHERE     qsht.srf_header_id = qslt.srf_header_id
               AND qsprt.position_ref_id = qspht.position_ref_id(+)
               AND qsprt.srf_line_id = qslt.srf_line_id
               AND qst.pos_ref_number(+) = qsprt.position_ref_num
               AND hap.position_id = ppei.position_id
               AND ppei.information_type = 'QAG_POS_EXTRA_INFO'
               AND ppei.position_extra_info_id = qsprt.position_extra_info_id
               AND ppei.poei_information7 IS NOT NULL
               AND qst.status NOT IN ('REJECTED')
               AND qsht.status NOT IN ('CEASED') -- Ceased records filter condition due to budget block period
               AND TRUNC (SYSDATE) BETWEEN hap.effective_start_date
                                       AND hap.effective_end_date
               AND qsht.cost_center NOT IN ('236')
               AND (   NVL (qslt.replacement, 'N') = 'Y'
                    OR (   qsht.budget_year
                        || '-'
                        || UPPER (
                              ( (SELECT DISTINCT haou1.NAME
                                   FROM hr_all_organization_units haou1
                                  WHERE haou1.organization_id =
                                           get_org_id (qsht.department_id,
                                                       'DIV'))
                               UNION
                               (SELECT DISTINCT haou1.NAME
                                  FROM hr_all_organization_units haou1
                                 WHERE     1 = 1
                                       AND ROWNUM = 1
                                       AND haou1.organization_id =
                                              get_org_id (qsht.department_id,
                                                          'STN'))))) NOT IN
                          (    SELECT    NVL (REGEXP_SUBSTR (description,
                                                             '[^,]+',
                                                             1,
                                                             LEVEL),
                                              0)
                                      || '-'
                                      || UPPER (meaning)
                                         div_name
                                 FROM (SELECT (description), meaning
                                         FROM fnd_lookup_values
                                        WHERE lookup_type =
                                                 'QAG_SRF_DIVISION_DISPLAY_FY')
                           CONNECT BY LEVEL <=
                                           LENGTH (description)
                                         - LENGTH (
                                              REPLACE (description, ','))
                                         + 1))
        UNION
        SELECT qsht.ROWID row_id,
               qsht.srf_header_id,
               qslt.srf_line_id,
               qsprt.position_ref_id,
               qsht.budget_year,
               flv1.tag fy_year,
               DECODE (qsht.budgeted, 'Y', 'Yes', 'No') budgeted,
               qsht.cost_center,
               qsht.srf_number,
               ppei.poei_information1 position_reference_no,
               qag_srf_utilities.get_position_name (qslt.position_id)
                  position_title,
               (SELECT pg.NAME
                  FROM per_grades pg
                 WHERE     TRUNC (SYSDATE) BETWEEN TRUNC (pg.date_from)
                                               AND TRUNC (
                                                      NVL (pg.date_to,
                                                           SYSDATE + 1))
                       AND pg.grade_id = qslt.grade_id)
                  grade,
               qsom.department_name department_name,
               qsom.division_station_name division_name,
               qsom.bu_country_name business_unit_name,
               qslt.sourcing_initiation_date,
               qslt.boarding_effective_date onboarding_effective_date,
               ppei.poei_information4 srf_ivn_number,
               ppei.poei_information5 srf_xvn_number,
               UPPER (ppei.poei_information6) sma_number,
               INITCAP (qag_srf_utilities.get_person_name (
                           NVL (
                              (SELECT ppx.person_id
                                 FROM per_all_people_f ppx
                                WHERE     ppx.employee_number =
                                             qsht.attribute9
                                      AND ROWNUM < 2),
                              qslt.reporting_to_person_id)))
                  reporting_to,
               NVL (
                  (SELECT ppx.person_id
                     FROM per_all_people_f ppx
                    WHERE     ppx.employee_number = qsht.attribute9
                          AND ROWNUM < 2),
                  qslt.reporting_to_person_id)
                  reporting_person_id,
               (qag_srf_utilities.get_staff_number (
                   NVL (
                      (SELECT ppx.person_id
                         FROM per_all_people_f ppx
                        WHERE     ppx.employee_number = qsht.attribute9
                              AND ROWNUM < 2),
                      qslt.reporting_to_person_id)))
                  reporting_staff_number,
               emp_det.employee_number staff_number,
               (DECODE (
                   qag_srf_gems_general_pkg.hdr_status (
                      qslt.srf_header_id,
                      qslt.srf_line_id,
                      qsprt.position_ref_id),
                   'REPLACED', 'SWAPPED',
                   NVL (
                      emp_det.emp_status,
                      NVL (
                         appl_det.appl_status,
                         qag_srf_gems_general_pkg.hdr_status (
                            qslt.srf_header_id,
                            qslt.srf_line_id,
                            qsprt.position_ref_id)))))
                  status,
               NVL (
                  qsprt.attribute5,
                  qag_srf_gems_general_pkg.pos_status (qslt.srf_header_id,
                                                       qslt.srf_line_id,
                                                       qsprt.position_ref_id))
                  position_status,
               DECODE (UPPER (NVL (hap.attribute4, 'Y')),
                       'YES', 'Y',
                       'NO', 'N',
                       'Y', 'Y',
                       'N', 'N')
                  jd_val_required_flg,
               DECODE (UPPER (NVL (hap.attribute1, 'Y')),
                       'YES', 'Y',
                       'NO', 'N',
                       'Y', 'Y',
                       'N', 'N')
                  jd_approved,
               (TO_CHAR (
                   CASE
                      WHEN fnd_date.canonical_to_date (hap.attribute2) <
                              (SYSDATE - 730)
                      THEN
                         TO_DATE ('2012/01/01 00:00:00',
                                  'yyyy/mm/dd hh24:mi:ss')
                      WHEN hap.attribute2 IS NULL
                      THEN
                         TO_DATE ('2012/01/01 00:00:00',
                                  'yyyy/mm/dd hh24:mi:ss')
                      ELSE
                         fnd_date.canonical_to_date (hap.attribute2)
                   END,
                   'YYYY/MM/DD HH24:MI:SS'))
                  jd_approved_date,
               --qag_srf_utilities.GET_PERSON_NAME(ppei.POEI_INFORMATION3) REP_PERSON_NAME
               qag_srf_gems_general_pkg.is_update_status (
                  qslt.srf_header_id,
                  qslt.srf_line_id,
                  qsprt.position_ref_id)
                  is_update_sucess,
               GREATEST (
                  NVL (emp_det.last_update_date, qsht.last_update_date),
                  NVL (appl_det.last_update_date, qsht.last_update_date))
                  last_update_date,
               DECODE (emp_det.emp_status,
                       'EMP_JOINED', '',
                       appl_det.applicant_number)
                  applicant_number,
               DECODE (emp_det.emp_status,
                       'EMP_JOINED', '',
                       appl_det.full_name)
                  applicant_name,
               emp_det.full_name employee_name,
               '' snp_xvn_number,
               '' snp_ivn_number,
               (SELECT meaning
                  FROM fnd_lookup_values
                 WHERE     lookup_type = 'QAG_SRF_STATUS'
                       AND enabled_flag = 'Y'
                       AND lookup_code =
                              (DECODE (
                                  qag_srf_gems_general_pkg.hdr_status (
                                     qslt.srf_header_id,
                                     qslt.srf_line_id,
                                     qsprt.position_ref_id),
                                  'REPLACED', 'SWAPPED',
                                  NVL (
                                     emp_det.emp_status,
                                     NVL (
                                        appl_det.appl_status,
                                        qag_srf_gems_general_pkg.hdr_status (
                                           qslt.srf_header_id,
                                           qslt.srf_line_id,
                                           qsprt.position_ref_id))))))
                  srf_status_description,
               (SELECT tag
                  FROM fnd_lookup_values
                 WHERE     lookup_type = 'QAG_SRF_STATUS'
                       AND enabled_flag = 'Y'
                       AND meaning =
                              (SELECT meaning
                                 FROM fnd_lookup_values
                                WHERE     lookup_type = 'QAG_SRF_STATUS'
                                      AND enabled_flag = 'Y'
                                      AND lookup_code =
                                             (DECODE (
                                                 qag_srf_gems_general_pkg.hdr_status (
                                                    qslt.srf_header_id,
                                                    qslt.srf_line_id,
                                                    qsprt.position_ref_id),
                                                 'REPLACED', 'SWAPPED',
                                                 NVL (
                                                    emp_det.emp_status,
                                                    NVL (
                                                       appl_det.appl_status,
                                                       qag_srf_gems_general_pkg.hdr_status (
                                                          qslt.srf_header_id,
                                                          qslt.srf_line_id,
                                                          qsprt.position_ref_id)))))))
                  srf_status_used,
               qsht.srf_type srf_type,
               (DECODE (
                   qag_srf_gems_general_pkg.hdr_status (
                      qslt.srf_header_id,
                      qslt.srf_line_id,
                      qsprt.position_ref_id),
                   'REPLACED', 'SWAPPED',
                   NVL (
                      emp_det.emp_status,
                      NVL (
                         appl_det.appl_status,
                         qag_srf_gems_general_pkg.hdr_status (
                            qslt.srf_header_id,
                            qslt.srf_line_id,
                            qsprt.position_ref_id)))))
                  srf_pos_discription,
               (SELECT papf.employee_number
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_no,
               (SELECT INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_name,
               NVL (qslt.replacement, 'N') replace_flag,
               qsht.budget_period,
               qsht.remarks comments,
               qspht.last_update_date actual_sour_date,
               qsht.department_id,
               qsht.division_id,
               qsht.company_id,
               qslt.job_code,
               qslt.position_id,
               qslt.grade_id,
               INITCAP (
                  qag_srf_utilities.get_person_name (
                     qslt.reporting_to_person_id))
                  hiring_staff,
               qslt.reporting_to_person_id hiring_person_id,
               (SELECT employee_number
                  FROM per_all_people_f
                 WHERE     TRUNC (SYSDATE) BETWEEN effective_start_date
                                               AND effective_end_date
                       AND current_employee_flag = 'Y'
                       AND person_id = qslt.reporting_to_person_id)
                  hiring_staff_number
          FROM qag_srf_headers_t qsht,
               qr_srf.qag_srf_posting_headers_t qspht,
               qag_srf_lines_t qslt,
               qag_srf_position_ref_t qsprt,
               per_position_extra_info ppei,
               hr_all_positions_f hap,
               fnd_lookup_values flv1,
               apps.qag_srf_org_matrix_v qsom,
               (SELECT DISTINCT
                       'EMP_JOINED' emp_status,
                       papf.employee_number,
                       papf.applicant_number,
                       INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                          full_name,
                       (SELECT paaf3.ass_attribute17
                          FROM per_all_assignments_f paaf3
                         WHERE     paaf3.assignment_id = paaf.assignment_id
                               AND paaf3.ass_attribute17 IS NOT NULL
                               AND ROWNUM < 2)
                          srf_number,
                       (SELECT paaf3.ass_attribute16
                          FROM per_all_assignments_f paaf3
                         WHERE     paaf3.assignment_id = paaf.assignment_id
                               AND paaf3.ass_attribute16 IS NOT NULL
                               AND ROWNUM < 2)
                          pos_ref,
                       papf.last_update_date
                  FROM per_all_people_f papf, per_all_assignments_f paaf
                 WHERE     papf.person_id = paaf.person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND paaf.primary_flag = 'Y'
                       AND paaf.assignment_status_type_id = 1
                       AND papf.person_id = paaf.person_id
                       AND paaf.effective_start_date >
                              (SELECT MAX (paaf2.effective_start_date)
                                 FROM per_all_assignments_f paaf2
                                WHERE     paaf2.assignment_id =
                                             paaf.assignment_id
                                      AND paaf2.person_id = papf.person_id
                                      AND paaf2.assignment_status_type_id IN
                                             (132, 6)
                                      AND paaf2.ass_attribute17 IS NOT NULL
                                      AND paaf2.ass_attribute16 IS NOT NULL)
                       AND papf.current_employee_flag = 'Y'
                       AND paaf.person_id = paaf.person_id) emp_det,
               (SELECT DISTINCT
                       'SMA_INITIATED' appl_status,
                       papf.applicant_number,
                       papf.employee_number,
                       INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                          full_name,
                       (SELECT paaf3.ass_attribute17
                          FROM per_all_assignments_f paaf3
                         WHERE     paaf3.assignment_id = paaf.assignment_id
                               AND paaf3.ass_attribute17 IS NOT NULL
                               AND ROWNUM < 2)
                          srf_number,
                       (SELECT paaf3.ass_attribute16
                          FROM per_all_assignments_f paaf3
                         WHERE     paaf3.assignment_id = paaf.assignment_id
                               AND paaf3.ass_attribute16 IS NOT NULL
                               AND ROWNUM < 2)
                          pos_ref,
                       paaf.last_update_date
                  FROM per_all_people_f papf, per_all_assignments_f paaf
                 --,per_periods_of_service_v pps
                 WHERE     papf.person_id = paaf.person_id
                       --  and pps.person_id = paaf.person_id
                       --   and trunc(pps.actual_termination_date) <= trunc(sysdate)
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       --  and trunc(sysdate) between paaf.effective_start_date and paaf.effective_end_date
                       AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                       AND paaf.assignment_status_type_id IN (132, 6)
                       AND paaf.ass_attribute17 IS NOT NULL
                       AND UPPER (papf.full_name) NOT LIKE
                              '%BATCH%APPLICANT%'
                       AND paaf.ass_attribute16 IS NOT NULL) appl_det
         WHERE     qsht.srf_header_id = qslt.srf_header_id
               AND qsprt.position_ref_id = qspht.position_ref_id(+)
               AND qsprt.srf_line_id = qslt.srf_line_id
               AND qsht.department_id = qsom.department_id
               AND emp_det.pos_ref(+) = qsprt.position_ref_num
               AND appl_det.pos_ref(+) = qsprt.position_ref_num
               AND hap.position_id = ppei.position_id
               AND qslt.position_id = ppei.position_id
               AND qsht.srf_number = ppei.poei_information2
               AND qsprt.position_ref_num = ppei.poei_information1
               AND flv1.lookup_type = 'QAG_GEMS-SRF_FY_VAL'
               AND qsht.status NOT IN ('CEASED') -- Ceased status for Budget block period
               AND flv1.enabled_flag = 'Y'
               AND flv1.lookup_code = qsht.budget_year
               AND qsprt.position_ref_num IN
                      (SELECT paaf2.ass_attribute16
                         FROM per_all_assignments_f paaf2
                        WHERE     paaf2.assignment_status_type_id IN (132, 6)
                              AND paaf2.ass_attribute17 IS NOT NULL
                              AND paaf2.ass_attribute16 IS NOT NULL)
               AND qsprt.position_ref_num NOT IN
                      (SELECT paaf2.ass_attribute16
                         FROM per_all_assignments_f paaf2,
                              per_periods_of_service_v pps
                        WHERE     paaf2.assignment_status_type_id IN (132, 6)
                              AND paaf2.ass_attribute17 IS NOT NULL
                              AND paaf2.ass_attribute16 IS NOT NULL
                              AND pps.person_id = paaf2.person_id
                              AND TRUNC (pps.actual_termination_date) <=
                                     TRUNC (SYSDATE))
               AND qsprt.position_ref_num NOT IN
                      (SELECT qst.pos_ref_number
                         FROM qag_hr_sma_transaction_tab qst
                        WHERE qst.status NOT IN ('REJECTED'))
               --Added by Prathap Nagarajan on 23-Mar-2014 for including MSMA Tables
               AND qsprt.position_ref_num NOT IN
                      (SELECT qst.ass_attribute16
                         FROM qair.qag_msma_all_assignments_t qst
                        WHERE     qst.status NOT IN ('REJECTED')
                              AND qst.ass_attribute16 IS NOT NULL)
               --Added by Prathap Nagarajan on 23-Mar-2014 for including MSMA Tables
               AND ppei.information_type = 'QAG_POS_EXTRA_INFO'
               AND (DECODE (
                       qag_srf_gems_general_pkg.hdr_status (
                          qslt.srf_header_id,
                          qslt.srf_line_id,
                          qsprt.position_ref_id),
                       'REPLACED', 'SWAPPED',
                       NVL (
                          emp_det.emp_status,
                          NVL (
                             appl_det.appl_status,
                             qag_srf_gems_general_pkg.hdr_status (
                                qslt.srf_header_id,
                                qslt.srf_line_id,
                                qsprt.position_ref_id))))) NOT IN
                      ('PUBLISHED', 'APPROVED')
               AND ppei.position_extra_info_id = qsprt.position_extra_info_id
               AND TRUNC (SYSDATE) BETWEEN hap.effective_start_date
                                       AND hap.effective_end_date
               AND (   NVL (qslt.replacement, 'N') = 'Y'
                    OR (   qsht.budget_year
                        || '-'
                        || UPPER (
                              ( (SELECT DISTINCT haou1.NAME
                                   FROM hr_all_organization_units haou1
                                  WHERE haou1.organization_id =
                                           get_org_id (qsht.department_id,
                                                       'DIV'))
                               UNION
                               (SELECT DISTINCT haou1.NAME
                                  FROM hr_all_organization_units haou1
                                 WHERE     1 = 1
                                       AND ROWNUM = 1
                                       AND haou1.organization_id =
                                              get_org_id (qsht.department_id,
                                                          'STN'))))) NOT IN
                          (    SELECT    NVL (REGEXP_SUBSTR (description,
                                                             '[^,]+',
                                                             1,
                                                             LEVEL),
                                              0)
                                      || '-'
                                      || UPPER (meaning)
                                         div_name
                                 FROM (SELECT (description), meaning
                                         FROM fnd_lookup_values
                                        WHERE lookup_type =
                                                 'QAG_SRF_DIVISION_DISPLAY_FY')
                           CONNECT BY LEVEL <=
                                           LENGTH (description)
                                         - LENGTH (
                                              REPLACE (description, ','))
                                         + 1))
        UNION
        SELECT qsht.ROWID row_id,
               qsht.srf_header_id,
               qslt.srf_line_id,
               qsprt.position_ref_id,
               qsht.budget_year,
               flv1.tag fy_year,
               DECODE (qsht.budgeted, 'Y', 'Yes', 'No') budgeted,
               qsht.cost_center,
               qsht.srf_number,
               ppei.poei_information1 position_reference_no,
               qag_srf_utilities.get_position_name (qslt.position_id)
                  position_title,
               (SELECT pg.NAME
                  FROM per_grades pg
                 WHERE     TRUNC (SYSDATE) BETWEEN TRUNC (pg.date_from)
                                               AND TRUNC (
                                                      NVL (pg.date_to,
                                                           SYSDATE + 1))
                       AND pg.grade_id = qslt.grade_id)
                  grade,
               qsom.department_name department_name,
               qsom.division_station_name division_name,
               qsom.bu_country_name business_unit_name,
               qslt.sourcing_initiation_date,
               qslt.boarding_effective_date onboarding_effective_date,
               ppei.poei_information4 srf_ivn_number,
               ppei.poei_information5 srf_xvn_number,
               UPPER (ppei.poei_information6) sma_number,
               INITCAP (qag_srf_utilities.get_person_name (
                           NVL (
                              (SELECT ppx.person_id
                                 FROM per_all_people_f ppx
                                WHERE     ppx.employee_number =
                                             qsht.attribute9
                                      AND ROWNUM < 2),
                              qslt.reporting_to_person_id)))
                  reporting_to,
               NVL (
                  (SELECT ppx.person_id
                     FROM per_all_people_f ppx
                    WHERE     ppx.employee_number = qsht.attribute9
                          AND ROWNUM < 2),
                  qslt.reporting_to_person_id)
                  reporting_person_id,
               (qag_srf_utilities.get_staff_number (
                   NVL (
                      (SELECT ppx.person_id
                         FROM per_all_people_f ppx
                        WHERE     ppx.employee_number = qsht.attribute9
                              AND ROWNUM < 2),
                      qslt.reporting_to_person_id)))
                  reporting_staff_number,
               emp_det.employee_number staff_number,
               (DECODE (
                   qag_srf_gems_general_pkg.hdr_status (
                      qslt.srf_header_id,
                      qslt.srf_line_id,
                      qsprt.position_ref_id),
                   'REPLACED', 'SWAPPED',
                   NVL (
                      emp_det.emp_status,
                      NVL (
                         appl_det.appl_status,
                         qag_srf_gems_general_pkg.hdr_status (
                            qslt.srf_header_id,
                            qslt.srf_line_id,
                            qsprt.position_ref_id)))))
                  status,
               NVL (
                  qsprt.attribute5,
                  qag_srf_gems_general_pkg.pos_status (qslt.srf_header_id,
                                                       qslt.srf_line_id,
                                                       qsprt.position_ref_id))
                  position_status,
               DECODE (UPPER (NVL (hap.attribute4, 'Y')),
                       'YES', 'Y',
                       'NO', 'N',
                       'Y', 'Y',
                       'N', 'N')
                  jd_val_required_flg,
               DECODE (UPPER (NVL (hap.attribute1, 'Y')),
                       'YES', 'Y',
                       'NO', 'N',
                       'Y', 'Y',
                       'N', 'N')
                  jd_approved,
               (TO_CHAR (
                   CASE
                      WHEN fnd_date.canonical_to_date (hap.attribute2) <
                              (SYSDATE - 730)
                      THEN
                         TO_DATE ('2012/01/01 00:00:00',
                                  'yyyy/mm/dd hh24:mi:ss')
                      WHEN hap.attribute2 IS NULL
                      THEN
                         TO_DATE ('2012/01/01 00:00:00',
                                  'yyyy/mm/dd hh24:mi:ss')
                      ELSE
                         fnd_date.canonical_to_date (hap.attribute2)
                   END,
                   'YYYY/MM/DD HH24:MI:SS'))
                  jd_approved_date,
               --qag_srf_utilities.GET_PERSON_NAME(ppei.POEI_INFORMATION3) REP_PERSON_NAME
               qag_srf_gems_general_pkg.is_update_status (
                  qslt.srf_header_id,
                  qslt.srf_line_id,
                  qsprt.position_ref_id)
                  is_update_sucess,
               GREATEST (
                  NVL (emp_det.last_update_date, qsht.last_update_date),
                  NVL (appl_det.last_update_date, qsht.last_update_date))
                  last_update_date,
               DECODE (emp_det.emp_status,
                       'EMP_JOINED', '',
                       appl_det.applicant_number)
                  applicant_number,
               DECODE (emp_det.emp_status,
                       'EMP_JOINED', '',
                       appl_det.full_name)
                  applicant_name,
               emp_det.full_name employee_name,
               '' snp_xvn_number,
               '' snp_ivn_number,
               (SELECT meaning
                  FROM fnd_lookup_values
                 WHERE     lookup_type = 'QAG_SRF_STATUS'
                       AND enabled_flag = 'Y'
                       AND lookup_code =
                              (DECODE (
                                  qag_srf_gems_general_pkg.hdr_status (
                                     qslt.srf_header_id,
                                     qslt.srf_line_id,
                                     qsprt.position_ref_id),
                                  'REPLACED', 'SWAPPED',
                                  NVL (
                                     emp_det.emp_status,
                                     NVL (
                                        appl_det.appl_status,
                                        qag_srf_gems_general_pkg.hdr_status (
                                           qslt.srf_header_id,
                                           qslt.srf_line_id,
                                           qsprt.position_ref_id))))))
                  srf_status_description,
               (SELECT tag
                  FROM fnd_lookup_values
                 WHERE     lookup_type = 'QAG_SRF_STATUS'
                       AND enabled_flag = 'Y'
                       AND meaning =
                              (SELECT meaning
                                 FROM fnd_lookup_values
                                WHERE     lookup_type = 'QAG_SRF_STATUS'
                                      AND enabled_flag = 'Y'
                                      AND lookup_code =
                                             (DECODE (
                                                 qag_srf_gems_general_pkg.hdr_status (
                                                    qslt.srf_header_id,
                                                    qslt.srf_line_id,
                                                    qsprt.position_ref_id),
                                                 'REPLACED', 'SWAPPED',
                                                 NVL (
                                                    emp_det.emp_status,
                                                    NVL (
                                                       appl_det.appl_status,
                                                       qag_srf_gems_general_pkg.hdr_status (
                                                          qslt.srf_header_id,
                                                          qslt.srf_line_id,
                                                          qsprt.position_ref_id)))))))
                  srf_status_used,
               qsht.srf_type srf_type,
               (DECODE (
                   qag_srf_gems_general_pkg.hdr_status (
                      qslt.srf_header_id,
                      qslt.srf_line_id,
                      qsprt.position_ref_id),
                   'REPLACED', 'SWAPPED',
                   NVL (
                      emp_det.emp_status,
                      NVL (
                         appl_det.appl_status,
                         qag_srf_gems_general_pkg.hdr_status (
                            qslt.srf_header_id,
                            qslt.srf_line_id,
                            qsprt.position_ref_id)))))
                  srf_pos_discription,
               (SELECT papf.employee_number
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_no,
               (SELECT INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_name,
               NVL (qslt.replacement, 'N') replace_flag,
               qsht.budget_period,
               qsht.remarks comments,
               qspht.last_update_date actual_sour_date,
               qsht.department_id,
               qsht.division_id,
               qsht.company_id,
               qslt.job_code,
               qslt.position_id,
               qslt.grade_id,
               INITCAP (
                  qag_srf_utilities.get_person_name (
                     qslt.reporting_to_person_id))
                  hiring_staff,
               qslt.reporting_to_person_id hiring_person_id,
               (SELECT employee_number
                  FROM per_all_people_f
                 WHERE     TRUNC (SYSDATE) BETWEEN effective_start_date
                                               AND effective_end_date
                       AND current_employee_flag = 'Y'
                       AND person_id = qslt.reporting_to_person_id)
                  hiring_staff_number
          FROM qag_srf_headers_t qsht,
               qr_srf.qag_srf_posting_headers_t qspht,
               qag_srf_lines_t qslt,
               qag_srf_position_ref_t qsprt,
               per_position_extra_info ppei,
               hr_all_positions_f hap,
               fnd_lookup_values flv1,
               apps.qag_srf_org_matrix_v qsom,
               (SELECT DISTINCT
                       'EMP_JOINED' emp_status,
                       papf.employee_number,
                       papf.applicant_number,
                       INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                          full_name,
                       (SELECT paaf3.ass_attribute17
                          FROM per_all_assignments_f paaf3
                         WHERE     paaf3.assignment_id = paaf.assignment_id
                               AND paaf3.ass_attribute17 IS NOT NULL
                               AND ROWNUM < 2)
                          srf_number,
                       (SELECT paaf3.ass_attribute16
                          FROM per_all_assignments_f paaf3
                         WHERE     paaf3.assignment_id = paaf.assignment_id
                               AND paaf3.ass_attribute16 IS NOT NULL
                               AND ROWNUM < 2)
                          pos_ref,
                       papf.last_update_date
                  FROM per_all_people_f papf,
                       per_all_assignments_f paaf,
                       per_periods_of_service_v pps
                 WHERE     papf.person_id = paaf.person_id
                       AND pps.person_id = paaf.person_id
                       AND TRUNC (pps.actual_termination_date) <=
                              TRUNC (SYSDATE)
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       -- and paaf.PRIMARY_FLAG = 'Y'
                       -- and paaf.assignment_status_type_id = 1
                       AND papf.person_id = paaf.person_id
                       AND paaf.effective_start_date >
                              (SELECT MAX (paaf2.effective_start_date)
                                 FROM per_all_assignments_f paaf2
                                WHERE     paaf2.assignment_id =
                                             paaf.assignment_id
                                      AND paaf2.person_id = papf.person_id
                                      AND paaf2.assignment_status_type_id IN
                                             (132, 6)
                                      AND paaf2.ass_attribute17 IS NOT NULL
                                      AND paaf2.ass_attribute16 IS NOT NULL)
                       -- and papf.current_employee_flag = 'Y'
                       AND paaf.person_id = paaf.person_id) emp_det,
               (SELECT DISTINCT
                       'SMA_INITIATED' appl_status,
                       papf.applicant_number,
                       papf.employee_number,
                       INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                          full_name,
                       (SELECT paaf3.ass_attribute17
                          FROM per_all_assignments_f paaf3
                         WHERE     paaf3.assignment_id = paaf.assignment_id
                               AND paaf3.ass_attribute17 IS NOT NULL
                               AND ROWNUM < 2)
                          srf_number,
                       (SELECT paaf3.ass_attribute16
                          FROM per_all_assignments_f paaf3
                         WHERE     paaf3.assignment_id = paaf.assignment_id
                               AND paaf3.ass_attribute16 IS NOT NULL
                               AND ROWNUM < 2)
                          pos_ref,
                       paaf.last_update_date
                  FROM per_all_people_f papf, per_all_assignments_f paaf
                 --,per_periods_of_service_v pps
                 WHERE     papf.person_id = paaf.person_id
                       --  and pps.person_id = paaf.person_id
                       --  and trunc(pps.actual_termination_date) <= trunc(sysdate)
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       --  and trunc(sysdate) between paaf.effective_start_date and paaf.effective_end_date
                       AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                       AND paaf.assignment_status_type_id IN (132, 6)
                       AND paaf.ass_attribute17 IS NOT NULL
                       AND UPPER (papf.full_name) NOT LIKE
                              '%BATCH%APPLICANT%'
                       AND paaf.ass_attribute16 IS NOT NULL) appl_det
         WHERE     qsht.srf_header_id = qslt.srf_header_id
               AND qsprt.position_ref_id = qspht.position_ref_id(+)
               --  and qsprt.POSITION_REF_NUM = 'POS-912-APR-2013-0549-247'
               AND qsprt.srf_line_id = qslt.srf_line_id
               AND qsht.department_id = qsom.department_id
               AND emp_det.pos_ref(+) = qsprt.position_ref_num
               AND appl_det.pos_ref(+) = qsprt.position_ref_num
               AND hap.position_id = ppei.position_id
               AND qslt.position_id = ppei.position_id
               AND qsht.srf_number = ppei.poei_information2
               AND qsprt.position_ref_num = ppei.poei_information1
               AND flv1.lookup_type = 'QAG_GEMS-SRF_FY_VAL'
               AND qsht.status NOT IN ('CEASED') --Ceased status for Budget block period
               AND flv1.enabled_flag = 'Y'
               AND flv1.lookup_code = qsht.budget_year
               AND qsprt.position_ref_num IN
                      (SELECT paaf2.ass_attribute16
                         FROM per_all_assignments_f paaf2
                        WHERE     paaf2.assignment_status_type_id IN (132, 6)
                              AND paaf2.ass_attribute17 IS NOT NULL
                              AND paaf2.ass_attribute16 IS NOT NULL)
               AND qsprt.position_ref_num NOT IN
                      (SELECT qst.pos_ref_number
                         FROM qag_hr_sma_transaction_tab qst
                        WHERE qst.status NOT IN ('REJECTED'))
               --Added by Prathap Nagarajan on 23-Mar-2014 for including MSMA Tables
               AND qsprt.position_ref_num NOT IN
                      (SELECT qst.ass_attribute16
                         FROM qair.qag_msma_all_assignments_t qst
                        WHERE     qst.status NOT IN ('REJECTED')
                              AND qst.ass_attribute16 IS NOT NULL)
               --Added by Prathap Nagarajan on 23-Mar-2014 for including MSMA Tables
               AND ppei.information_type = 'QAG_POS_EXTRA_INFO'
               AND (DECODE (
                       qag_srf_gems_general_pkg.hdr_status (
                          qslt.srf_header_id,
                          qslt.srf_line_id,
                          qsprt.position_ref_id),
                       'REPLACED', 'SWAPPED',
                       NVL (
                          emp_det.emp_status,
                          NVL (
                             appl_det.appl_status,
                             qag_srf_gems_general_pkg.hdr_status (
                                qslt.srf_header_id,
                                qslt.srf_line_id,
                                qsprt.position_ref_id))))) NOT IN
                      ('PUBLISHED', 'APPROVED')
               AND ppei.position_extra_info_id = qsprt.position_extra_info_id
               AND TRUNC (SYSDATE) BETWEEN hap.effective_start_date
                                       AND hap.effective_end_date
               AND (   NVL (qslt.replacement, 'N') = 'Y'
                    OR (   qsht.budget_year
                        || '-'
                        || UPPER (
                              ( (SELECT DISTINCT haou1.NAME
                                   FROM hr_all_organization_units haou1
                                  WHERE haou1.organization_id =
                                           get_org_id (qsht.department_id,
                                                       'DIV'))
                               UNION
                               (SELECT DISTINCT haou1.NAME
                                  FROM hr_all_organization_units haou1
                                 WHERE     1 = 1
                                       AND ROWNUM = 1
                                       AND haou1.organization_id =
                                              get_org_id (qsht.department_id,
                                                          'STN'))))) NOT IN
                          (    SELECT    NVL (REGEXP_SUBSTR (description,
                                                             '[^,]+',
                                                             1,
                                                             LEVEL),
                                              0)
                                      || '-'
                                      || UPPER (meaning)
                                         div_name
                                 FROM (SELECT (description), meaning
                                         FROM fnd_lookup_values
                                        WHERE lookup_type =
                                                 'QAG_SRF_DIVISION_DISPLAY_FY')
                           CONNECT BY LEVEL <=
                                           LENGTH (description)
                                         - LENGTH (
                                              REPLACE (description, ','))
                                         + 1))
        UNION
        --Added by Prathap Nagarajan on 23-Mar-2014 for including MSMA Tables
        SELECT DISTINCT
               qsht.ROWID row_id,
               qsht.srf_header_id,
               qslt.srf_line_id,
               qsprt.position_ref_id,
               qsht.budget_year,
               (SELECT tag
                  FROM fnd_lookup_values flv
                 WHERE     flv.lookup_type = 'QAG_GEMS-SRF_FY_VAL'
                       AND enabled_flag = 'Y'
                       AND lookup_code = qsht.budget_year)
                  fy_year,
               DECODE (qsht.budgeted, 'Y', 'Yes', 'No') budgeted,
               qsht.cost_center,
               qsht.srf_number,
               ppei.poei_information1 position_reference_no,
               qag_srf_utilities.get_position_name (qslt.position_id)
                  position_title,
               (SELECT pg.NAME
                  FROM per_grades pg
                 WHERE     TRUNC (SYSDATE) BETWEEN TRUNC (pg.date_from)
                                               AND TRUNC (
                                                      NVL (pg.date_to,
                                                           SYSDATE + 1))
                       AND pg.grade_id = qslt.grade_id)
                  grade,
               qag_srf_utilities.get_department (qsht.department_id)
                  department_name,
               ( (SELECT DISTINCT haou1.NAME
                    FROM hr_all_organization_units haou1
                   WHERE haou1.organization_id =
                            get_org_id (qsht.department_id, 'DIV'))
                UNION
                (SELECT DISTINCT haou1.NAME
                   FROM hr_all_organization_units haou1
                  WHERE     1 = 1
                        AND ROWNUM = 1
                        AND haou1.organization_id =
                               get_org_id (qsht.department_id, 'STN')))
                  division_name,
               ( (SELECT DISTINCT haou1.NAME
                    FROM hr_all_organization_units haou1
                   WHERE haou1.organization_id =
                            get_org_id (qsht.department_id, 'BU'))
                UNION
                (SELECT DISTINCT haou1.NAME
                   FROM hr_all_organization_units haou1
                  WHERE     1 = 1
                        AND ROWNUM = 1
                        AND haou1.organization_id =
                               get_org_id (qsht.department_id, 'CTY')))
                  business_unit_name,
               qslt.sourcing_initiation_date,
               qslt.boarding_effective_date onboarding_effective_date,
               ppei.poei_information4 srf_ivn_number,
               ppei.poei_information5 srf_xvn_number,
               (SELECT qmabt.sma_number
                  FROM qair.qag_msma_all_batch_t qmabt,
                       qair.qag_msma_all_assignments_t qmaat
                 WHERE     qmabt.sma_batch_id = qmaat.sma_batch_id
                       AND qmaat.person_id = qmabt.person_id
                       AND qmaat.sma_batch_id = qmst.sma_batch_id
                       AND qmaat.person_id = qmst.person_id
                       AND qmabt.status != 'REJECTED'
                       AND ROWNUM < 2)
                  sma_number,
               INITCAP (qag_srf_utilities.get_person_name (
                           NVL (
                              (SELECT ppx.person_id
                                 FROM per_all_people_f ppx
                                WHERE     ppx.employee_number =
                                             qsht.attribute9
                                      AND ROWNUM < 2),
                              qslt.reporting_to_person_id)))
                  reporting_to,
               NVL (
                  (SELECT ppx.person_id
                     FROM per_all_people_f ppx
                    WHERE     ppx.employee_number = qsht.attribute9
                          AND ROWNUM < 2),
                  qslt.reporting_to_person_id)
                  reporting_person_id,
               (SELECT employee_number
                  FROM per_all_people_f
                 WHERE     TRUNC (SYSDATE) BETWEEN effective_start_date
                                               AND effective_end_date
                       AND current_employee_flag = 'Y'
                       AND person_id =
                              NVL (
                                 (SELECT ppx.person_id
                                    FROM per_all_people_f ppx
                                   WHERE     ppx.employee_number =
                                                qsht.attribute9
                                         AND ROWNUM < 2),
                                 qslt.reporting_to_person_id))
                  reporting_staff_number,
               (SELECT DISTINCT papf.employee_number
                  FROM qair.qag_msma_all_assignments_t qst, per_people_x papf
                 WHERE     qst.person_id = papf.person_id
                       AND qst.person_id = qmst.person_id
                       AND qst.ass_attribute16 = qsprt.position_ref_num
                       AND qst.status != 'REJECTED')
                  staff_number,
               DECODE (
                  NVL (
                     (SELECT DISTINCT
                             DECODE (qst.status,
                                     'HIRED', 'EMP_JOINED',
                                     'APPROVED', 'SMA_INITIATED',
                                     'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                        FROM qair.qag_msma_all_assignments_t qst
                       WHERE     qst.ass_attribute16 = qsprt.position_ref_num
                             AND qst.person_id = qmst.person_id
                             AND qst.status != 'REJECTED'),
                     qag_srf_gems_general_pkg.hdr_status (
                        qslt.srf_header_id,
                        qslt.srf_line_id,
                        qsprt.position_ref_id)),
                  'REPLACED', 'SWAPPED',
                  NVL (
                     (SELECT DISTINCT
                             DECODE (qst.status,
                                     'HIRED', 'EMP_JOINED',
                                     'APPROVED', 'SMA_INITIATED',
                                     'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                        FROM qair.qag_msma_all_assignments_t qst
                       WHERE     qst.ass_attribute16 = qsprt.position_ref_num
                             AND qst.person_id = qmst.person_id
                             AND qst.status != 'REJECTED'),
                     qag_srf_gems_general_pkg.hdr_status (
                        qslt.srf_header_id,
                        qslt.srf_line_id,
                        qsprt.position_ref_id)))
                  status,
               NVL (
                  qsprt.attribute5,
                  qag_srf_gems_general_pkg.pos_status (qslt.srf_header_id,
                                                       qslt.srf_line_id,
                                                       qsprt.position_ref_id))
                  position_status,
               DECODE (UPPER (NVL (hap.attribute4, 'Y')),
                       'YES', 'Y',
                       'NO', 'N',
                       'Y', 'Y',
                       'N', 'N')
                  jd_val_required_flg,
               DECODE (UPPER (NVL (hap.attribute1, 'Y')),
                       'YES', 'Y',
                       'NO', 'N',
                       'Y', 'Y',
                       'N', 'N')
                  jd_approved,
               (TO_CHAR (
                   CASE
                      WHEN fnd_date.canonical_to_date (hap.attribute2) <
                              (SYSDATE - 730)
                      THEN
                         TO_DATE ('2012/01/01 00:00:00',
                                  'yyyy/mm/dd hh24:mi:ss')
                      WHEN hap.attribute2 IS NULL
                      THEN
                         TO_DATE ('2012/01/01 00:00:00',
                                  'yyyy/mm/dd hh24:mi:ss')
                      ELSE
                         fnd_date.canonical_to_date (hap.attribute2)
                   END,
                   'YYYY/MM/DD HH24:MI:SS'))
                  jd_approved_date,
               qag_srf_gems_general_pkg.is_update_status (
                  qslt.srf_header_id,
                  qslt.srf_line_id,
                  qsprt.position_ref_id)
                  is_update_sucess,
               qmst.last_update_date,
               (SELECT DISTINCT papf.applicant_number
                  FROM qair.qag_msma_all_assignments_t qst,
                       per_all_people_f papf
                 WHERE     qst.person_id = papf.person_id
                       AND qst.person_id = qmst.person_id
                       AND qst.status != 'REJECTED'
                       AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND qst.ass_attribute16 = qsprt.position_ref_num)
                  applicant_number,
               (SELECT DISTINCT
                       INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                          full_name
                  FROM qair.qag_msma_all_assignments_t qst,
                       per_all_people_f papf
                 WHERE     qst.person_id = papf.person_id
                       AND qst.person_id = qmst.person_id
                       AND qst.status != 'REJECTED'
                       AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                       AND qst.ass_attribute16 = qsprt.position_ref_num
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date)
                  applicant_name,
               (SELECT DISTINCT
                       INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                          full_name
                  FROM qair.qag_msma_all_assignments_t qst, per_people_x papf
                 WHERE     qst.person_id = papf.person_id
                       AND qst.person_id = qmst.person_id
                       AND qst.ass_attribute16 = qsprt.position_ref_num
                       AND papf.employee_number IS NOT NULL
                       AND qst.status != 'REJECTED')
                  employee_name,
               '' snp_xvn_number,
               '' snp_ivn_number,
               (SELECT meaning
                  FROM fnd_lookup_values
                 WHERE     lookup_type = 'QAG_SRF_STATUS'
                       AND enabled_flag = 'Y'
                       AND lookup_code =
                              DECODE (
                                 NVL (
                                    (SELECT DISTINCT
                                            DECODE (
                                               qst.status,
                                               'HIRED', 'EMP_JOINED',
                                               'APPROVED', 'SMA_INITIATED',
                                               'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                                       FROM qair.qag_msma_all_assignments_t qst
                                      WHERE     qst.ass_attribute16 =
                                                   qsprt.position_ref_num
                                            AND qst.person_id =
                                                   qmst.person_id
                                            AND qst.status != 'REJECTED'),
                                    qag_srf_gems_general_pkg.hdr_status (
                                       qslt.srf_header_id,
                                       qslt.srf_line_id,
                                       qsprt.position_ref_id)),
                                 'REPLACED', 'SWAPPED',
                                 NVL (
                                    (SELECT DISTINCT
                                            DECODE (
                                               qst.status,
                                               'HIRED', 'EMP_JOINED',
                                               'APPROVED', 'SMA_INITIATED',
                                               'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                                       FROM qair.qag_msma_all_assignments_t qst
                                      WHERE     qst.ass_attribute16 =
                                                   qsprt.position_ref_num
                                            AND qst.person_id =
                                                   qmst.person_id
                                            AND qst.status != 'REJECTED'),
                                    qag_srf_gems_general_pkg.hdr_status (
                                       qslt.srf_header_id,
                                       qslt.srf_line_id,
                                       qsprt.position_ref_id))))
                  srf_status_description,
               (SELECT tag
                  FROM fnd_lookup_values
                 WHERE     lookup_type = 'QAG_SRF_STATUS'
                       AND enabled_flag = 'Y'
                       AND meaning =
                              (SELECT meaning
                                 FROM fnd_lookup_values
                                WHERE     lookup_type = 'QAG_SRF_STATUS'
                                      AND enabled_flag = 'Y'
                                      AND lookup_code =
                                             DECODE (
                                                NVL (
                                                   (SELECT DISTINCT
                                                           DECODE (
                                                              qst.status,
                                                              'HIRED', 'EMP_JOINED',
                                                              'APPROVED', 'SMA_INITIATED',
                                                              'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                                                      FROM qair.qag_msma_all_assignments_t qst
                                                     WHERE     qst.ass_attribute16 =
                                                                  qsprt.position_ref_num
                                                           AND qst.person_id =
                                                                  qmst.person_id
                                                           AND qst.status !=
                                                                  'REJECTED'),
                                                   qag_srf_gems_general_pkg.hdr_status (
                                                      qslt.srf_header_id,
                                                      qslt.srf_line_id,
                                                      qsprt.position_ref_id)),
                                                'REPLACED', 'SWAPPED',
                                                NVL (
                                                   (SELECT DISTINCT
                                                           DECODE (
                                                              qst.status,
                                                              'HIRED', 'EMP_JOINED',
                                                              'APPROVED', 'SMA_INITIATED',
                                                              'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                                                      FROM qair.qag_msma_all_assignments_t qst
                                                     WHERE     qst.ass_attribute16 =
                                                                  qsprt.position_ref_num
                                                           AND qst.person_id =
                                                                  qmst.person_id
                                                           AND qst.status !=
                                                                  'REJECTED'),
                                                   qag_srf_gems_general_pkg.hdr_status (
                                                      qslt.srf_header_id,
                                                      qslt.srf_line_id,
                                                      qsprt.position_ref_id)))))
                  srf_status_used,
               qsht.srf_type srf_type,
               DECODE (
                  (SELECT DISTINCT
                          DECODE (qst.status,
                                  'HIRED', 'EMP_JOINED',
                                  'APPROVED', 'SMA_INITIATED',
                                  'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                     FROM qair.qag_msma_all_assignments_t qst
                    WHERE     qst.ass_attribute16 = qsprt.position_ref_num
                          AND qst.person_id = qmst.person_id
                          AND qst.status != 'REJECTED'),
                  'REPLACED', 'SWAPPED',
                  (SELECT DISTINCT
                          DECODE (qst.status,
                                  'HIRED', 'EMP_JOINED',
                                  'APPROVED', 'SMA_INITIATED',
                                  'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                     FROM qair.qag_msma_all_assignments_t qst
                    WHERE     qst.ass_attribute16 = qsprt.position_ref_num
                          AND qst.person_id = qmst.person_id
                          AND qst.status != 'REJECTED'))
                  srf_pos_discription,
               (SELECT papf.employee_number
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_no,
               (SELECT INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_name,
               NVL (qslt.replacement, 'N') replace_flag,
               qsht.budget_period,
               qsht.remarks comments,
               qspht.last_update_date actual_sour_date,
               qsht.department_id,
               qsht.division_id,
               qsht.company_id,
               qslt.job_code,
               qslt.position_id,
               qslt.grade_id,
               INITCAP (
                  qag_srf_utilities.get_person_name (
                     qslt.reporting_to_person_id))
                  hiring_staff,
               qslt.reporting_to_person_id hiring_person_id,
               (SELECT employee_number
                  FROM per_all_people_f
                 WHERE     TRUNC (SYSDATE) BETWEEN effective_start_date
                                               AND effective_end_date
                       AND current_employee_flag = 'Y'
                       AND person_id = qslt.reporting_to_person_id)
                  hiring_staff_number
          FROM qag_srf_headers_t qsht,
               qr_srf.qag_srf_posting_headers_t qspht,
               qag_srf_lines_t qslt,
               qag_srf_position_ref_t qsprt,
               per_position_extra_info ppei,
               hr_all_positions_f hap,
               qair.qag_msma_all_assignments_t qmst
         WHERE     qsht.srf_header_id = qslt.srf_header_id
               AND qsprt.position_ref_id = qspht.position_ref_id(+)
               AND qsprt.srf_line_id = qslt.srf_line_id
               AND hap.position_id = ppei.position_id
               AND qmst.ass_attribute16(+) = qsprt.position_ref_num
               AND ppei.information_type = 'QAG_POS_EXTRA_INFO'
               AND ppei.position_extra_info_id = qsprt.position_extra_info_id
               AND ppei.poei_information7 IS NULL
               AND qmst.status NOT IN ('REJECTED')
               AND qsht.status NOT IN ('CEASED') --Ceased status for Budget block period
               AND qsprt.position_ref_num IN
                      (SELECT qst2.ass_attribute16
                         FROM qair.qag_msma_all_assignments_t qst2
                        WHERE     qst2.status != 'REJECTED'
                              AND qst2.ass_attribute16 IS NOT NULL)
               AND TRUNC (SYSDATE) BETWEEN hap.effective_start_date
                                       AND hap.effective_end_date
               AND (   NVL (qslt.replacement, 'N') = 'Y'
                    OR (   qsht.budget_year
                        || '-'
                        || UPPER (
                              ( (SELECT DISTINCT haou1.NAME
                                   FROM hr_all_organization_units haou1
                                  WHERE haou1.organization_id =
                                           get_org_id (qsht.department_id,
                                                       'DIV'))
                               UNION
                               (SELECT DISTINCT haou1.NAME
                                  FROM hr_all_organization_units haou1
                                 WHERE     1 = 1
                                       AND ROWNUM = 1
                                       AND haou1.organization_id =
                                              get_org_id (qsht.department_id,
                                                          'STN'))))) NOT IN
                          (    SELECT    NVL (REGEXP_SUBSTR (description,
                                                             '[^,]+',
                                                             1,
                                                             LEVEL),
                                              0)
                                      || '-'
                                      || UPPER (meaning)
                                         div_name
                                 FROM (SELECT (description), meaning
                                         FROM fnd_lookup_values
                                        WHERE lookup_type =
                                                 'QAG_SRF_DIVISION_DISPLAY_FY')
                           CONNECT BY LEVEL <=
                                           LENGTH (description)
                                         - LENGTH (
                                              REPLACE (description, ','))
                                         + 1))
        UNION
        SELECT DISTINCT
               qsht.ROWID row_id,
               qsht.srf_header_id,
               qslt.srf_line_id,
               qsprt.position_ref_id,
               qsht.budget_year,
               (SELECT tag
                  FROM fnd_lookup_values flv
                 WHERE     flv.lookup_type = 'QAG_GEMS-SRF_FY_VAL'
                       AND enabled_flag = 'Y'
                       AND lookup_code = qsht.budget_year)
                  fy_year,
               DECODE (qsht.budgeted, 'Y', 'Yes', 'No') budgeted,
               qsht.cost_center,
               qsht.srf_number,
               ppei.poei_information1 position_reference_no,
               qag_srf_utilities.get_position_name (qslt.position_id)
                  position_title,
               (SELECT pg.NAME
                  FROM per_grades pg
                 WHERE     TRUNC (SYSDATE) BETWEEN TRUNC (pg.date_from)
                                               AND TRUNC (
                                                      NVL (pg.date_to,
                                                           SYSDATE + 1))
                       AND pg.grade_id = qslt.grade_id)
                  grade,
               qag_srf_utilities.get_department (qsht.department_id)
                  department_name,
               ( (SELECT DISTINCT haou1.NAME
                    FROM hr_all_organization_units haou1
                   WHERE haou1.organization_id =
                            get_org_id (qsht.department_id, 'DIV'))
                UNION
                (SELECT DISTINCT haou1.NAME
                   FROM hr_all_organization_units haou1
                  WHERE     1 = 1
                        AND ROWNUM = 1
                        AND haou1.organization_id =
                               get_org_id (qsht.department_id, 'STN')))
                  division_name,
               ( (SELECT DISTINCT haou1.NAME
                    FROM hr_all_organization_units haou1
                   WHERE haou1.organization_id =
                            get_org_id (qsht.department_id, 'BU'))
                UNION
                (SELECT DISTINCT haou1.NAME
                   FROM hr_all_organization_units haou1
                  WHERE     1 = 1
                        AND ROWNUM = 1
                        AND haou1.organization_id =
                               get_org_id (qsht.department_id, 'CTY')))
                  business_unit_name,
               qslt.sourcing_initiation_date,
               qslt.boarding_effective_date onboarding_effective_date,
               ppei.poei_information4 srf_ivn_number,
               ppei.poei_information5 srf_xvn_number,
               (SELECT qmabt.sma_number
                  FROM qair.qag_msma_all_batch_t qmabt,
                       qair.qag_msma_all_assignments_t qmaat
                 WHERE     qmabt.sma_batch_id = qmaat.sma_batch_id
                       AND qmaat.person_id = qmabt.person_id
                       AND qmaat.sma_batch_id = qst.sma_batch_id
                       AND qmaat.person_id = qst.person_id
                       AND qmaat.status != 'REJECTED'
                       AND ROWNUM < 2)
                  sma_number,
               INITCAP (qag_srf_utilities.get_person_name (
                           NVL (
                              (SELECT ppx.person_id
                                 FROM per_all_people_f ppx
                                WHERE     ppx.employee_number =
                                             qsht.attribute9
                                      AND ROWNUM < 2),
                              qslt.reporting_to_person_id)))
                  reporting_to,
               NVL (
                  (SELECT ppx.person_id
                     FROM per_all_people_f ppx
                    WHERE     ppx.employee_number = qsht.attribute9
                          AND ROWNUM < 2),
                  qslt.reporting_to_person_id)
                  reporting_person_id,
               (SELECT employee_number
                  FROM per_all_people_f
                 WHERE     TRUNC (SYSDATE) BETWEEN effective_start_date
                                               AND effective_end_date
                       AND current_employee_flag = 'Y'
                       AND person_id =
                              NVL (
                                 (SELECT ppx.person_id
                                    FROM per_all_people_f ppx
                                   WHERE     ppx.employee_number =
                                                qsht.attribute9
                                         AND ROWNUM < 2),
                                 qslt.reporting_to_person_id))
                  reporting_staff_number,
               (SELECT employee_number
                  FROM per_people_x
                 WHERE person_id = qst.person_id)
                  --ppei.poei_information7)
                  staff_number,
               --qsht.status,
               DECODE (
                  NVL (
                     (SELECT DECODE (qst1.status,
                                     'HIRED', 'EMP_JOINED',
                                     'APPROVED', 'SMA_INITIATED',
                                     'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                        FROM qair.qag_msma_all_assignments_t qst1
                       WHERE     qst1.sma_batch_id = qst.sma_batch_id
                             AND qst1.person_id = qst.person_id),
                     qag_srf_gems_general_pkg.hdr_status (
                        qslt.srf_header_id,
                        qslt.srf_line_id,
                        qsprt.position_ref_id)),
                  'REPLACED', 'SWAPPED',
                  NVL (
                     (SELECT DECODE (qst1.status,
                                     'HIRED', 'EMP_JOINED',
                                     'APPROVED', 'SMA_INITIATED',
                                     'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                        FROM qair.qag_msma_all_assignments_t qst1
                       WHERE     qst1.sma_batch_id = qst.sma_batch_id
                             AND qst1.person_id = qst.person_id),
                     qag_srf_gems_general_pkg.hdr_status (
                        qslt.srf_header_id,
                        qslt.srf_line_id,
                        qsprt.position_ref_id)))
                  status,
               -- DECODE (hold_status, 'Y', 'ON_HOLD', NULL) position_status,
               NVL (
                  qsprt.attribute5,
                  qag_srf_gems_general_pkg.pos_status (qslt.srf_header_id,
                                                       qslt.srf_line_id,
                                                       qsprt.position_ref_id))
                  position_status,
               DECODE (UPPER (NVL (hap.attribute4, 'Y')),
                       'YES', 'Y',
                       'NO', 'N',
                       'Y', 'Y',
                       'N', 'N')
                  jd_val_required_flg,
               DECODE (UPPER (NVL (hap.attribute1, 'Y')),
                       'YES', 'Y',
                       'NO', 'N',
                       'Y', 'Y',
                       'N', 'N')
                  jd_approved,
               --hap.attribute2 jd_approved_date1,
               (TO_CHAR (
                   CASE
                      WHEN fnd_date.canonical_to_date (hap.attribute2) <
                              (SYSDATE - 730)
                      THEN
                         TO_DATE ('2012/01/01 00:00:00',
                                  'yyyy/mm/dd hh24:mi:ss')
                      WHEN hap.attribute2 IS NULL
                      THEN
                         TO_DATE ('2012/01/01 00:00:00',
                                  'yyyy/mm/dd hh24:mi:ss')
                      ELSE
                         fnd_date.canonical_to_date (hap.attribute2)
                   END,
                   'YYYY/MM/DD HH24:MI:SS'))
                  jd_approved_date,
               --qag_srf_utilities.GET_PERSON_NAME(ppei.POEI_INFORMATION3) REP_PERSON_NAME
               qag_srf_gems_general_pkg.is_update_status (
                  qslt.srf_header_id,
                  qslt.srf_line_id,
                  qsprt.position_ref_id)
                  is_update_sucess,
               qst.last_update_date,
               (SELECT DISTINCT papf.applicant_number
                  FROM qair.qag_msma_all_assignments_t qst1,
                       per_all_people_f papf
                 WHERE     qst1.person_id = papf.person_id
                       AND qst1.person_id = qst.person_id
                       AND qst1.status != 'REJECTED'
                       AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND qst1.ass_attribute16 = qsprt.position_ref_num)
                  applicant_number,
               (SELECT INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                          full_name
                  FROM qair.qag_msma_all_assignments_t qst1,
                       per_all_people_f papf
                 WHERE     qst1.person_id = papf.person_id
                       AND qst1.person_id = qst.person_id
                       AND qst1.status != 'REJECTED'
                       AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                       AND qst1.ass_attribute16 = qsprt.position_ref_num
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date)
                  applicant_name,
               (SELECT INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                          full_name
                  FROM per_people_x papf
                 WHERE     papf.person_id = qst.person_id
                       AND papf.employee_number IS NOT NULL)
                  employee_name,
               '' snp_xvn_number,
               '' snp_ivn_number,
               (SELECT meaning
                  FROM fnd_lookup_values
                 WHERE     lookup_type = 'QAG_SRF_STATUS'
                       AND enabled_flag = 'Y'
                       AND lookup_code =
                              DECODE (
                                 NVL (
                                    (SELECT DECODE (
                                               qst1.status,
                                               'HIRED', 'EMP_JOINED',
                                               'APPROVED', 'SMA_INITIATED',
                                               'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                                       FROM qair.qag_msma_all_assignments_t qst1
                                      WHERE     qst1.sma_batch_id =
                                                   qst.sma_batch_id
                                            AND qst1.person_id =
                                                   qst.person_id),
                                    qag_srf_gems_general_pkg.hdr_status (
                                       qslt.srf_header_id,
                                       qslt.srf_line_id,
                                       qsprt.position_ref_id)),
                                 'REPLACED', 'SWAPPED',
                                 NVL (
                                    (SELECT DECODE (
                                               qst1.status,
                                               'HIRED', 'EMP_JOINED',
                                               'APPROVED', 'SMA_INITIATED',
                                               'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                                       FROM qair.qag_msma_all_assignments_t qst1
                                      WHERE     qst1.sma_batch_id =
                                                   qst.sma_batch_id
                                            AND qst1.person_id =
                                                   qst.person_id),
                                    qag_srf_gems_general_pkg.hdr_status (
                                       qslt.srf_header_id,
                                       qslt.srf_line_id,
                                       qsprt.position_ref_id))))
                  srf_status_description,
               (SELECT tag
                  FROM fnd_lookup_values
                 WHERE     lookup_type = 'QAG_SRF_STATUS'
                       AND enabled_flag = 'Y'
                       AND meaning =
                              (SELECT meaning
                                 FROM fnd_lookup_values
                                WHERE     lookup_type = 'QAG_SRF_STATUS'
                                      AND enabled_flag = 'Y'
                                      AND lookup_code =
                                             DECODE (
                                                NVL (
                                                   (SELECT DECODE (
                                                              qst1.status,
                                                              'HIRED', 'EMP_JOINED',
                                                              'APPROVED', 'SMA_INITIATED',
                                                              'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                                                      FROM qair.qag_msma_all_assignments_t qst1
                                                     WHERE     qst1.sma_batch_id =
                                                                  qst.sma_batch_id
                                                           AND qst1.person_id =
                                                                  qst.person_id),
                                                   qag_srf_gems_general_pkg.hdr_status (
                                                      qslt.srf_header_id,
                                                      qslt.srf_line_id,
                                                      qsprt.position_ref_id)),
                                                'REPLACED', 'SWAPPED',
                                                NVL (
                                                   (SELECT DECODE (
                                                              qst1.status,
                                                              'HIRED', 'EMP_JOINED',
                                                              'APPROVED', 'SMA_INITIATED',
                                                              'APPROVAL_IN_PROGRESS', 'SMA_INITIATED')
                                                      FROM qair.qag_msma_all_assignments_t qst1
                                                     WHERE     qst1.sma_batch_id =
                                                                  qst.sma_batch_id
                                                           AND qst1.person_id =
                                                                  qst.person_id),
                                                   qag_srf_gems_general_pkg.hdr_status (
                                                      qslt.srf_header_id,
                                                      qslt.srf_line_id,
                                                      qsprt.position_ref_id)))))
                  srf_status_used,
               qsht.srf_type srf_type,
               DECODE (
                  DECODE (qst.status,
                          'APPROVED', 'ONBOARDED',
                          'APPROVAL_IN_PROGRESS', 'SMA'),
                  'REPLACED', 'SWAPPED',
                  DECODE (qst.status,
                          'APPROVED', 'ONBOARDED',
                          'APPROVAL_IN_PROGRESS', 'SMA'))
                  srf_pos_discription,
               (SELECT papf.employee_number
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_no,
               (SELECT INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_name,
               NVL (qslt.replacement, 'N') replace_flag,
               qsht.budget_period,
               qsht.remarks comments,
               qspht.last_update_date actual_sour_date,
               qsht.department_id,
               qsht.division_id,
               qsht.company_id,
               qslt.job_code,
               qslt.position_id,
               qslt.grade_id,
               INITCAP (
                  qag_srf_utilities.get_person_name (
                     qslt.reporting_to_person_id))
                  hiring_staff,
               qslt.reporting_to_person_id hiring_person_id,
               (SELECT employee_number
                  FROM per_all_people_f
                 WHERE     TRUNC (SYSDATE) BETWEEN effective_start_date
                                               AND effective_end_date
                       AND current_employee_flag = 'Y'
                       AND person_id = qslt.reporting_to_person_id)
                  hiring_staff_number
          FROM qag_srf_headers_t qsht,
               qr_srf.qag_srf_posting_headers_t qspht,
               qag_srf_lines_t qslt,
               qag_srf_position_ref_t qsprt,
               per_position_extra_info ppei,
               hr_all_positions_f hap,
               qair.qag_msma_all_assignments_t qst
         WHERE     qsht.srf_header_id = qslt.srf_header_id
               AND qsprt.position_ref_id = qspht.position_ref_id(+)
               AND qsprt.srf_line_id = qslt.srf_line_id
               AND qst.ass_attribute16(+) = qsprt.position_ref_num
               AND hap.position_id = ppei.position_id
               AND ppei.information_type = 'QAG_POS_EXTRA_INFO'
               AND ppei.position_extra_info_id = qsprt.position_extra_info_id
               AND ppei.poei_information7 IS NOT NULL
               AND qst.status NOT IN ('REJECTED')
               AND qsht.status NOT IN ('CEASED') --Ceased status for Budget block period
               AND qsprt.position_ref_num IN
                      (SELECT qst2.ass_attribute16
                         FROM qair.qag_msma_all_assignments_t qst2
                        WHERE qst2.ass_attribute16 IS NOT NULL)
               AND TRUNC (SYSDATE) BETWEEN hap.effective_start_date
                                       AND hap.effective_end_date
               AND qsht.cost_center NOT IN ('236')
               AND (   NVL (qslt.replacement, 'N') = 'Y'
                    OR (   qsht.budget_year
                        || '-'
                        || UPPER (
                              ( (SELECT DISTINCT haou1.NAME
                                   FROM hr_all_organization_units haou1
                                  WHERE haou1.organization_id =
                                           get_org_id (qsht.department_id,
                                                       'DIV'))
                               UNION
                               (SELECT DISTINCT haou1.NAME
                                  FROM hr_all_organization_units haou1
                                 WHERE     1 = 1
                                       AND ROWNUM = 1
                                       AND haou1.organization_id =
                                              get_org_id (qsht.department_id,
                                                          'STN'))))) NOT IN
                          (    SELECT    NVL (REGEXP_SUBSTR (description,
                                                             '[^,]+',
                                                             1,
                                                             LEVEL),
                                              0)
                                      || '-'
                                      || UPPER (meaning)
                                         div_name
                                 FROM (SELECT (description), meaning
                                         FROM fnd_lookup_values
                                        WHERE lookup_type =
                                                 'QAG_SRF_DIVISION_DISPLAY_FY')
                           CONNECT BY LEVEL <=
                                           LENGTH (description)
                                         - LENGTH (
                                              REPLACE (description, ','))
                                         + 1))
        UNION
        SELECT qsht.ROWID row_id,
               qsht.srf_header_id,
               qslt.srf_line_id,
               qsprt.position_ref_id,
               qsht.budget_year,
               (SELECT tag
                  FROM fnd_lookup_values flv
                 WHERE     flv.lookup_type = 'QAG_GEMS-SRF_FY_VAL'
                       AND enabled_flag = 'Y'
                       AND lookup_code = qsht.budget_year
                       AND ROWNUM = 1)
                  fy_year,
               DECODE (qsht.budgeted, 'Y', 'Yes', 'No') budgeted,
               qsht.cost_center,
               qsht.srf_number,
               qsprt.position_ref_num,
               qag_srf_utilities.get_position_name (qslt.position_id)
                  position_title,
               (SELECT pg.NAME
                  FROM per_grades pg
                 WHERE     TRUNC (SYSDATE) BETWEEN TRUNC (pg.date_from)
                                               AND TRUNC (
                                                      NVL (pg.date_to,
                                                           SYSDATE + 1))
                       AND pg.grade_id = qslt.grade_id)
                  grade,
               qag_srf_utilities.get_department (qsht.department_id)
                  department_name,
               ( (SELECT DISTINCT haou1.NAME
                    FROM hr_all_organization_units haou1
                   WHERE haou1.organization_id =
                            get_org_id (qsht.department_id, 'DIV'))
                UNION
                (SELECT DISTINCT haou1.NAME
                   FROM hr_all_organization_units haou1
                  WHERE     1 = 1
                        AND ROWNUM = 1
                        AND haou1.organization_id =
                               get_org_id (qsht.department_id, 'STN')))
                  division_name,
               ( (SELECT DISTINCT haou1.NAME
                    FROM hr_all_organization_units haou1
                   WHERE haou1.organization_id =
                            get_org_id (qsht.department_id, 'BU'))
                UNION
                (SELECT DISTINCT haou1.NAME
                   FROM hr_all_organization_units haou1
                  WHERE     1 = 1
                        AND ROWNUM = 1
                        AND haou1.organization_id =
                               get_org_id (qsht.department_id, 'CTY')))
                  business_unit_name,
               qslt.sourcing_initiation_date,
               qslt.boarding_effective_date onboarding_effective_date,
               NULL,
               NULL,
               NULL,
               INITCAP (qag_srf_utilities.get_person_name (
                           NVL (
                              (SELECT ppx.person_id
                                 FROM per_all_people_f ppx
                                WHERE     ppx.employee_number =
                                             qsht.attribute9
                                      AND ROWNUM < 2),
                              qslt.reporting_to_person_id)))
                  reporting_to,
               NVL (
                  (SELECT ppx.person_id
                     FROM per_all_people_f ppx
                    WHERE     ppx.employee_number = qsht.attribute9
                          AND ROWNUM < 2),
                  qslt.reporting_to_person_id)
                  reporting_person_id,
               (SELECT employee_number
                  FROM per_all_people_f
                 WHERE     TRUNC (SYSDATE) BETWEEN effective_start_date
                                               AND effective_end_date
                       AND current_employee_flag = 'Y'
                       AND person_id =
                              NVL (
                                 (SELECT ppx.person_id
                                    FROM per_all_people_f ppx
                                   WHERE     ppx.employee_number =
                                                qsht.attribute9
                                         AND ROWNUM < 2),
                                 qslt.reporting_to_person_id))
                  reporting_staff_number,
               NULL,
               --      DECODE (NVL (
               --      (SELECT DECODE (qst.person_type, 'EMPLOYEE', DECODE (qst.status, 'APPROVED', 'EMP_PROMOTED', 'NEW', 'SMA_INITIATED' ), 'APPLICANT', DECODE (qst.status, 'APPROVED', 'EMP_JOINED', 'NEW', 'SMA_INITIATED' ) )
               --      FROM qag_hr_sma_transaction_tab qst
               --      WHERE qst.pos_ref_number = qsprt.position_ref_num
               --      AND qst.status          != 'REJECTED'
               --      ), NVL (
               --      (SELECT DECODE (qst.status, 'HIRED', 'EMP_JOINED', 'APPROVED', 'SMA_INITIATED', 'APPROVAL_IN_PROGRESS', 'SMA_INITIATED' )
               --      FROM qair.qag_msma_all_assignments_t qst
               --      WHERE qst.ass_attribute16 = qsprt.position_ref_num
               --      AND qst.status           != 'REJECTED'
               --      ), qsht.status ) ), 'REPLACED', 'SWAPPED', NVL (
               --      (SELECT DECODE (qst.person_type, 'EMPLOYEE', DECODE (qst.status, 'APPROVED', 'EMP_PROMOTED', 'NEW', 'SMA_INITIATED' ), 'APPLICANT', DECODE (qst.status, 'APPROVED', 'EMP_JOINED', 'NEW', 'SMA_INITIATED' ) )
               --      FROM qag_hr_sma_transaction_tab qst
               --      WHERE qst.pos_ref_number = qsprt.position_ref_num
               --      AND qst.status          != 'REJECTED'
               --      ), NVL (
               --      (SELECT DECODE (qst.status, 'HIRED', 'EMP_JOINED', 'APPROVED', 'SMA_INITIATED', 'APPROVAL_IN_PROGRESS', 'SMA_INITIATED' )
               --      FROM qair.qag_msma_all_assignments_t qst
               --      WHERE qst.ass_attribute16 = qsprt.position_ref_num
               --      AND qst.status           != 'REJECTED'
               --      ), qsht.status ) ) ) status,
               'CEASED' status,
               NVL (qsprt.attribute5,
                    DECODE (hold_status, 'Y', 'ON_HOLD', NULL))
                  position_status,
               NULL,
               NULL,
               NULL,
               --qag_srf_utilities.GET_PERSON_NAME(ppei.POEI_INFORMATION3) REP_PERSON_NAME
               1 is_update_sucess,
               qsht.last_update_date,
               NVL (
                  (SELECT DISTINCT papf.applicant_number
                     FROM qag_hr_sma_transaction_tab qst,
                          per_all_people_f papf
                    WHERE     qst.person_id = papf.person_id
                          AND qst.person_type = 'APPLICANT'
                          AND qst.status = 'NEW'
                          AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                          AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                                  AND papf.effective_end_date
                          AND qst.pos_ref_number = qsprt.position_ref_num),
                  (SELECT DISTINCT papf.applicant_number
                     FROM qair.qag_msma_all_assignments_t qst,
                          per_all_people_f papf
                    WHERE     qst.person_id = papf.person_id
                          AND qst.status != 'REJECTED'
                          AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                          AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                                  AND papf.effective_end_date
                          AND qst.ass_attribute16 = qsprt.position_ref_num))
                  applicant_number,
               NVL (
                  (SELECT INITCAP (
                                papf.title
                             || ' '
                             || papf.first_name
                             || ' '
                             || papf.middle_names
                             || ' '
                             || papf.last_name)
                             full_name
                     FROM qag_hr_sma_transaction_tab qst,
                          per_all_people_f papf
                    WHERE     qst.person_id = papf.person_id
                          AND qst.person_type = 'APPLICANT'
                          AND qst.status != 'REJECTED'
                          AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                          AND qst.pos_ref_number = qsprt.position_ref_num
                          AND ROWNUM = 1
                          AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                                  AND papf.effective_end_date),
                  (SELECT INITCAP (
                                papf.title
                             || ' '
                             || papf.first_name
                             || ' '
                             || papf.middle_names
                             || ' '
                             || papf.last_name)
                             full_name
                     FROM qair.qag_msma_all_assignments_t qst,
                          per_all_people_f papf
                    WHERE     qst.person_id = papf.person_id
                          AND qst.status != 'REJECTED'
                          AND NVL (papf.current_applicant_flag, 'N') = 'Y'
                          AND qst.ass_attribute16 = qsprt.position_ref_num
                          AND ROWNUM = 1
                          AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                                  AND papf.effective_end_date))
                  applicant_name,
               NVL (
                  (SELECT INITCAP (
                                papf.title
                             || ' '
                             || papf.first_name
                             || ' '
                             || papf.middle_names
                             || ' '
                             || papf.last_name)
                             full_name
                     FROM qag_hr_sma_transaction_tab qst, per_people_x papf
                    WHERE     qst.person_id = papf.person_id
                          AND qst.pos_ref_number = qsprt.position_ref_num
                          AND ROWNUM = 1
                          AND qst.person_type = 'EMPLOYEE'
                          AND qst.status != 'REJECTED'),
                  (SELECT INITCAP (
                                papf.title
                             || ' '
                             || papf.first_name
                             || ' '
                             || papf.middle_names
                             || ' '
                             || papf.last_name)
                             full_name
                     FROM qair.qag_msma_all_assignments_t qst,
                          per_people_x papf
                    WHERE     qst.person_id = papf.person_id
                          AND qst.ass_attribute16 = qsprt.position_ref_num
                          AND papf.employee_number IS NOT NULL
                          AND ROWNUM = 1
                          AND qst.status != 'REJECTED'))
                  employee_name,
               '' snp_xvn_number,
               '' snp_ivn_number,
               --      (SELECT meaning
               --      FROM fnd_lookup_values
               --      WHERE lookup_type = 'QAG_SRF_STATUS'
               --      AND enabled_flag  = 'Y'
               --      AND lookup_code   = DECODE (NVL (
               --        (SELECT DECODE (qst.person_type, 'EMPLOYEE', DECODE (qst.status, 'APPROVED', 'EMP_PROMOTED', 'NEW', 'SMA_INITIATED' ), 'APPLICANT', DECODE (qst.status, 'APPROVED', 'EMP_JOINED', 'NEW', 'SMA_INITIATED' ) )
               --        FROM qag_hr_sma_transaction_tab qst
               --        WHERE qst.pos_ref_number = qsprt.position_ref_num
               --        AND qst.status          != 'REJECTED'
               --        ), NVL (
               --        (SELECT DECODE (qst.status, 'HIRED', 'EMP_JOINED', 'APPROVED', 'SMA_INITIATED', 'APPROVAL_IN_PROGRESS', 'SMA_INITIATED' )
               --        FROM qair.qag_msma_all_assignments_t qst
               --        WHERE qst.ass_attribute16 = qsprt.position_ref_num
               --        AND qst.status           != 'REJECTED'
               --        ), qsht.status ) ), 'REPLACED', 'SWAPPED', NVL (
               --        (SELECT DECODE (qst.person_type, 'EMPLOYEE', DECODE (qst.status, 'APPROVED', 'EMP_PROMOTED', 'NEW', 'SMA_INITIATED' ), 'APPLICANT', DECODE (qst.status, 'APPROVED', 'EMP_JOINED', 'NEW', 'SMA_INITIATED' ) )
               --        FROM qag_hr_sma_transaction_tab qst
               --        WHERE qst.pos_ref_number = qsprt.position_ref_num
               --        AND qst.status          != 'REJECTED'
               --        ), NVL (
               --        (SELECT DECODE (qst.status, 'HIRED', 'EMP_JOINED', 'APPROVED', 'SMA_INITIATED', 'APPROVAL_IN_PROGRESS', 'SMA_INITIATED' )
               --        FROM qair.qag_msma_all_assignments_t qst
               --        WHERE qst.ass_attribute16 = qsprt.position_ref_num
               --        AND qst.status           != 'REJECTED'
               --        ), qsht.status ) ) )
               --      ) srf_status_description,
               'Ceased' srf_status_description,
               --      (SELECT tag
               --      FROM fnd_lookup_values
               --      WHERE lookup_type = 'QAG_SRF_STATUS'
               --      AND enabled_flag  = 'Y'
               --      AND meaning       =
               --        (SELECT meaning
               --        FROM fnd_lookup_values
               --        WHERE lookup_type = 'QAG_SRF_STATUS'
               --        AND enabled_flag  = 'Y'
               --        AND lookup_code   = DECODE (NVL (
               --          (SELECT DECODE (qst.person_type, 'EMPLOYEE', DECODE (qst.status, 'APPROVED', 'EMP_PROMOTED', 'NEW', 'SMA_INITIATED' ), 'APPLICANT', DECODE (qst.status, 'APPROVED', 'EMP_JOINED', 'NEW', 'SMA_INITIATED' ) )
               --          FROM qag_hr_sma_transaction_tab qst
               --          WHERE qst.pos_ref_number = qsprt.position_ref_num
               --          AND qst.status          != 'REJECTED'
               --          ), NVL (
               --          (SELECT DECODE (qst.status, 'HIRED', 'EMP_JOINED', 'APPROVED', 'SMA_INITIATED', 'APPROVAL_IN_PROGRESS', 'SMA_INITIATED' )
               --          FROM qair.qag_msma_all_assignments_t qst
               --          WHERE qst.ass_attribute16 = qsprt.position_ref_num
               --          AND qst.status           != 'REJECTED'
               --          ), qsht.status ) ), 'REPLACED', 'SWAPPED', NVL (
               --          (SELECT DECODE (qst.person_type, 'EMPLOYEE', DECODE (qst.status, 'APPROVED', 'EMP_PROMOTED', 'NEW', 'SMA_INITIATED' ), 'APPLICANT', DECODE (qst.status, 'APPROVED', 'EMP_JOINED', 'NEW', 'SMA_INITIATED' ) )
               --          FROM qag_hr_sma_transaction_tab qst
               --          WHERE qst.pos_ref_number = qsprt.position_ref_num
               --          AND qst.status          != 'REJECTED'
               --          ), NVL (
               --          (SELECT DECODE (qst.status, 'HIRED', 'EMP_JOINED', 'APPROVED', 'SMA_INITIATED', 'APPROVAL_IN_PROGRESS', 'SMA_INITIATED' )
               --          FROM qair.qag_msma_all_assignments_t qst
               --          WHERE qst.ass_attribute16 = qsprt.position_ref_num
               --          AND qst.status           != 'REJECTED'
               --          ), qsht.status ) ) )
               --        )
               --      ) srf_status_used,
               'Unused' srf_status_used,
               qsht.srf_type srf_type,
               '' srf_pos_discription,
               (SELECT papf.employee_number
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_no,
               (SELECT INITCAP (
                             papf.title
                          || ' '
                          || papf.first_name
                          || ' '
                          || papf.middle_names
                          || ' '
                          || papf.last_name)
                  FROM per_all_people_f papf
                 WHERE     papf.person_id = qslt.replaced_person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND ROWNUM < 2)
                  replace_staff_name,
               NVL (qslt.replacement, 'N') replace_flag,
               qsht.budget_period,
               qsht.remarks comments,
               qspht.last_update_date actual_sour_date,
               qsht.department_id,
               qsht.division_id,
               qsht.company_id,
               qslt.job_code,
               qslt.position_id,
               qslt.grade_id,
               INITCAP (
                  qag_srf_utilities.get_person_name (
                     qslt.reporting_to_person_id))
                  hiring_staff,
               qslt.reporting_to_person_id hiring_person_id,
               (SELECT employee_number
                  FROM per_all_people_f
                 WHERE     TRUNC (SYSDATE) BETWEEN effective_start_date
                                               AND effective_end_date
                       AND current_employee_flag = 'Y'
                       AND person_id = qslt.reporting_to_person_id)
                  hiring_staff_number
          FROM qag_srf_headers_t qsht,
               qr_srf.qag_srf_posting_headers_t qspht,
               qag_srf_lines_t qslt,
               qag_srf_position_ref_t qsprt
         WHERE     qsht.srf_header_id = qslt.srf_header_id
               AND qsprt.position_ref_id = qspht.position_ref_id(+)
               AND qsprt.srf_line_id(+) = qslt.srf_line_id
               AND qsht.status = 'CEASED'
               AND (   NVL (qslt.replacement, 'N') = 'Y'
                    OR (   qsht.budget_year
                        || '-'
                        || UPPER (
                              ( (SELECT DISTINCT haou1.NAME
                                   FROM hr_all_organization_units haou1
                                  WHERE haou1.organization_id =
                                           get_org_id (qsht.department_id,
                                                       'DIV'))
                               UNION
                               (SELECT DISTINCT haou1.NAME
                                  FROM hr_all_organization_units haou1
                                 WHERE     1 = 1
                                       AND ROWNUM = 1
                                       AND haou1.organization_id =
                                              get_org_id (qsht.department_id,
                                                          'STN'))))) NOT IN
                          (    SELECT    NVL (REGEXP_SUBSTR (description,
                                                             '[^,]+',
                                                             1,
                                                             LEVEL),
                                              0)
                                      || '-'
                                      || UPPER (meaning)
                                         div_name
                                 FROM (SELECT (description), meaning
                                         FROM fnd_lookup_values
                                        WHERE lookup_type =
                                                 'QAG_SRF_DIVISION_DISPLAY_FY')
                           CONNECT BY LEVEL <=
                                           LENGTH (description)
                                         - LENGTH (
                                              REPLACE (description, ','))
                                         + 1))) qrslt
 WHERE qrslt.status != 'DELETED';