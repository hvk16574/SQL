SELECT /*:StartDate start_date,
             :EndDate end_date,*/
        trunc(icxsess.first_connect),
        fu.user_name,
       fu.description,
       round(sum(icxsess.last_connect - icxsess.first_connect) * 24,1) connect_time,
       round((sum(icxsess.last_connect - icxsess.first_connect) * 24) * 100 /
              decode(totals.total_hours, 0, .0000001, totals.total_hours ),1) Connect_time_pct_of_tot,
       count(*) number_of_sessions,
       round((count(*) * 100 / totals.total_connects),1) num_sessions_pct_of_tot,
       sum(icxsess.counter) num_pages,
       round((sum(icxsess.counter) * 100 / totals.total_counter),1) num_pages_pct_of_tot
  FROM icx.icx_sessions icxsess,
       applsys.fnd_user fu,
      ( SELECT sum(icxsessb.last_connect - icxsessb.first_connect) * 24 total_hours,
               count(*) total_connects,
          decode(sum(icxsessb.counter), 0, .0000001,sum(icxsessb.counter) ) total_counter
         FROM icx.icx_sessions icxsessb
 --WHERE icxsessb.first_connect > (Trunc(Sysdate) )
--     and icxsessb.first_connect < (Trunc((sysdate)))
        ) totals
 WHERE icxsess.user_id = fu.user_id
 and icxsess.RESPONSIBILITY_ID = 53398
 and ICXSESS.RESPONSIBILITY_APPLICATION_ID = 20003
-- and FU.USER_NAME = '21873'
--   and icxsess.first_connect > (Trunc(Sysdate))
--   and icxsess.first_connect < (Trunc((sysdate)))
 GROUP by fu.user_name,
          fu.description,
          totals.total_hours,
          totals.total_connects,
          totals.total_counter, trunc(icxsess.first_connect)
 ORDER by sum(icxsess.counter) desc
