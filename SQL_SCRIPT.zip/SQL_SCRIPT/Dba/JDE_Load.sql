DECLARE
   CURSOR c1 IS
      SELECT   FLIGHT_NO,date2jde (TO_DATE (FLIGHT_DATE, 'dd/mm/yyyy')) FLIGHT_DATE,
               ORIGIN,DESTINATION,lpad(LOCDPTTIME,4,0) LOCDPTTIME,LOCARRTIME,F,Y,C
        FROM   f550060file; --       WHERE   FLIGHT_NO = '00001';

   CURSOR c2 (v_flight_date NUMBER, v_flight_no VARCHAR2) IS
          SELECT   QADBLDATE,LPAD (TRIM (SUBSTR (QADBLFLT, 3)), 5, '0') QADBLFLT,
                   QADBLALPH,QAPL48HRFC,QAPL48HRJC,QAPL48HRYC,QAPL24HRFC,QAPL24HRJC,
                   QAPL24HRYC,QAPL12HRFC,QAPL12HRJC,QAPL12HRYC,QA48HRFLG,QA24HRFLG,
                   QA12HRFLG
            FROM   f550060_v
           WHERE   QADBLDATE = v_flight_date AND LPAD (TRIM (SUBSTR (QADBLFLT, 3)), 5, '0') = v_flight_no FOR UPDATE   ;

   c1rec   c1%ROWTYPE;
   c2rec   c2%ROWTYPE;
   v_hours     NUMBER;
BEGIN
   FOR c1_rec IN c1
   LOOP
--      DBMS_OUTPUT.put_line(   c1_rec.FLIGHT_NO|| '-'|| c1_rec.FLIGHT_DATE|| '-'|| c1_rec.LOCDPTTIME
--                            || '-'|| c1_rec.F|| '-'|| c1_rec.C|| '-'|| c1_rec.Y);

      FOR c2_rec IN c2 (c1_rec.FLIGHT_DATE, c1_rec.FLIGHT_NO)
      LOOP
         SELECT FLOOR( (TO_DATE (jde2date (c1_rec.FLIGHT_DATE)|| ' ' || SUBSTR (LPAD (c1_rec.LOCDPTTIME, 4, 0), 1, 2) || ':' || 
                SUBSTR (LPAD (c1_rec.LOCDPTTIME, 4, 0), 3, 2),'dd-MON-YY hh24:mi') - SYSDATE) * 24) INTO v_hours FROM DUAL;
         DBMS_OUTPUT.put_line(c1_rec.FLIGHT_NO|| '-'|| c1_rec.FLIGHT_DATE|| '-'|| c1_rec.LOCDPTTIME || '-'|| c1_rec.F|| '-'|| 
                                 c1_rec.C|| '-'|| c1_rec.Y || '-=*=-'|| c2_rec.QADBLDATE|| '-'|| c2_rec.QADBLFLT|| '-'|| 
                                 NVL (TRIM (c2_rec.QA48HRFLG), 0)|| '-' || NVL (TRIM (c2_rec.QA24HRFLG), 0)|| '-'|| 
                                 NVL (TRIM (c2_rec.QA12HRFLG), 0) || '-' ||v_hours ||' hours');
         DBMS_OUTPUT.put_line( NVL (TRIM (c2_rec.QAPL48HRFC), 0)|| '-'|| NVL (TRIM (c2_rec.QAPL48HRJC), 0)|| '-'
                              || NVL (TRIM (c2_rec.QAPL48HRYC), 0)|| '-'|| NVL (TRIM (c2_rec.QAPL24HRFC), 0)|| '-'
                              || NVL (TRIM (c2_rec.QAPL24HRJC), 0)|| '-'|| NVL (TRIM (c2_rec.QAPL24HRYC), 0)|| '-'
                              || NVL (TRIM (c2_rec.QAPL12HRFC), 0)|| '-'|| NVL (TRIM (c2_rec.QAPL12HRJC), 0)|| '-'
                              || NVL (TRIM (c2_rec.QAPL12HRYC), 0)|| '-'|| NVL (TRIM (c2_rec.QA48HRFLG),  0)|| '-'
                              || NVL (TRIM (c2_rec.QA24HRFLG),  0)|| '-'|| NVL (TRIM (c2_rec.QA12HRFLG),  0));
         if v_hours > 24 then
--            DBMS_OUTPUT.put_line('In48');
            UPDATE   f550060_v
               SET   QA48HRFLG = 1, QAPL48HRFC = c1_rec.F, QAPL48HRJC = c1_rec.C, QAPL48HRYC = c1_rec.Y
             WHERE   CURRENT OF c2;
         elsif v_hours between 12 and 24 then
--            DBMS_OUTPUT.put_line('In24');
            UPDATE   f550060_v
               SET   QA24HRFLG = 1, QAPL24HRFC = c1_rec.F, QAPL24HRJC = c1_rec.C, QAPL24HRYC = c1_rec.Y
             WHERE   CURRENT OF c2;
         elsif v_hours between 6 and 12 then
--            DBMS_OUTPUT.put_line('In12');          
            UPDATE   f550060_v
               SET   QA12HRFLG = 1, QAPL12HRFC = c1_rec.F, QAPL12HRJC = c1_rec.C, QAPL12HRYC = c1_rec.Y
             WHERE   CURRENT OF c2;
         else 
             null;
--             DBMS_OUTPUT.put_line('In Else');
         end if;
         
      END LOOP;
   END LOOP;
END;




/*
         IF c2_rec.QA48HRFLG != '1'
         THEN
            UPDATE   f550060_v
               SET   QA48HRFLG = 1, QAPL48HRFC = c1_rec.F
             WHERE   CURRENT OF c2;
         ELSIF c2_rec.QA24HRFLG != '1'
         THEN
            UPDATE   f550060_v
               SET   QA24HRFLG = 1, QAPL24HRFC = c1_rec.F
             WHERE   CURRENT OF c2;
         ELSIF c2_rec.QA12HRFLG != '1'
         THEN
            UPDATE   f550060_v
               SET   QA12HRFLG = 1, QAPL12HRFC = c1_rec.F
             WHERE   CURRENT OF c2;
         END IF;
*/