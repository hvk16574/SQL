  SELECT fu.user_name Employee_No, fu.description Employee_Name, frt.responsibility_name
    FROM APPS.fnd_user_resp_groups fur, applsys.fnd_user fu, fnd_responsibility_tl frt
   WHERE     fur.user_id = fu.user_id
         AND fur.responsibility_application_id = 201
         AND fur.responsibility_id = frt.responsibility_id
         AND (fur.end_date IS NULL OR fur.end_date > SYSDATE)
         AND (fu.end_date IS NULL OR fu.end_date > SYSDATE)
         AND UPPER (frt.responsibility_name) LIKE '%REQUISITION%CREATOR%'
         --       AND frt.responsibility_id = 50291
         AND fu.user_name IN (SELECT papf.employee_number staff_number
                                FROM per_All_people_f papf,
                                     per_All_assignments_f paaf,
                                     hr_all_organization_units haou,
                                     pay_payrolls_f ppf
                               WHERE     papf.person_id = paaf.person_id
                                     AND paaf.payroll_id = ppf.payroll_id
                                     AND paaf.organization_id = haou.organization_id
                                     AND NVL (current_employee_flag, 'N') = 'Y'
                                     AND primary_flag = 'Y'
                                     AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date AND papf.effective_End_Date
                                     AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date AND paaf.effective_End_Date
                                     --AND ppf.payroll_name = 'QR_PAYROLL'
                                     AND assignment_status_type_id = 1
                                     AND haou.name IN (SELECT department_name
                                                         FROM QAG_SRF_ORG_MATRIX_V
                                                        WHERE DIVISION_STATION_NAME LIKE 'Human Resources (Division)'))
ORDER BY 1