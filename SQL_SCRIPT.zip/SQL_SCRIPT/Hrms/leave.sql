SELECT   item_type, item_key,
         DECODE (hatv.NAME,
                 'P_ABSENCE_ATTENDANCE_TYPE_ID', patt.NAME,
                 hatv.NAME
                ) NAME,
         date_value
    FROM hr_api_transaction_values hatv,
         hr_api_transaction_steps hats,
         per_absence_attendance_types patt
   WHERE hatv.transaction_step_id IN (
            SELECT transaction_step_id
              FROM hr_api_transaction_steps
             WHERE item_key IN (
                      SELECT item_key
                        FROM hr_api_transactions
                       WHERE creator_person_id IN (
                                               SELECT person_id
                                                 FROM per_all_people_f
                                                WHERE employee_number =
                                                                      :emp_num)
                         AND process_name = 'HR_LOA_JSP_PRC'))
     AND hatv.NAME IN
               ('P_DATE_START', 'P_DATE_END', 'P_ABSENCE_ATTENDANCE_TYPE_ID')
     AND hats.transaction_step_id = hatv.transaction_step_id
     AND patt.absence_attendance_type_id(+) = hatv.number_value
ORDER BY hatv.ROWID