select * from pay_payroll_actions where TO_CHAR (effective_date, 'MON-RRRR') = :p_payroll_date
and action_type='R'


select * from per_all_assignments_f where payroll_id=142
and sysdate between effective_start_date and effective_end_date

select * from pay_all_payrolls_f where payroll_name like 'QS%'

84


QAG_EMP_ELE_WISE_PAY_PKG.QAG_PAYROLL_ELEWISE_P1


SELECT   pf.payroll_name, peo.employee_number EMP_NUM,
         peo.first_name || '  ' || peo.last_name NAME,
         hr_general.decode_fnd_comm_lookup ('NATIONALITY',
                                            peo.nationality
                                           ) nationality,
         SUBSTR
            (hr_general.decode_position_latest_name (paaf.position_id),
             1,
             NVL
                (  INSTR
                      (hr_general.decode_position_latest_name
                                                             (paaf.position_id),
                       '|'
                      )
                 - 1,
                 LENGTH
                     (hr_general.decode_position_latest_name (paaf.position_id)
                     )
                )
            ) position_name,
         hr_general.decode_organization
                                      (paaf.organization_id)
                                                            organization_name,
         pet.reporting_name element_name,
         DECODE (upper(pec.classification_name),
                 UPPER ('Earnings'), NVL (result_value, 0),
                 '-' || NVL (result_value, 0)
                ) amount,
         pg.NAME grade
    FROM pay_payroll_actions ppa,
         pay_assignment_actions paa,
         per_all_assignments_f paaf,
         per_all_people_f peo,
         pay_run_results prr,
         pay_run_result_values prrv,
         pay_element_types_f pet,
         pay_input_values_f piv,
         per_grades pg,
         pay_all_payrolls_f pf,
         pay_element_classifications pec
   WHERE ppa.action_type = 'R'
     AND UPPER (pec.classification_name) IN
                         (UPPER ('Earnings'), UPPER ('Voluntary Deductions'))
     --AND paa.run_type_id IS NOT NULL
     AND paa.action_status = 'C'
     AND paa.payroll_action_id = ppa.payroll_action_id
     AND paa.assignment_id = paaf.assignment_id
     AND prr.element_type_id = pet.element_type_id
     AND pet.classification_id = pec.classification_id
     AND peo.person_id = paaf.person_id
     AND prr.assignment_action_id = paa.assignment_action_id
     --AND peo.employee_number = '10594'
     AND peo.person_id=NVL(:p_person_id,peo.person_id)
     AND TO_CHAR (ppa.effective_date, 'MON-RRRR') = :p_payroll_date
     AND prrv.run_result_id = prr.run_result_id
     AND prrv.input_value_id = piv.input_value_id
     AND piv.NAME LIKE 'Pay Value'
     AND piv.element_type_id = pet.element_type_id
     AND paaf.payroll_id = :p_payroll_id
     AND paaf.payroll_id = pf.payroll_id
     AND paaf.payroll_id = ppa.payroll_id
     AND pg.grade_id = paaf.grade_id
     AND ppa.effective_date BETWEEN peo.effective_start_date
                                AND peo.effective_end_date
     AND ppa.effective_date BETWEEN piv.effective_start_date
                                AND piv.effective_end_date
     AND ppa.effective_date BETWEEN pet.effective_start_date
                                AND pet.effective_end_date
     AND ppa.effective_date BETWEEN paaf.effective_start_date
                                AND paaf.effective_end_date
     AND ppa.effective_date BETWEEN pf.effective_start_date
                                AND pf.effective_end_date
ORDER BY peo.employee_number, pet.element_name  ;