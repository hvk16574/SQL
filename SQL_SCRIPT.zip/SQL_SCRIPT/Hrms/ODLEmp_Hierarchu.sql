DECLARE
   v_fname   VARCHAR2 (100);
   v_empno   varchar2(10);
   v_person_id varchar2(20);
   CURSOR c1
   IS
      SELECT     paf.person_id
            FROM per_all_assignments_f paf
      START WITH paf.person_id = (SELECT DISTINCT person_id
                                             FROM per_all_people_f
                                            WHERE employee_number = :emp_num)
             AND paf.primary_flag = 'Y'
             AND paf.assignment_type IN ('E', 'C')
             AND TRUNC (SYSDATE) BETWEEN paf.effective_start_date AND paf.effective_end_date
      CONNECT BY PRIOR paf.supervisor_id = paf.person_id
             AND paf.primary_flag = 'Y'
             AND paf.assignment_type IN ('E', 'C')
             AND TRUNC (SYSDATE) BETWEEN paf.effective_start_date AND paf.effective_end_date;
BEGIN
   FOR c1_rec IN c1
   LOOP
      SELECT employee_number,full_name, person_id
        INTO v_empno,v_fname, v_person_id
        FROM per_all_people_f
       WHERE person_id = c1_rec.person_id
         AND TRUNC (SYSDATE) BETWEEN effective_start_date AND effective_end_date
         AND current_employee_flag = 'Y';
      DBMS_OUTPUT.put_line (rpad(v_empno,5,'0')||' - '||v_fname||' - '||v_person_id);
   END LOOP;
END;