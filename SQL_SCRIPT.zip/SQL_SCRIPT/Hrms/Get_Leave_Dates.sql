SELECT   papf.employee_number
       ,    INITCAP( papf.title )
         || TRIM( papf.first_name )
         || ' '
         || TRIM( papf.last_name ) full_name
         ,to_char(qr_final_settlement_cpnt.qr_service_date(papf.person_id)
              ,'DD-Mon-YYYY') DOJ
         ,pg.name grade
         ,SUBSTR(hr_general.decode_position_current_name(paaf.position_id)
                    ,1
                    ,(INSTR(hr_general.decode_position_current_name(paaf.position_id)
                           ,'|'
                           ,1) - 1)) designation
       , hrorg.NAME deptname, paat.NAME leave_type
       , TO_CHAR( ( paa.date_start ), 'DD-MON-YYYY' ) leave_start_date
       , TO_CHAR( ( paa.date_end ), 'DD-MON-YYYY' ) leave_end_date
       , paa.absence_days absence_days
    FROM per_absence_attendances paa
       , per_all_people_f papf
       , per_all_assignments_f paaf
       , hr_all_organization_units hrorg
       , per_absence_attendance_types paat
       , per_grades pg
   WHERE paa.person_id = papf.person_id
     AND papf.person_id = paaf.person_id
     AND paaf.person_id = paa.person_id
     AND papf.current_employee_flag = 'Y'
     AND paaf.primary_flag = 'Y'
     AND pg.grade_id=paaf.grade_id
     AND paaf.organization_id = hrorg.organization_id
     AND paa.absence_attendance_type_id = paat.absence_attendance_type_id
     --AND paaf.organization_id = NVL( :p_x_dept, hrorg.organization_id )
     --AND hrorg.name='HR - Employee Sourcing & Planning'
     --and pg.name in ( 'QR.10','QR.11','QR.12','QR.13','QR.14','QR.15')
     AND TRUNC( SYSDATE ) BETWEEN papf.effective_start_date
                              AND papf.effective_end_date
     AND TRUNC( SYSDATE ) BETWEEN paaf.effective_start_date
                              AND paaf.effective_end_date
     and papf.employee_number = '24756'
     --AND paa.PERSON_ID = 272114
    -- AND paa.date_end BETWEEN '15-DEC-2009' AND '05-JAN-2010'
    --AND paa.date_start >='23-MAR-2010' AND paa.date_end <='30-APR-2010'
    AND paa.date_end >='01-JAN-2010' AND paa.date_start <='23-MAY-2010'
ORDER BY date_start asc
