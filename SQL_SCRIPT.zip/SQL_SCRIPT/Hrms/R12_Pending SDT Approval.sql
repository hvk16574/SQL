SELECT   PROCESS_NAME,transaction_id, item_key
  FROM   hr_api_transactions
WHERE       creator_person_id = (SELECT   DISTINCT person_id FROM   per_all_people_f WHERE   employee_number = :emp_num)
  AND PROCESS_NAME LIKE '%DT%'
--  AND status = 'E';