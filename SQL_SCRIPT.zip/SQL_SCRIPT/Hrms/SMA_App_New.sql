SELECT prom_sma_batch_id,
  a.department_id,
         A.STATUS,
         b.full_name,
         b.employee_number,
         a.transaction_id,
         item_key,item_type,
         process_name,
         a.creation_Date,
         b.person_id,
         a.created_by,
         a.attribute31
    FROM QAG_HR_PROM_SMA_TRANSACT_T A, PER_ALL_PEOPLE_F B
   WHERE     A.SELECTED_PERSON_ID = B.PERSON_ID
         AND B.EMPLOYEE_NUMBER IN ('07462')
         AND TRUNC (SYSDATE) BETWEEN effective_start_date
                                 AND effective_end_date
ORDER BY creation_date DESC