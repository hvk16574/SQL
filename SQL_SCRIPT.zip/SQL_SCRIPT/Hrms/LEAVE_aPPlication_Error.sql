SELECT   DISTINCT employee_number --, full_name,hr_general.DECODE_ORGANIZATION(organization_id)
  FROM   per_all_people_f papf, per_all_assignments_f paaf
 WHERE  papf.person_id IN (SELECT   DISTINCT selected_person_id
                  FROM   hr_api_transactions hat
                 WHERE   TRUNC (hat.creation_date) BETWEEN TO_DATE ('01-JAN-2000') AND  TO_DATE ('30-NOV-2010')
                         AND status = 'E'
                         AND item_type = 'HRSSA') 
         AND employee_number is not null
         AND papf.person_id = paaf.person_id                         
--         AND employee_number = lpad(trunc(:emp_num),5,'0');

SELECT item_key,(select distinct employee_number from per_all_people_f where person_id = selected_person_id AND employee_number is not null) em
FROM   hr_api_transactions hat 
      WHERE   TRUNC (hat.creation_date) BETWEEN TO_DATE ('01-JAN-2000')
                                            AND  TO_DATE ('30-NOV-2010')
              AND status = 'E'
              AND item_type = 'HRSSA';

SELECT COUNT(1) FROM   hr_api_transaction_steps hats
      WHERE   hats.transaction_id IN
                    (SELECT   transaction_id
                       FROM   hr_api_transactions hat
                      WHERE   TRUNC (hat.creation_date) BETWEEN TO_DATE('01-JAN-2000')
                                                            AND  TO_DATE('31-OCT-2010')
                              AND status = 'E'
                              AND item_type = 'HRSSA');

SELECT COUNT(1)FROM   hr_api_transaction_values hatv
      WHERE   hatv.transaction_step_id IN
                    (SELECT   transaction_step_id
                       FROM   hr_api_transaction_steps hats
                      WHERE   hats.transaction_id IN
                                    (SELECT   transaction_id
                                       FROM   hr_api_transactions hat
                                      WHERE   TRUNC (hat.creation_date) BETWEEN TO_DATE('01-JAN-2000')
                                                                            AND  TO_DATE('31-OCT-2010')
                                              AND status = 'E'
                                              AND item_type = 'HRSSA'));