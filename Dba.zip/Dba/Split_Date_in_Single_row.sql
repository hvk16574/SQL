WITH   cntr        AS
(
    SELECT    LEVEL - 1    AS n
    FROM    dual
    CONNECT BY    LEVEL    <= (
                    SELECT  MAX (end_date - start_date)
                    FROM    table_x
                   ) + 1
)
SELECT      x.id
,      x.start_date + c.n    AS a_date
FROM      table_x  x
JOIN      cntr       c  ON  c.n  <= x.end_date - x.start_date
ORDER BY  x.id
,           a_date
;