SELECT    'execute dbms_scheduler.disable('''
       || owner
       || '.'
       || job_name
       || ''');'
  FROM dba_scheduler_jobs
 WHERE owner NOT IN ('SYS', 'ORACLE_OCM', 'DBREPORT', 'EXFSYS');



SELECT    'execute dbms_scheduler.stop_job('''
       || owner
       || '.'
       || job_name
       || ''',TRUE);'
  FROM dba_scheduler_jobs
 WHERE owner NOT IN ('SYS', 'ORACLE_OCM', 'DBREPORT', 'EXFSYS');