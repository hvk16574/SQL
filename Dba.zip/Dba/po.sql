select * from fnd_conc_req_summary_v where request_id = &id;
 

SET VERIFY OFF
 
ACCEPT req_id PROMPT 'Enter the request id: '
ACCEPT phase PROMPT  'Enter the phase code - R for running or C for complete: '
 
SELECT a.request_id, c.spid
FROM   apps.fnd_concurrent_requests a,
       apps.fnd_concurrent_processes b,
       v$process c
WHERE  c.spid IN ( SELECT c.spid
                   FROM   apps.fnd_concurrent_requests a,
                          apps.fnd_concurrent_processes b,
                          v$process c
                   WHERE  a.controlling_manager = b.concurrent_process_id
                   AND    c.pid = b.oracle_process_id
                   AND    a.request_id = &req_id
                 )
AND   a.controlling_manager = b.concurrent_process_id
AND   c.pid = b.oracle_process_id
AND   a.phase_code = UPPER('&phase');
 
 
 

SELECT a.sid,a.serial#,a.username, a.osuser, b.spid, module, a.program, a.machine, a.status 
FROM   v$session a, v$process b 
WHERE  a.paddr = b.addr 
AND   a.username IS NOT null
and b.SPID =&spid;
 

alter system kill session '&sid, &serial';
 
update fnd_concurrent_requests
set status_code = 'X', phase_code='C'
where request_id = 4120866; 
 
commit;
