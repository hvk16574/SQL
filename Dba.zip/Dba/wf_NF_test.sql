set serverout on
 
DECLARE
   v_res   NUMBER;
BEGIN
   v_res   :=
      wf_notification.send (ROLE => '23339',
                            msg_type => 'CS_MSGS',
                            msg_name => 'FYI_MESSAGE',
                            priority => 1
      );
 
   wf_notification.setattrtext (v_res, 'OBJECT_TYPE', 'Test Message from ERP'
   );
 
   wf_notification.setattrtext (v_res,
                                'MESSAGE_TEXT',
                                   'Message from ERP'
                                || CHR (10)
                                || 'Regards,'
                                || CHR (10)
                                || 'Hamid Vahid Khan'
   );
 
   COMMIT;
 
   DBMS_OUTPUT.put_line (v_res);
END;
/