select max(log_sequence) from fnd_log_messages;
172960347

select * from fnd_log_messages where log_sequence between 172960347 and 
172960442  and user_id = (select user_id from fnd_user where user_name like :emp_no)  order by log_sequence