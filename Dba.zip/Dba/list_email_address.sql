SELECT papf.employee_number "Employee Number", papf.email_address "Email Address ", pac.segment1 "Email Address Alternate"
             FROM per_all_people_f papf,per_analysis_criteria pac 
            WHERE TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                      AND papf.effective_end_date
                                      and pac.analysis_criteria_id = (
                     SELECT ppa.analysis_criteria_id
                       FROM per_person_analyses ppa
                     WHERE ppa.person_id = papf.person_id and rownum <2 )
                      AND pac.segment1 LIKE '%@%'
                      
                                      
                                      
                                      
 (SELECT pac.segment1
             FROM per_analysis_criteria pac
            WHERE pac.analysis_criteria_id = (
                     SELECT ppa.analysis_criteria_id
                       FROM per_person_analyses ppa
                      WHERE ppa.person_id =
                               (SELECT papf.person_id
                                  FROM per_all_people_f papf
                                 WHERE TRUNC (SYSDATE)
                                          BETWEEN papf.effective_start_date
                                              AND papf.effective_end_date)and rownum < 2)
              AND pac.segment1 LIKE '%@%')
 