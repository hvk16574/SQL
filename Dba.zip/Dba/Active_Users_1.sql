SELECT user_id, user_name, full_name
    FROM fnd_user fu, per_all_people_f papf
   WHERE papf.person_id = fu.employee_id
         AND SYSDATE BETWEEN fu.start_date AND NVL (fu.end_date, SYSDATE)
         AND SYSDATE BETWEEN papf.effective_start_date
                         AND NVL (papf.effective_end_date, SYSDATE ) ORDER BY 2;

