SELECT   user_name, description, NVL (email_address, 'Email Id Missing')
    FROM fnd_user
   WHERE user_name IN (
            SELECT employee_number
              FROM per_all_people_f papf
             WHERE person_id IN (
                      SELECT person_id
                        FROM per_all_assignments_f paaf
                       WHERE location_id IN (SELECT location_id
                                               FROM hr_locations_all_tl
                                              WHERE location_id != 1868)
                         AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date
                                                 AND paaf.effective_end_date)
               AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                       AND papf.effective_end_date)
     AND (   email_address IS NULL
          OR LOWER (email_address) NOT LIKE '%qatarairways%'
         )
     AND end_date IS NULL
ORDER BY user_name