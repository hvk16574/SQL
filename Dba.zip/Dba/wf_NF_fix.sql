/*
    DISABLED - Disabled
    QUERY - Do not send me mail
    MAILHTM2 - HTML mail
    MAILHTML - HTML mail with attachments
    SUMHTML - HTML summary mail
    MAILTEXT - Plain text mail
    MAILATTH - Plain text mail with HTML attachments
    SUMMARY - Plain text summary mail

*/
    
BEGIN
  fnd_preference.put('TESTUSER', 'WF', 'MAILTYPE', 'QUERY');
  COMMIT;
END;