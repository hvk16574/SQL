SELECT SUBSTR (ipadrs_frm, (-LENGTH (ipadrs_frm)), 3) || '.' || 
TRUNC (SUBSTR (ipadrs_frm, -9, 3)) || '.' || 
TRUNC (SUBSTR (ipadrs_frm, -6, 3)) || '.' || 
TRUNC (SUBSTR (ipadrs_frm, -3, 3)) || 
DECODE ( ipadrs_to - ipadrs_frm, 0, NULL, ' - ' || 
SUBSTR (ipadrs_to, (-LENGTH (ipadrs_to)), 3) || '.' || 
TRUNC (SUBSTR (ipadrs_to, -9, 3)) || '.' || 
TRUNC (SUBSTR (ipadrs_to, -6, 3)) || '.' || 
TRUNC (SUBSTR (ipadrs_to, -3, 3))) IP 
FROM audit_ip
ORDER BY 1 DESC