BEGIN
   SYS.DBMS_SYSTEM.ksdwrt (2,'ORA-DB: Test Message '|| TO_CHAR (SYSDATE, 'dd/mm/yyyy hh24:mi:ss'));
END;