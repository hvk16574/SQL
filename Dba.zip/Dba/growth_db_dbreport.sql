-- Daily
  SELECT CR_DATE,TO_CHAR (CR_DATE, 'MON'), TO_CHAR (CR_DATE, 'DD'), REGEXP_REPLACE (DATABASESIZE, '[[:alpha:]]', '') ABC FROM DBREPORT.QRDBA_DB_SIZE
ORDER BY 1 DESC;

-- Min, Max, Average of Month 
SELECT TO_CHAR (CR_DATE, 'MON-YY') MONTH, MIN (REGEXP_REPLACE (DATABASESIZE, '[[:alpha:]]', '')) MIN, MAX (REGEXP_REPLACE (DATABASESIZE, '[[:alpha:]]', '')) MAX,
         CEIL (AVG (REGEXP_REPLACE (DATABASESIZE, '[[:alpha:]]', ''))) AVG FROM DBREPORT.QRDBA_DB_SIZE
GROUP BY TO_CHAR (CR_DATE, 'MON-YY') ORDER BY TO_DATE (TO_CHAR (CR_DATE, 'MON-YY'), 'MON-YY') DESC;

--Last Day of Month
  SELECT TO_CHAR (CR_DATE, 'MON-YY'), REGEXP_REPLACE (DATABASESIZE, '[[:alpha:]]', '') ABC FROM DBREPORT.QRDBA_DB_SIZE
   WHERE TRUNC (CR_DATE) = TRUNC (LAST_DAY (CR_DATE) ) ORDER BY TO_DATE (TO_CHAR (CR_DATE, 'MON-YY'), 'MON-YY') DESC;

  --First Day of Month
  SELECT TO_CHAR (CR_DATE, 'MON-YY'), REGEXP_REPLACE (DATABASESIZE, '[[:alpha:]]', '') ABC FROM DBREPORT.QRDBA_DB_SIZE
   WHERE TRUNC (CR_DATE) = TRUNC (LAST_DAY (CR_DATE) - (TO_CHAR (LAST_DAY (CR_DATE), 'DD') - 1)) ORDER BY TO_DATE (TO_CHAR (CR_DATE, 'MON-YY'), 'MON-YY') DESC;

-- Schema Transpose
WITH pivot_data  AS ( SELECT TO_CHAR (CR_DATE, 'MON-YY') MONTH, OWNER, CEIL (AVG (SIZE_MB)) AVG
                      FROM DBREPORT.QRDBA_SCHEMA_SIZE
                      GROUP BY TO_CHAR (CR_DATE, 'MON-YY'), OWNER
                      ORDER BY TO_DATE (TO_CHAR (CR_DATE, 'MON-YY'), 'MON-YY') DESC)
SELECT *
  FROM pivot_data PIVOT (SUM (AVG)                          --<-- pivot_clause
                  FOR month                             --<-- pivot_for_clause
                  IN  ('SEP-13','AUG-13','JUL-13','JUN-13','MAY-13','APR-13','MAR-13','FEB-13','JAN-13','DEC-12','NOV-12','OCT-12',
                       'SEP-12','AUG-12','JUL-12','JUN-12','MAY-12','APR-12','MAR-12','FEB-12','JAN-12','DEC-11','NOV-11','OCT-11',
                       'SEP-11','AUG-11','JUL-11','JUN-11')                          --<-- pivot_in_clause
                               );

  SELECT DISTINCT TO_CHAR (CR_DATE, 'MON-YY') month
    FROM DBREPORT.QRDBA_SCHEMA_SIZE
ORDER BY TO_DATE (TO_CHAR (CR_DATE, 'MON-YY'), 'MON-YY') DESC;