select target_node 
from fnd_concurrent_queues where concurrent_queue_name like 'WFMLRSVC%';  

SELECT b.component_name,  
       c.parameter_name,  
       a.parameter_value , (select target_node 
from fnd_concurrent_queues where concurrent_queue_name like 'WFMLRSVC%') a
FROM fnd_svc_comp_param_vals a,  
     fnd_svc_components b,  
     fnd_svc_comp_params_b c 
WHERE b.component_id = a.component_id  
     AND b.component_type = c.component_type  
     AND c.parameter_id = a.parameter_id 
     AND c.encrypted_flag = 'N' 
     AND b.component_name like '%Mailer%' 
     AND c.parameter_name in ('OUTBOUND_SERVER', 'REPLYTO') 
ORDER BY c.parameter_name; 


telnet qrsmtp.qatarairways.com.qa 25 
EHLO QRHQSD06
MAIL FROM: erpservices@qatarairways.com.qa 
RCPT TO: hkhan@qatarairways.com.qa
DATA 
Subject: Test message 

Test message body 
. 
quit 

FND_PROFILE_OPTIONS_VL