select segment_name,(bytes/1024/1024)  "SIZE MB",tablespace_name,segment_type
from user_segments
order by segment_name
   

select table_name,( ((blocks*8192)-(blocks*avg_space))/1024/1024) "MB size" 
from user_indexes



select
   segment_name           table_name,   
   sum(bytes)/(1024*1024) table_size_meg
from  
   user_extents 
   group by segment_name
   
   
   
   
