SELECT to_char(drivers.LAST_UPDATE_DATE, 'yyyy-mm-dd') install_date,
         bug.BUG_NUMBER,
         patches.patch_type,
         drivers.PLATFORM,
         langs.language,
         drivers.DRIVER_FILE_NAME,
         to_char(runs.start_date, 'HH24":"MI":"SS') start_time,
         to_char(runs.end_date, 'HH24":"MI":"SS') end_time,
         to_char(to_date('00:00:00','HH24:MI:SS') + (runs.end_date - runs.start_date), 'HH24:MI:SS') time_difference,
         (to_number(to_char(to_date('00','HH24')  + (runs.end_date - runs.start_date), 'HH24'))*60) +
         (to_number(to_char(to_date('00','MI')    + (runs.end_date - runs.start_date), 'MI'))) +
         (to_number(to_char(to_date('00','SS')    + (runs.end_date - runs.start_date), 'SS')) / 60) time_dif_min
  FROM apps.ad_bugs bug,
       apps.ad_patch_drivers drivers,
       apps.ad_patch_driver_langs langs,
       apps.ad_applied_patches patches,
       apps.ad_patch_runs runs
  WHERE langs.patch_driver_id = drivers.patch_driver_id AND
        runs.patch_driver_id=drivers.patch_driver_id AND
        patches.APPLIED_PATCH_ID=drivers.APPLIED_PATCH_ID AND
        patches.patch_name=bug.bug_number AND
        drivers.orig_patch_name = 'bug_' || bug.bug_number
--        and bug_number in (9920036,10056653,9508416,9667061,7668608,9927910)
  ORDER BY install_date DESC, start_time DESC;
