SELECT   prha.segment1,
         prha.AUTHORIZATION_STATUS,
         pahv.ACTION_CODE_DSP,
         pahv.ACTION_DATE,
         pahv.EMPLOYEE_NAME,
         papf.employee_number,
         nvl(papf.email_address,fu.email_address),
         pahv.SEQUENCE_NUM,
         pahv.CREATED_BY,
         pahv.EMPLOYEE_ID,
         pahv.OBJECT_REVISION_NUM,
         pahv.NOTE
  FROM   PO_REQUISITION_HEADERS_ALL prha,
         PO_ACTION_HISTORY_V pahv,
         per_all_people_f papf, fnd_user fu
 WHERE   papf.person_id = PAHV.EMPLOYEE_ID
         AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                 AND  papf.effective_end_date
         AND current_employee_flag = 'Y'
         AND object_type_code = 'REQUISITION'
         AND object_id = prha.requisition_header_id
         AND prha.AUTHORIZATION_STATUS != 'APPROVED'
         --                              AND TRUNC (prha.creation_date) = TRUNC (SYSDATE)
         AND prha.wf_item_type = 'REQAPPRV'
         and fu.user_name = papf.employee_number
         AND sequence_num =
               (SELECT   MAX (sequence_num)
                  FROM   PO_ACTION_HISTORY_V
                 WHERE   object_type_code = 'REQUISITION'
                         AND object_id = pahv.object_id);

SELECT   CREATED_BY,
         EMPLOYEE_ID,
         SEQUENCE_NUM,
         ACTION_DATE,
         OBJECT_REVISION_NUM,
         ACTION_CODE_DSP,
         EMPLOYEE_NAME,
         NOTE
  FROM   PO_ACTION_HISTORY_V
 WHERE   object_type_code = 'REQUISITION'
         AND object_id IN
                  (SELECT   requisition_header_id
                     FROM   PO_REQUISITION_HEADERS_ALL
                    WHERE       AUTHORIZATION_STATUS = 'INCOMPLETE'
                            AND TRUNC (creation_date) = TRUNC (SYSDATE)
                            AND wf_item_type = 'REQAPPRV');