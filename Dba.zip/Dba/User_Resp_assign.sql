SELECT   (CASE
             WHEN organization_id = 574 AND paaf.payroll_id = 61
             THEN
                (SELECT   'QAG_CABIN_CREW_SSHR'
                   FROM   fnd_user
                  WHERE   user_name = papf.employee_number
                          AND user_id NOT IN (SELECT   user_id
                                                FROM   fnd_user_resp_groups_direct
                                               WHERE   RESPONSIBILITY_ID = 53076 AND RESPONSIBILITY_application_ID = 800))
             WHEN hr_general.DECODE_GRADE (paaf.grade_id) LIKE 'FD%' AND paaf.payroll_id = 61
             THEN
                (SELECT   'QAG_DECK_CREW_SSHR'
                   FROM   fnd_user
                  WHERE   user_name = papf.employee_number
                          AND user_id NOT IN (SELECT   user_id
                                                FROM   fnd_user_resp_groups_direct
                                               WHERE   RESPONSIBILITY_ID = 53458 AND RESPONSIBILITY_application_ID = 800))
             WHEN paaf.payroll_id = 61
             THEN
                DECODE (
                   (SELECT   1
                      FROM   fnd_user
                     WHERE   user_name = papf.employee_number
                             AND user_id NOT IN
                                      (SELECT   user_id
                                         FROM   fnd_user_resp_groups_direct
                                        WHERE   RESPONSIBILITY_ID IN (51374, 51375) AND RESPONSIBILITY_application_ID = 800)),
                   1,
                   DECODE (
                      (SELECT   COUNT (b.employee_number)
                         FROM   per_all_people_f a, per_all_people_f b, per_all_assignments_f c
                        WHERE       c.supervisor_id = a.person_id
                                AND b.person_id = c.person_id
                                AND TRUNC (SYSDATE) BETWEEN a.effective_start_date AND a.effective_end_date
                                AND a.current_employee_flag = 'Y'
                                AND c.primary_flag = 'Y'
                                AND TRUNC (SYSDATE) BETWEEN c.effective_start_date AND c.effective_end_date
                                AND a.employee_number = papf.employee_number
                                AND b.current_employee_flag = 'Y'
                                AND TRUNC (SYSDATE) BETWEEN b.effective_start_date AND b.effective_end_date),
                      0,
                      'QR_EMPLOYEE_DIRECT_ACCESS',
                      'QR_MANAGER_DIRECT_ACCESS'
                   )
                )
             WHEN payroll_id = 122
             THEN
                DECODE (
                   (SELECT   1
                      FROM   fnd_user
                     WHERE   user_name = papf.employee_number
                             AND user_id NOT IN
                                      (SELECT   user_id
                                         FROM   fnd_user_resp_groups_direct
                                        WHERE   RESPONSIBILITY_ID IN (53136, 53137) AND RESPONSIBILITY_application_ID = 800)),
                   1,
                   DECODE (
                      (SELECT   COUNT (b.employee_number)
                         FROM   per_all_people_f a, per_all_people_f b, per_all_assignments_f c
                        WHERE       c.supervisor_id = a.person_id
                                AND b.person_id = c.person_id
                                AND TRUNC (SYSDATE) BETWEEN a.effective_start_date AND a.effective_end_date
                                AND a.current_employee_flag = 'Y'
                                AND c.primary_flag = 'Y'
                                AND TRUNC (SYSDATE) BETWEEN c.effective_start_date AND c.effective_end_date
                                AND a.employee_number = papf.employee_number
                                AND b.current_employee_flag = 'Y'
                                AND TRUNC (SYSDATE) BETWEEN b.effective_start_date AND b.effective_end_date),
                      0,
                      'DIA_EMPLOYEE_DIRECT_ACCESS',
                      'DIA_MANAGER_DIRECT_ACCESS'
                   )
                )
             WHEN payroll_id = 84
             THEN
                DECODE (
                   (SELECT   1
                      FROM   fnd_user
                     WHERE   user_name = papf.employee_number
                             AND user_id NOT IN
                                      (SELECT   user_id
                                         FROM   fnd_user_resp_groups_direct
                                        WHERE   RESPONSIBILITY_ID IN (53116, 53117) AND RESPONSIBILITY_application_ID = 800)),
                   1,
                   DECODE (
                      (SELECT   COUNT (b.employee_number)
                         FROM   per_all_people_f a, per_all_people_f b, per_all_assignments_f c
                        WHERE       c.supervisor_id = a.person_id
                                AND b.person_id = c.person_id
                                AND TRUNC (SYSDATE) BETWEEN a.effective_start_date AND a.effective_end_date
                                AND a.current_employee_flag = 'Y'
                                AND c.primary_flag = 'Y'
                                AND TRUNC (SYSDATE) BETWEEN c.effective_start_date AND c.effective_end_date
                                AND a.employee_number = papf.employee_number
                                AND b.current_employee_flag = 'Y'
                                AND TRUNC (SYSDATE) BETWEEN b.effective_start_date AND b.effective_end_date),
                      0,
                      'QC_EMPLOYEE_DIRECT_ACCESS',
                      'QC_MANAGER_DIRECT_ACCESS'
                   )
                )
             WHEN payroll_id = 142
             THEN
                DECODE (
                   (SELECT   1
                      FROM   fnd_user
                     WHERE   user_name = papf.employee_number
                             AND user_id NOT IN
                                      (SELECT   user_id
                                         FROM   fnd_user_resp_groups_direct
                                        WHERE   RESPONSIBILITY_ID IN (53138, 53139) AND RESPONSIBILITY_application_ID = 800)),
                   1,
                   DECODE (
                      (SELECT   COUNT (b.employee_number)
                         FROM   per_all_people_f a, per_all_people_f b, per_all_assignments_f c
                        WHERE       c.supervisor_id = a.person_id
                                AND b.person_id = c.person_id
                                AND TRUNC (SYSDATE) BETWEEN a.effective_start_date AND a.effective_end_date
                                AND a.current_employee_flag = 'Y'
                                AND c.primary_flag = 'Y'
                                AND TRUNC (SYSDATE) BETWEEN c.effective_start_date AND c.effective_end_date
                                AND a.employee_number = papf.employee_number
                                AND b.current_employee_flag = 'Y'
                                AND TRUNC (SYSDATE) BETWEEN b.effective_start_date AND b.effective_end_date),
                      0,
                      'QD_EMPLOYEE_DIRECT_ACCESS',
                      'QD_MANAGER_DIRECT_ACCESS'
                   )
                )
             WHEN payroll_id = 162
             THEN
                DECODE (
                   (SELECT   1
                      FROM   fnd_user
                     WHERE   user_name = papf.employee_number
                             AND user_id NOT IN
                                      (SELECT   user_id
                                         FROM   fnd_user_resp_groups_direct
                                        WHERE   RESPONSIBILITY_ID IN (53097, 53096) AND RESPONSIBILITY_application_ID = 800)),
                   1,
                   DECODE (
                      (SELECT   COUNT (b.employee_number)
                         FROM   per_all_people_f a, per_all_people_f b, per_all_assignments_f c
                        WHERE       c.supervisor_id = a.person_id
                                AND b.person_id = c.person_id
                                AND TRUNC (SYSDATE) BETWEEN a.effective_start_date AND a.effective_end_date
                                AND a.current_employee_flag = 'Y'
                                AND c.primary_flag = 'Y'
                                AND TRUNC (SYSDATE) BETWEEN c.effective_start_date AND c.effective_end_date
                                AND a.employee_number = papf.employee_number
                                AND b.current_employee_flag = 'Y'
                                AND TRUNC (SYSDATE) BETWEEN b.effective_start_date AND b.effective_end_date),
                      0,
                      'QF_EMPLOYEE_DIRECT_ACCESS',
                      'QF_MANAGER_DIRECT_ACCESS'
                   )
                )
             WHEN payroll_id = 202
             THEN
                DECODE (
                   (SELECT   1
                      FROM   fnd_user
                     WHERE   user_name = papf.employee_number
                             AND user_id NOT IN
                                      (SELECT   user_id
                                         FROM   fnd_user_resp_groups_direct
                                        WHERE   RESPONSIBILITY_ID IN (53158, 53159) AND RESPONSIBILITY_application_ID = 800)),
                   1,
                   DECODE (
                      (SELECT   COUNT (b.employee_number)
                         FROM   per_all_people_f a, per_all_people_f b, per_all_assignments_f c
                        WHERE       c.supervisor_id = a.person_id
                                AND b.person_id = c.person_id
                                AND TRUNC (SYSDATE) BETWEEN a.effective_start_date AND a.effective_end_date
                                AND a.current_employee_flag = 'Y'
                                AND c.primary_flag = 'Y'
                                AND TRUNC (SYSDATE) BETWEEN c.effective_start_date AND c.effective_end_date
                                AND a.employee_number = papf.employee_number
                                AND b.current_employee_flag = 'Y'
                                AND TRUNC (SYSDATE) BETWEEN b.effective_start_date AND b.effective_end_date),
                      0,
                      'QS_EMPLOYEE_DIRECT_ACCESS',
                      'QS_MANAGER_DIRECT_ACCESS'
                   )
                )
          END)
            abc,
         papf.employee_number,
         papf.full_name,
         papf.person_id,
         papf.email_address,
         papf.date_of_birth,
         NVL (paaf.payroll_id, 0) payroll_id,
         paaf.organization_id,
         HR_GENERAL.DECODE_ORGANIZATION (paaf.organization_id) org_name,
         papf.creation_date,
         DECODE (NVL (ppg.segment6, 'N'), 'N', 'N', 'Y') Uniform
  FROM   per_all_people_f papf, per_all_assignments_f paaf, pay_people_groups ppg
 WHERE       TRUNC (SYSDATE) BETWEEN papf.effective_start_date AND papf.effective_end_date
         AND papf.current_employee_flag = 'Y'
         AND papf.person_id = paaf.person_id
         AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date AND paaf.effective_end_date
         AND paaf.primary_flag = 'Y'
         --         AND paaf.payroll_id = 61
         AND paaf.people_group_id = ppg.people_group_id
--      AND upper(papf.employee_number) = '23339'