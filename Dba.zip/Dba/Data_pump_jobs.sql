select x.message ,x.sid ,x.opname ,x.username,
x.units ,x.totalwork,x.sofar ,x.start_time,
x.last_update_time, x.elapsed_seconds/3600 time_remain_in_hour
from V$SESSION_LONGOPS x where /*x.target_desc='EXPORT'
and  */ x.time_remaining >0 ;

SELECT   * FROM dba_datapump_jobs;

SELECT   owner_name,job_name,operation,job_mode,state,attached_sessions
    FROM   dba_datapump_jobs
   WHERE   job_name NOT LIKE 'BIN$%' ORDER BY   1, 2;

SELECT   o.status,o.object_id,o.object_type,'drop table ' || o.owner || '.' || object_name || ';' "OWNER.OBJECT"
    FROM   dba_objects o, dba_datapump_jobs j
   WHERE       o.owner = j.owner_name AND o.object_name = j.job_name  AND j.job_name NOT LIKE 'BIN$%' ORDER BY   4, 2;

SELECT   sid, serial# FROM   v$session s, dba_datapump_sessions d
 WHERE   s.saddr = d.saddr;

SELECT   sid, serial#, sofar, totalwork, opname
  FROM   v$session_longops

  where sofar != totalwork
  
DECLARE
   h1 NUMBER;
BEGIN
   h1 := DBMS_DATAPUMP.ATTACH('SYS_IMPORT_SCHEMA_01','SYS');
   DBMS_DATAPUMP.STOP_JOB (h1);
END;
/  