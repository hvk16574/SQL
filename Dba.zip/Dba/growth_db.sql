select cr_date,to_char(cr_date,'MON'),to_char(cr_date,'DD'),REGEXP_REPLACE(databasesize, '[[:alpha:]]','')  abc from dbreport.QRDBA_DB_SIZE
order by 1 desc;

  SELECT   TO_CHAR (creation_time, 'RRRR MM') "Month", SUM (bytes) / 1024 / 1024 / 1024 "Growth in GB"
    FROM   sys.v_$datafile
   WHERE   creation_time > SYSDATE - 365
GROUP BY   TO_CHAR (creation_time, 'RRRR MM')


select sum(space_used_delta) / 1024 / 1024 "Space used (M)", sum(c.bytes) / 1024 / 1024 "Total Schema Size (M)",
round(sum(space_used_delta) / sum(c.bytes) * 100, 2) || '%' "Percent of Total Disk Usage"
from
   dba_hist_snapshot sn,
   dba_hist_seg_stat a,
   dba_objects b,
   dba_segments c
see code depot for full script
where end_interval_time > trunc(sysdate) - &days_back
and sn.snap_id = a.snap_id
and b.object_id = a.obj#
and b.owner = c.owner
and b.object_name = c.segment_name
and c.owner = '&schema_name'
and space_used_delta > 0;
 
ttitle "Total Disk Used by Object Type"
 
select c.segment_type, sum(space_used_delta) / 1024 / 1024 "Space used (M)", sum(c.bytes) / 1024 / 1024 "Total Space (M)",
round(sum(space_used_delta) / sum(c.bytes) * 100, 2) || '%' "Percent of Total Disk Usage"
from
   dba_hist_snapshot sn,
   dba_hist_seg_stat a,
   dba_objects b,
   dba_segments c
where end_interval_time > trunc(sysdate) - &days_back
and sn.snap_id = a.snap_id
and b.object_id = a.obj#
and b.owner = c.owner
and b.object_name = c.segment_name
and space_used_delta > 0
--and c.owner = '&schema_name'
group by rollup(segment_type);
