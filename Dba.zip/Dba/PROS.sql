connect ondprod_1/a1#05tn#@SN001021

set pages 0
set feed off
set heads off
set underline off
set termout off

spool E:\temp\PROStoJDE.txt

select 'FLIGHT_NO,FLIGHT_DATE,LF' from dual;
SELECT      flight_no
           || '|'
           || flight_date
           || '|'
           || MAX (DECODE (compartment, 'F', 'F' || total_booked || '/'))
           || MAX (DECODE (compartment, 'C', 'C' || total_booked || '/'))
           || MAX (DECODE (compartment, 'Y', 'Y' || total_booked))
              AS "FLIGHT_NO,FLIGHT_DATE,LF"
    FROM   (SELECT   flc.fltnum flight_no,
                     flc.fltdate flight_date,
                     flc.orgn origin,
                     flc.dstn destination,
                     flc.cmpcode compartment,
                     flc.totbkd total_booked
              FROM   flt f,
                     fltcmp flc,
                     (SELECT   f.*, l.legorgn, l.legdstn
                        FROM   schflt f, schleg l
                       WHERE   f.scheffdate =
                                  (SELECT   MAX (scheffdate) FROM schflt)
                               AND f.fltnum = l.fltnum
                               AND f.scheffdate = l.scheffdate
                               AND f.flteffdate = l.flteffdate) fltsch
             WHERE       flc.crrcode = f.crrcode
                     AND flc.fltnum = f.fltnum
                     AND flc.orgn = f.orgn
                     AND flc.dstn = f.dstn
                     AND flc.fltdate = f.fltdate
                     AND flc.fltnum = fltsch.fltnum
                     AND flc.fltdate BETWEEN fltsch.flteffdate
                                         AND  fltsch.fltdscdate
                     AND SUBSTR (
                           fltsch.fltfreq,
                           DECODE (TO_CHAR (flc.fltdate, 'D'),
                                   1, 7,
                                   TO_CHAR (flc.fltdate, 'D') - 1),
                           1
                        ) = 1
                     AND flc.fltdate BETWEEN TRUNC (SYSDATE)
                                         AND  TRUNC (SYSDATE) + 2
                     AND flc.orgn = fltsch.legorgn
                     AND flc.dstn = fltsch.legdstn
                     AND flc.adjcap <> 0)
GROUP BY   flight_no,
           flight_date,
           origin,
           destination
ORDER BY   flight_no, flight_date;
spool off
exit
