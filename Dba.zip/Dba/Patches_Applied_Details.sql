  SELECT   aat.name,
           app.patch_name,
           app.creation_date,
           ROUND ( (apr.end_date - apr.start_date) * 24 * 60, 2) Minutes
    FROM   applsys.ad_applied_patches app,
           applsys.ad_appl_tops aat,
           applsys.ad_patch_drivers apd,
           applsys.ad_patch_runs apr
   WHERE       app.applied_patch_id = apd.applied_patch_id
           AND apd.patch_driver_id = apr.patch_driver_id
           AND apr.appl_top_id = aat.appl_top_id
           AND app.applied_patch_id IN
                    (SELECT   applied_Patch_id
                       FROM   ad_applied_patches
                      WHERE   TRUNC (creation_date) = '31-JAN-2010')
ORDER BY   apr.start_date DESC