SELECT   DISTINCT
         employee_number,
         full_name,
         SUBSTR (HR_GENERAL.DECODE_POSITION_LATEST_NAME (PAaf.POSITION_ID), 1, 
         INSTR (HR_GENERAL.DECODE_POSITION_LATEST_NAME (PAaf.POSITION_ID), '|', 1) - 1)Position,
         hr_general.decode_grade (paaf.grade_id)
  FROM   per_all_people_f a, per_all_assignments_f paaf, pay_payrolls_f ppf
 WHERE       a.person_id = paaf.person_id
         AND ppf.payroll_id(+) = paaf.payroll_id
         AND primary_flag = 'Y'
         AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date AND paaf.effective_end_date
         AND TRUNC (SYSDATE) BETWEEN a.effective_start_date AND a.effective_end_date
         AND current_employee_flag = 'Y'
         AND HR_GENERAL.DECODE_POSITION_LATEST_NAME (PAaf.POSITION_ID) LIKE '%Manager%'
         AND payroll_name = 'QR_PAYROLL'
         AND hr_general.decode_organization (paaf.organization_id) LIKE '%Information Technology%'