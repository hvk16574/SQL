select * from per_absence_attendances where trunc(CREATION_DATE) = trunc(sysdate)
 AND ATTRIBUTE20 like 'Ditching Training in Dubai on%'

delete per_absence_attendances where trunc(CREATION_DATE) = trunc(sysdate)
 AND ATTRIBUTE20 like 'Ditching Training in Dubai on%'

UPDATE   emp_photo ep
   SET   ep.person_id =
            (SELECT   DISTINCT person_id
               FROM   per_all_people_f papf
              WHERE   papf.employee_number = ep.employee_number);

declare
l_dur_dys_less_warning boolean;   
l_dur_hrs_less_warning boolean;
l_exceeds_pto_entit_warning boolean;
l_exceeds_run_total_warning boolean;
l_abs_overlap_warning  boolean;
l_abs_day_after_warning  boolean;
l_dur_overwritten_warning  boolean;
l_absence_attendance_id number;
l_object_version_number number;
l_occurrence number;
l_absence_hours number;
l_absence_days number;
l_ds date;
l_de date;
err_empno varchar2(30);
cursor c1 is select employee_number,person_id,email_address from emp_photo;
begin
FOR c1_rec IN c1
   LOOP
l_absence_hours:=null;
l_ds:=TO_DATE(c1_rec.email_address);
l_de:=TO_DATE(c1_rec.email_address);
l_absence_days:=(l_de-l_ds)+1;
err_empno := c1_rec.employee_number;
apps.HR_PERSON_ABSENCE_API.create_person_absence
                          (p_validate                      =>false
                          ,p_effective_date                =>TRUNC(SYSDATE) 
                          ,p_person_id                     =>c1_rec.person_id    
                          ,p_business_group_id             =>81
                          ,p_absence_attendance_type_id    =>226 
                          ,p_abs_attendance_reason_id      =>262
--                          ,p_comments                      =>l_comments 
                          ,p_date_notification             => sysdate
--                          ,p_date_projected_start          =>l_date_projected_start
--                          ,p_date_projected_end            =>l_date_projected_end 
                          ,p_date_start                    =>l_ds
                          ,p_date_end                      =>l_de 
                          ,p_absence_days                  =>l_absence_days  
                       ,p_absence_hours                 =>l_absence_hours
  --                        ,p_authorising_person_id         =>l_authorising_person_id 
    --                      ,p_attribute_category            =>l_attribute_category                           
      --                    ,p_replacement_person_id         =>l_replacement_person_id
  --                        ,p_attribute1                    =>l_attribute1 
--                          ,p_attribute2                    =>l_attribute2
                          ,p_attribute16                   => to_char(to_date(c1_rec.email_address),'YYYY/MM/DD HH24:MI:SS')   
                        ,p_attribute17                   =>'DUBAI'
                  --   ,p_attribute9                   =>'N' 
                         --,p_attribute19                   =>l_attribute19 
                          ,p_attribute20                   => 'Ditching Training in Dubai on '||c1_rec.email_address
                          /*,p_absence_attendance_id        =>l_absence_attendance_id
                          ,p_object_version_number         =>l_object_version_number 
                          ,p_occurrence                    =>l_occurrence*/
                          ,p_absence_attendance_id         => l_absence_attendance_id
                          ,p_object_version_number         => l_object_version_number
                            ,p_occurrence                  => l_occurrence
                          ,p_dur_dys_less_warning          =>l_dur_dys_less_warning   
                          ,p_dur_hrs_less_warning           =>l_dur_hrs_less_warning 
                          ,p_exceeds_pto_entit_warning      =>l_exceeds_pto_entit_warning
                          ,p_exceeds_run_total_warning    =>l_exceeds_run_total_warning 
                          ,p_abs_overlap_warning          =>l_abs_overlap_warning  
                          ,p_abs_day_after_warning         =>l_abs_day_after_warning  
                          ,p_dur_overwritten_warning       =>l_dur_overwritten_warning
                          );
                          dbms_output.PUT_LINE('Success. Employee#:- '||c1_rec.employee_number||' Exit date:- '|| c1_rec.email_address);
                          err_empno := c1_rec.employee_number;
end loop;                          
exception when others then
dbms_output.PUT_LINE('Employee#:- '||err_empno||sqlerrm);
end;





--BEGIN
--   fnd_global.apps_initialize (-1, 20536, 800, NULL, NULL);
--END;

