SELECT * FROM wf_notifications WHERE recipient_role = CASE WHEN LENGTH (:emp_num) < 5 THEN LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0') ELSE :emp_num END 
order by BEGIN_DATE desc;

SELECT *  FROM wf_notifications WHERE NOTIFICATION_ID = :nid;

select ERROR_MESSAGE from wf_item_activity_statuses_v WHERE NOTIFICATION_ID = :nid;

SELECT WORKFLOWITEMEO.ITEM_TYPE, WORKFLOWITEMEO.ITEM_KEY, WF_FWKMON.GETITEMSTATUS (WORKFLOWITEMEO.ITEM_TYPE, WORKFLOWITEMEO.ITEM_KEY, WORKFLOWITEMEO.END_DATE, 
       WORKFLOWITEMEO.ROOT_ACTIVITY, WORKFLOWITEMEO.ROOT_ACTIVITY_VERSION) AS STATUS_CODE, WN.NOTIFICATION_ID,',', WN.MESSAGE_NAME, WN.RECIPIENT_ROLE, WN.STATUS, 
       WN.MAIL_STATUS, (SELECT    notification_preference || '-' || (SELECT PREFERENCE_VALUE FROM FND_USER_PREFERENCES WHERE PREFERENCE_NAME = 'MAILTYPE' AND user_name = wlr.name) 
                        FROM wf_local_roles wlr WHERE name = WN.RECIPIENT_ROLE) WLR_FUP_NOTI,
       WN.BEGIN_DATE, WN.ORIGINAL_RECIPIENT, WN.FROM_USER, WN.TO_USER, WN.SUBJECT, WN.FROM_ROLE, WN.USER_KEY --WN.*
  FROM WF_ITEMS WORKFLOWITEMEO, WF_ITEM_TYPES_VL WORKFLOWITEMTYPEEO, WF_ACTIVITIES_VL ACTIVITYEO, WF_NOTIFICATIONS WN
 WHERE     WORKFLOWITEMEO.ITEM_TYPE = WORKFLOWITEMTYPEEO.NAME AND ACTIVITYEO.ITEM_TYPE = WORKFLOWITEMEO.ITEM_TYPE
       AND ACTIVITYEO.NAME = WORKFLOWITEMEO.ROOT_ACTIVITY AND ACTIVITYEO.VERSION = WORKFLOWITEMEO.ROOT_ACTIVITY_VERSION
       AND WORKFLOWITEMEO.ITEM_KEY = WN.ITEM_KEY AND WORKFLOWITEMEO.ITEM_TYPE = WN.MESSAGE_TYPE AND WN.MAIL_STATUS = 'MAIL' ORDER BY 3;
       
--/*

UPDATE wf_notifications SET MAIL_STATUS = 'SENT'
 WHERE     MAIL_STATUS = 'MAIL' AND RECIPIENT_ROLE IN (SELECT user_name FROM fnd_user WHERE     user_name IN (SELECT DISTINCT RECIPIENT_ROLE FROM wf_notifications WHERE MAIL_STATUS = 'MAIL'-- AND status = 'OPEN'
 ) AND email_address IS NULL);

UPDATE   wf_notifications   SET   mail_status = 'SENT'
 WHERE notification_id  in 
-- (138756203 )
 
 (SELECT  WN.NOTIFICATION_ID
  FROM WF_ITEMS WORKFLOWITEMEO, WF_ITEM_TYPES_VL WORKFLOWITEMTYPEEO, WF_ACTIVITIES_VL ACTIVITYEO, WF_NOTIFICATIONS WN
 WHERE     WORKFLOWITEMEO.ITEM_TYPE = WORKFLOWITEMTYPEEO.NAME AND ACTIVITYEO.ITEM_TYPE = WORKFLOWITEMEO.ITEM_TYPE
       AND ACTIVITYEO.NAME = WORKFLOWITEMEO.ROOT_ACTIVITY AND ACTIVITYEO.VERSION = WORKFLOWITEMEO.ROOT_ACTIVITY_VERSION
       AND WORKFLOWITEMEO.ITEM_KEY = WN.ITEM_KEY AND WORKFLOWITEMEO.ITEM_TYPE = WN.MESSAGE_TYPE AND WN.MAIL_STATUS = 'MAIL' 
       AND WF_FWKMON.GETITEMSTATUS (WORKFLOWITEMEO.ITEM_TYPE, WORKFLOWITEMEO.ITEM_KEY, WORKFLOWITEMEO.END_DATE, 
            WORKFLOWITEMEO.ROOT_ACTIVITY, WORKFLOWITEMEO.ROOT_ACTIVITY_VERSION)  = 'ERROR'  )

*/

SELECT n.begin_date, n.status, n.mail_status, n.recipient_role, de.def_enq_time, de.def_deq_time, de.def_state, ou.out_enq_time, ou.out_deq_time, ou.out_state
  FROM applsys.wf_notifications n,
       (SELECT d.enq_time def_enq_time, d.deq_time def_deq_time,
               TO_NUMBER ( (SELECT VALUE FROM TABLE (d.user_data.parameter_list) WHERE NAME = 'NOTIFICATION_ID')) d_notification_id, msg_state def_state
          FROM applsys.aq$wf_deferred d
         WHERE d.corr_id = 'APPS:oracle.apps.wf.notification.send') de,
       (SELECT o.deq_time out_deq_time, o.enq_time out_enq_time, TO_NUMBER ( (SELECT str_value FROM TABLE (o.user_data.header.properties) WHERE NAME = 'NOTIFICATION_ID')) o_notification_id, msg_state out_state
          FROM applsys.aq$wf_notification_out o) ou
 WHERE     n.notification_id = 138810273 AND --:NOTIFICATION_ID
          recipient_role = :emp_no
       AND n.notification_id = de.d_notification_id(+)
       AND n.notification_id = ou.o_notification_id(+)
/

SELECT item_key,a.*  FROM wf_notifications a WHERE MAIL_STATUS = 'MAIL' 
 -- AND status = 'CLOSED' --AND TRUNC (BEGIN_DATE) <= TRUNC (SYSDATE) - 1
--AND MESSAGE_NAME in ( 'LOGIN_HELP_MSG_PWD',  'MSG_PASSWORDRESET', 'HR_SFL_MSG')
order by BEGIN_DATE asc; 
SELECT  count(1)  FROM wf_notifications WHERE MAIL_STATUS = 'MAIL' AND status = 'OPEN' AND TRUNC (BEGIN_DATE) <= TRUNC (SYSDATE) - 1;

SELECT * FROM   FND_USER_PREFERENCES WHERE   PREFERENCE_NAME = 'MAILTYPE';

select name, display_name, name, notification_preference, email_address from wf_local_roles where notification_preference = 'DISABLED'
and name in (SELECT  user_name  FROM   FND_USER_PREFERENCES WHERE PREFERENCE_VALUE like 'MAIL%');

SELECT 
--name, display_name, name, notification_preference, email_address, user_name,
       'UPDATE WF_LOCAL_ROLES SET notification_preference = ''' || PREFERENCE_VALUE || ''' WHERE name = ''' || user_name || ''';'
  FROM wf_local_roles, FND_USER_PREFERENCES
 WHERE notification_preference = 'DISABLED' AND name = user_name AND PREFERENCE_VALUE LIKE 'MAIL%';

SELECT name, 'WLR', notification_preference FROM wf_local_roles WHERE     name = CASE WHEN LENGTH (:emp_num) < 5 THEN LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0') ELSE :emp_num END AND user_flag = 'Y'
UNION
SELECT user_name, 'FUP', preference_value FROM fnd_user_preferences WHERE     module_name = 'WF' AND preference_name = 'MAILTYPE' AND user_name = CASE WHEN LENGTH (:emp_num) < 5 THEN LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0') ELSE :emp_num END;
 
SELECT 'WLR',name, display_name, notification_preference, email_address FROM wf_local_roles WHERE     name = CASE WHEN LENGTH (:emp_num) < 5 THEN LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0') ELSE :emp_num END AND user_flag = 'Y'
UNION
SELECT 'FUP', fup.* FROM fnd_user_preferences fup WHERE     module_name = 'WF' AND preference_name = 'MAILTYPE' AND user_name = CASE WHEN LENGTH (:emp_num) < 5 THEN LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0') ELSE :emp_num END;

SELECT 'WLR',name, display_name, notification_preference, email_address FROM wf_local_roles WHERE     name = CASE WHEN LENGTH (:emp_num) < 5 THEN LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0') ELSE :emp_num END AND user_flag = 'Y'
UNION
SELECT 'FUP', fup.* FROM fnd_user_preferences fup WHERE     module_name = 'WF' AND preference_name = 'MAILTYPE' AND user_name = CASE WHEN LENGTH (:emp_num) < 5 THEN LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0') ELSE :emp_num END;


UPDATE wf_local_roles SET notification_preference = 'MAILHTML' WHERE     name = CASE WHEN LENGTH (:emp_num) < 5 THEN LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0') ELSE :emp_num END AND user_flag = 'Y';

UPDATE fnd_user_preferences SET preference_value = 'MAILHTML' WHERE     module_name = 'WF' AND preference_name = 'MAILTYPE' AND user_name = CASE WHEN LENGTH (:emp_num) < 5 THEN LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0') ELSE :emp_num END;


 --IN (SELECT   RECIPIENT_ROLE FROM   wf_notifications WHERE   MAIL_STATUS = 'MAIL');

SELECT 'Insert into FND_USER_PREFERENCES Values (''' || RECIPIENT_ROLE|| ''', ''WF'', ''MAILTYPE'', ''MAILHTML'');'
  FROM   wf_notifications
 WHERE   MAIL_STATUS = 'MAIL' AND RECIPIENT_ROLE NOT IN (SELECT   user_name FROM   FND_USER_PREFERENCES WHERE   PREFERENCE_NAME = 'MAILTYPE');

/*

UPDATE   wf_notifications   SET   mail_status = 'SENT'
 WHERE notification_id = 115413464   
 
  end_date IS NOT NULL AND status = 'CLOSED' AND MAIL_STATUS = 'MAIL';

UPDATE wf_notifications
   SET MAIL_STATUS = 'SENT'
 WHERE MAIL_STATUS = 'MAIL' AND status = 'OPEN' AND TRUNC (BEGIN_DATE) <= TRUNC (SYSDATE) - 1
 AND MESSAGE_NAME in ( 'LOGIN_HELP_MSG_PWD',  'MSG_PASSWORDRESET', 'HR_SFL_MSG')
  
UPDATE   wf_notifications SET   mail_status = 'SENT'
 WHERE   MAIL_STATUS = 'MAIL' AND TO_CHAR (BEGIN_DATE, 'YYYY') < 2010

UPDATE wf_notifications
   SET MAIL_STATUS = 'SENT'
 WHERE MAIL_STATUS = 'MAIL' AND status = 'OPEN' AND TRUNC (BEGIN_DATE) <= TRUNC (SYSDATE) - 1


UPDATE wf_notifications SET MAIL_STATUS = 'SENT'
 WHERE MAIL_STATUS = 'MAIL' AND status = 'OPEN' AND TRUNC (BEGIN_DATE) <= TRUNC (SYSDATE) - 2;
 
 APINVAPR

UPDATE wf_notifications SET MAIL_STATUS = 'SENT'
 WHERE MAIL_STATUS = 'MAIL' AND status = 'CANCELED';

UPDATE wf_notifications SET MAIL_STATUS = 'SENT'
 WHERE     MAIL_STATUS = 'MAIL' AND RECIPIENT_ROLE IN (SELECT user_name FROM fnd_user WHERE     user_name IN (SELECT DISTINCT RECIPIENT_ROLE FROM wf_notifications WHERE MAIL_STATUS = 'MAIL' AND status = 'OPEN') AND email_address IS NULL);

SELECT COUNT (1) FROM wf_notifications WHERE MAIL_STATUS = 'MAIL' AND status = 'OPEN' AND TRUNC (BEGIN_DATE) <= TRUNC (SYSDATE) - 2;

SELECT trunc(begin_date),count(1)  FROM wf_notifications
where /*MAIL_STATUS = 'SENT'
 AND */ TRUNC (BEGIN_DATE) >= TRUNC (SYSDATE) - 20
 group by trunc(begin_date)
 
*/

SELECT   'UPDATE   FND_USER_PREFERENCES  SET   PREFERENCE_VALUE = ''MAILHTML'' WHERE USER_NAME = '''
         || USER_NAME || ''' AND MODULE_NAME = ''WF''AND PREFERENCE_NAME = ''MAILTYPE'';'
  FROM   FND_USER_PREFERENCES
 WHERE       PREFERENCE_NAME = 'MAILTYPE' AND PREFERENCE_VALUE IS NULL
         AND user_name IN (SELECT   user_name FROM   fnd_user WHERE   EMAIL_ADDRESS IS NOT NULL);
         
select * from per_all_people_f papf
where employee_number in (
SELECT   user_name FROM   fnd_user WHERE   EMAIL_ADDRESS IS NULL and end_date is null )
and email_address is null 
                  AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                          AND papf.effective_end_date
order by 1;

SELECT * FROM   FND_USER_PREFERENCES WHERE   PREFERENCE_NAME = 'MAILTYPE' and user_name = '13395';

SELECT   user_name FROM   fnd_user WHERE   EMAIL_ADDRESS IS NULL and end_date is null and user_name in (
SELECT RECIPIENT_ROLE FROM   wf_notifications WHERE   MAIL_STATUS = 'MAIL');


SELECT 'Insert into FND_USER_PREFERENCES Values (''' || RECIPIENT_ROLE|| ''', ''WF'', ''MAILTYPE'', ''MAILHTML'');'
  FROM   wf_notifications
 WHERE   MAIL_STATUS = 'MAIL' AND RECIPIENT_ROLE NOT IN (SELECT   user_name FROM   FND_USER_PREFERENCES WHERE   PREFERENCE_NAME = 'MAILTYPE')
 and RECIPIENT_ROLE in (SELECT   user_name FROM   fnd_user WHERE   EMAIL_ADDRESS IS NOT NULL and end_date is null);


SELECT MESSAGE_NAME, STATUS, count(1) FROM   wf_notifications WHERE   MAIL_STATUS = 'MAIL'
group by MESSAGE_NAME, STATUS;

HR_MESSAGE

select * from dba_objects where object_name like 'HR%MESS%'



SELECT * FROM wf_local_roles WHERE name ='PER_ROLE:'||:person_id and orig_system = 'PER_ROLE'

SELECT * FROM wf_local_roles where name = :fnd_user_name and  orig_system = 'FND_USR'




WF_ITEM_ACTIVITY_STATUSES, 
WF_ITEM_ACTIVITY_STATUSES_H, 
WF_ITEM_ATTRIBUTE_VALUES, 
WF_ITEMS, 
WF_NOTIFICATIONS, 
WF_NOTIFICATION_ATTRIBUTES



/*  REBUILD THE WF_NOTIFICATION_OUT QUEUE

STEP 1. Stop the mailer, listeners and service component container in that order.

STEP 2. Run $FND_TOP/sql/wfntfqup.sql:
sqlplus apps/<apps_passwd> @$FND_TOP/patch/115/sql/wfntfqup apps <apps_passwd>
applsys

This job purges the wf_notification_out outbound message queue and repopulates from the
WF_NOTIFICATION table:

STEP 3. Ensure that this index is in place:

SQL> select index_name,column_name,column_position
from dba_ind_columns
where table_name='WF_NOTIFICATION_OUT' and
table_owner='APPLSYS'
> WF_NOTIFICATION_OUT_N1 CORRID 

If it's not there one can add it back using $FND_TOP/sql/wfqidxc.sql. First check to see if
$FND_TOP/patch/115/sql/wfqidxc2.sql is present and if yes use that instead.

@$FND_TOP/patch/115/sql/wfqidxc2.sql APPLSYS APPS APPLSYSX

STEP 4. Restart the container, listeners and mailer in that order to test.

create or replace synonym WF_NOTIFICATION_OUT for APPLSYS.WF_NOTIFICATION_OUT;

alter package WF_DIAGNOSTICS compile body;

*/
;

SELECT WORKFLOWITEMEO.ITEM_TYPE, count(1)
  FROM WF_ITEMS WORKFLOWITEMEO, WF_ITEM_TYPES_VL WORKFLOWITEMTYPEEO, WF_ACTIVITIES_VL ACTIVITYEO, WF_NOTIFICATIONS WN
 WHERE     WORKFLOWITEMEO.ITEM_TYPE = WORKFLOWITEMTYPEEO.NAME AND ACTIVITYEO.ITEM_TYPE = WORKFLOWITEMEO.ITEM_TYPE
       AND ACTIVITYEO.NAME = WORKFLOWITEMEO.ROOT_ACTIVITY AND ACTIVITYEO.VERSION = WORKFLOWITEMEO.ROOT_ACTIVITY_VERSION
       AND WORKFLOWITEMEO.ITEM_KEY = WN.ITEM_KEY AND WORKFLOWITEMEO.ITEM_TYPE = WN.MESSAGE_TYPE AND WN.MAIL_STATUS = 'MAIL' 
       group by WORKFLOWITEMEO.ITEM_TYPE ORDER BY 2 desc;

SELECT fcp.logfile_name
FROM fnd_concurrent_queues fcq, fnd_concurrent_processes fcp
WHERE concurrent_queue_name in ('WFMLRSVC')
AND fcq.concurrent_queue_id = fcp.concurrent_queue_id
AND fcq.application_id = fcp.queue_application_id
AND fcp.process_status_code = 'A';                         

UPDATE wf_notifications SET MAIL_STATUS = 'SENT'
 WHERE MAIL_STATUS = 'MAIL' AND status = 'OPEN'  and message_type = 'APINVAPR';