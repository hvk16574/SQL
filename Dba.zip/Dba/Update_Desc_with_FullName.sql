SELECT user_name, description, end_date
  FROM fnd_user
 WHERE end_date IS NULL AND description IS NULL;

CREATE TABLE fnd_user_hvk TABLESPACE qair AS SELECT * FROM fnd_user;

UPDATE fnd_user
   SET description =
          (SELECT full_name
             FROM per_all_people_f
            WHERE employee_number = user_name
              AND TRUNC (SYSDATE) BETWEEN effective_start_date
                                      AND effective_end_date)
 WHERE end_date IS NULL AND description IS NULL;