UPDATE APPLSYS.FND_USER FUSER
   SET FUSER.EMAIL_ADDRESS =
          (SELECT PAP.EMAIL_ADDRESS
             FROM HR.PER_ALL_PEOPLE_F PAP
            WHERE FUSER.EMPLOYEE_ID = PAP.PERSON_ID AND pap.email_address IS NOT NULL AND ROWNUM < 2)
 WHERE EXISTS
          (SELECT PAP.EMAIL_ADDRESS
             FROM HR.PER_ALL_PEOPLE_F PAP
            WHERE fuser.employee_id = pap.person_id --      AND   fu.email_address <> pap.email_address
                  AND fuser.email_address IS NULL AND pap.email_address IS NOT NULL);