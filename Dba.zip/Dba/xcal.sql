select lpad( Month, 20-(20-length(month))/2 ) month,
"Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"
from (select to_char(dt,'fmMonthfm YYYY') month,
CASE when to_char(dt,'fmMonthfm YYYY') like 'Dec%' AND to_char(dt+1,'iw') = '01' then '53'
when to_char(dt,'fmMonthfm YYYY') like 'Jan%' AND to_char(dt+1,'iw') = '53' then '.5'
else to_char(dt+1,'iw')
END week,
max(decode(to_char(dt,'d'),'1',lpad(to_char(dt,'fmdd'),2))) "Su",
max(decode(to_char(dt,'d'),'2',lpad(to_char(dt,'fmdd'),2))) "Mo",
max(decode(to_char(dt,'d'),'3',lpad(to_char(dt,'fmdd'),2))) "Tu",
max(decode(to_char(dt,'d'),'4',lpad(to_char(dt,'fmdd'),2))) "We",
max(decode(to_char(dt,'d'),'5',lpad(to_char(dt,'fmdd'),2))) "Th",
max(decode(to_char(dt,'d'),'6',lpad(to_char(dt,'fmdd'),2))) "Fr",
max(decode(to_char(dt,'d'),'7',lpad(to_char(dt,'fmdd'),2))) "Sa"
from (select trunc(sysdate,'y')-1+rownum dt
from all_objects
where rownum <= add_months(trunc(sysdate,'y'),12) - trunc(sysdate,'y'))
group by to_char(dt,'fmMonthfm YYYY'), to_char( dt+1, 'iw' )
order by to_char(dt+1,'iw'))
order by to_date( month, 'Month YYYY' ), to_number(week);