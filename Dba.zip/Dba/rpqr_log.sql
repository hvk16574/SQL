  SELECT FLOOR ( ( (SYSDATE - first_time) * 24 * 60 * 60) / 3600) / 4,
            FLOOR ( ( (SYSDATE - first_time) * 24 * 60 * 60) / 3600)
         || ' HOURS '
         || FLOOR ( ( ( (SYSDATE - first_time) * 24 * 60 * 60) - FLOOR ( ( (SYSDATE - first_time) * 24 * 60 * 60) / 3600) * 3600) / 60)
         || ' MINUTES '
         || ROUND (
               (  ( (SYSDATE - first_time) * 24 * 60 * 60)
                - FLOOR ( ( (SYSDATE - first_time) * 24 * 60 * 60) / 3600) * 3600
                - (FLOOR ( ( ( (SYSDATE - first_time) * 24 * 60 * 60) - FLOOR ( ( (SYSDATE - first_time) * 24 * 60 * 60) / 3600) * 3600) / 60) * 60)))
         || ' SECS '
            time_difference
    FROM v$log_history
   WHERE TRUNC (first_time) = TRUNC (SYSDATE) AND FLOOR ( ( (SYSDATE - first_time) * 24 * 60 * 60) / 3600) / 4 <= 1
ORDER BY TO_CHAR (first_time, 'DD-MON-YYYY HH24');


  SELECT TO_CHAR (first_time, 'DD-MON-YYYY HH24'), COUNT (1)
    FROM v$log_history
   WHERE TRUNC (first_time) = TRUNC (SYSDATE) AND FLOOR ( ( (SYSDATE - first_time) * 24 * 60 * 60) / 3600) / 3 <= 1
GROUP BY TO_CHAR (first_time, 'DD-MON-YYYY HH24')
ORDER BY 1, 2;

  SELECT NVL (SUM (COUNT (1)), 0) APPLIED_COUNT
    FROM V$LOG_HISTORY
   WHERE TRUNC (FIRST_TIME) = TRUNC (SYSDATE) AND FLOOR ( ( (SYSDATE - FIRST_TIME) * 24 * 60 * 60) / 3600) / 3 <= 1
GROUP BY FLOOR ( ( (SYSDATE - FIRST_TIME) * 24 * 60 * 60) / 3600);


  SELECT ( (FIRST_TIME - 30 / 24 / 60) - 2 / 24), A.*
    FROM V$LOG_HISTORY A
ORDER BY FIRST_TIME DESC;

SELECT NVL (SUM (COUNT (1)), 0) APPLIED_COUNT FROM V$LOG_HISTORY
WHERE TRUNC ( ( (FIRST_TIME - 30 / 24 / 60) - 2 / 24)) = TRUNC (SYSDATE) 
AND CEIL ( ( (SYSDATE - ( (FIRST_TIME - 30 / 24 / 60) - 2 / 24)) * 24 * 60 * 60) / 3600) / 4 <= 1
GROUP BY FLOOR ( ( (SYSDATE - ( (FIRST_TIME - 30 / 24 / 60) - 2 / 24)) * 24 * 60 * 60) / 3600);