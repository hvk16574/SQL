SET DEFINE OFF;
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR Move Order Details');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Create Accounting');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG HR Employee Absence Reporting to CEO1');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QC PTO Carryover');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Remove obsolete sessions from fnd_sessions');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG HR OS Head Count Report');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR Crew Carry Over');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QC Staff Movement Report');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG Estaff DSD Element Entry Creation');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG HR Bond Element Entry Creation Program');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG HR ExitPermit Staff Notify Program');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_CHEQUE_CLEARANCE_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR_LEAVE_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('OTA_ALERT_RESOURCE_CANCELLATION (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('OTA_MARKS_SEP_CABIN (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_SUPP_BG_EXP_15 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAS_SUPP_BG_EXP_60 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_PROJ_INS_30 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR_EXIT_PERMIT_CASHIER_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_PROJ_ED_30 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAS_SUPP_CONT_15 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_JOINING_ADVANCE_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_ABSENCE_DET_LOOKUP (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG HR Emp Absence Report Send to CEO (G_8 above)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Process transaction interface');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR UMS Unassigned Department and Position Groups');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR Min-Max Analysis / Re-order Report By Category');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QStyle Outstations - Update Employees Uniform Group');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QF PTO Carryover');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAS Occupancy and Vacancy Summary');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR AP Invoice Approval Reminder Notification to Approver');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR UMS Entitlement Change Updation');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR Move Order Transaction Notification');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QC HR Head Count Report (Ver 1.0)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG Replaced Appr SRF- LM has to initiate sourcing (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_ABSCOND_STAFF_ALT (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR_DUTY_TRAVEL_IT_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Recurring Journal Entry');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_HR_TRAINING_BOND_ASSIGN (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_INVOICE_APPROVAL (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_PROJ_IND_15 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_PROJ_INS_15 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_PROJ_ED_15 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_HR_SCH_CHK_PROGRAM (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QF_DUTY_TRAVEL_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_CONC_SCHD_CHK (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Purge Logs and Closed System Alerts');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Workflow Background Process');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA Receipt Rejection Notification');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Pay On Receipt AutoInvoice');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Cost Manager');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG Estaff Travel DSD Program');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_HR_SEPARATIONS_NOTIFICATION');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG SRF - Update SRF status from GEMS Interface');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QC List of Deductions Report');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QStyle Outstations - Update Entitlement Period');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QStyle Inventory Planning Items below Safety Stock Report');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG HR TBS Contact Update Interface');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QS_LEAVE_ADMIN_NOTI_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QD_LEAVE_ADMIN_NOTI_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG HR Medical New Joiners -Grade 8 and above (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR HR Cabin Crew Exit Permit Alert (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('OTA_ALERT_RESOURCE_BOOKINGS (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_SUPP_BG_EXP_60 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAS_SUPP_CONT_60 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_SUPP_CONT_30 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_PROJ_WMC_15 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Mass Additions Create');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_EGATE_EXPIRY_DATE_ALT (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAS_SUPP_BG_EXP_30 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QC_LEAVE_ADMIN_NOTI_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAS_SUPP_BG_EXP_15 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_PROJ_RR_15 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QS_CUST_SER_LEAVE_ADMIN_NOTI_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR Uniform Update Employees Uniform Group');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QStyle Outstations - Create or Assign Entitlement Group Notification');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA Receipt Accepted Notification');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR GSIA Status Report');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG Exit Permit Mail Send Program');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG HR GEMS Leave Details Interface');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR Uniform Inventory Update Program');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA Project Alerts Program');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Purge Concurrent Request and/or Manager Data');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR_PRINT_EXIT_PERMIT_SIT_IN_ADV (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAS_CUST_BG_EXP_15 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR_ENG_DUTY_TRAVEL_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR_DUTY_TRAVEL_L&D_DEPT (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_PENDING_CHQ_CLEARENCE_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QStyle Outstations - Consolidated Uniform Request Details Report');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QStyle Internal Replenishment - Move Order Request Set (Report Set)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QStyle Inventory Planning Consumption Variance Report');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG HR LDAP Email Update Interface');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG HR Non Rec Element Set Creation');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAS Supplier Payment Advice Notification');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR AP Invoice Approval Reminder Notification to Senior Managers');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR Uniform Entitlement Renewal Program');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR Move Order Allocation Program');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QStyle Outstations - Send Uniform Dispatch Details');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Workflow Control Queue Cleanup');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QS_CARGO_SER_LEAVE_ADMIN_NOTI_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR_DUTY_TRAVEL_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR_LEAVE_NULL_SUPERVISOR_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_PROJ_TPL_30 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_UMS_UPLOAD_ERR_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_PROJ_TPL_15 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_SUPP_CONT_60 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('OAM Applications Dashboard Collection');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QS_LEAVE_SALARY_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_EN_ANNUAL_LEAVE_DET (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_LEGAL_CLEARANCE_P (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG SRF Sourcing Initiated by LM (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Security List Maintenance');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR Move Order Approval Notification program');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR AP Invoice Approval Pending Notification to Management');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QStyle Inventory Planning Upload MIN MAX Setup Values program');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR Items Not Used details');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA Receipt Receiving Notification');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA Supplier Payment Advice Notification');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG Salary Advance Element Creation');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR AP Invoice Approval Action Notification to Approver (XML)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR PTO Carryover');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_QACC_ABSCOND_STAFF_ALT (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_Telephone_Issue_Alert (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_DSD_ERRORS_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Periodic Alert Scheduler');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAS_CUST_BG_EXP_60 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAS_CUST_BG_EXP_30 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_PROJ_BG_15 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR_EXIT_CASHIER_WITH_ABS_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_PROJ_WMC_30 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_REPAT_CARGO_REQUEST_PA (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_FINANCE_PERIOD_STATUS (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR Invoice on Hold Report (Excel)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Details - Pending Approved Requisitions In Auto Create');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR HR AIMS Cabin Crew Leave Update Interface - Daily');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG HR Sma Srf Status Update Program');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QStyle Inventory Planning New Joiner Variance');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QC Leave Report');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QR UMS Transfer Returns To Staging');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG HR eStaff Travel Dependent PP Update Interface');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG SRF Update Positions for Approved SRF');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_SUPP_BG_EXP_30 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('OTA_MARKS_GENERAL (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_PROJ_BG_30 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_PROJ_IND_30 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_PROJ_RR_30 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG Customer Statement Mail Program');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG SRF Create IVN/XVN Number');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QStyle Inventory Planning New Joiner Forecast from SRF Request Set (Report Set)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DI PTO Carryover');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG UMS Element Entry Creation');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QStyle Inventory Planning Items below Min Stock Report');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG HR GEMS Career Path Interface');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QD PTO Carryover');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QS PTO Carryover');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QStyle Internal Replenishment - Close Move Order');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QStyle Statistics');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Workflow Mailer Statistics Concurrent Program');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG HR GEMS Leave Entitlement Interface');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_EOSB_PAYMENTS_APPROVAL (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Purge Signon Audit data');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('DIA_SUPP_CONT_15 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('Gather Schema Statistics');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAS_SUPP_CONT_30 (Check Periodic Alert)');
Insert into APPS.DISABLE_CP
   (USER_CONCURRENT_PROGRAM_NAME)
 Values
   ('QAG_LEAVE_SALARY_ADVANCE_PA (Check Periodic Alert)');
COMMIT;
