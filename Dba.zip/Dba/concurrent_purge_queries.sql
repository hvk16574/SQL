select count(1)/500 from FND_CONCURRENT_REQUESTS;
select count(1) from FND_RUN_REQUESTS;
select count(1) from FND_CONC_REQUEST_ARGUMENTS;
select count(1) from FND_DUAL;
select count(1) from FND_CONCURRENT_PROCESSES;
select count(1) from FND_CONC_STAT_LIST;
select count(1) from FND_CONC_STAT_SUMMARY;
select count(1) from FND_CONC_PP_ACTIONS;
select count(1) from FND_RUN_REQ_PP_ACTIONS;
select count(1) from FND_ENV_CONTEXT;



DELETE
FROM fnd_run_req_pp_actions fa
WHERE EXISTS
( SELECT 'x'
FROM fnd_concurrent_requests fcr
WHERE phase_code = 'C'
AND fa.parent_request_id= fcr.request_id
AND FCR.ACTUAL_COMPLETION_DATE < SYSDATE - 30 );

2- For Table (FND_CONC_PP_ACTIONS):

DELETE
FROM fnd_conc_pp_actions fca
WHERE EXISTS
( SELECT 'x'
FROM fnd_concurrent_requests fcr
where phase_code = 'C'
and fca.CONCURRENT_REQUEST_ID = fcr.request_id
AND FCR.ACTUAL_COMPLETION_DATE < SYSDATE - 30 );

We can use also fca.concurrent_request_id instead of fca.request_id.

3- For Table (FND_CONCURRENT_REQUESTS):

DELETE
FROM APPLSYS.FND_CONCURRENT_REQUESTS
WHERE PHASE_CODE <> 'P'
AND STATUS_CODE <> 'I'
AND ACTUAL_COMPLETION_DATE < SYSDATE - 30 ;

4- For Table (FND_CONCURRENT_PROCESSES):

TRUNCATE TABLE APPLSYS.FND_CONCURRENT_PROCESSES;