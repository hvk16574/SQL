DELETE FROM   hr_api_transaction_values
      WHERE   transaction_step_id IN
                    (SELECT   transaction_step_id
                       FROM   hr_api_transaction_steps
                      WHERE   transaction_id IN (SELECT   transaction_id
                                                   FROM   hr_api_transactions
                                                  WHERE   status = 'W'));


DELETE FROM   hr_api_transaction_steps
      WHERE   transaction_id IN (SELECT   transaction_id
                                   FROM   hr_api_transactions
                                  WHERE   status = 'W');

SELECT   transaction_id
  FROM   hr_api_transactions
 WHERE   status = 'W';