SELECT ffft.user_function_name "User Form Name",
       (SELECT application_name
          FROM fnd_application_tl fa
         WHERE fa.application_id = ff.application_id) application, ffcr.ID,
       ffcr.SEQUENCE, ffcr.function_name,
       REPLACE (ffcr.description, CHR (39), CHR (39) || CHR (39)) description,
       ffcr.enabled, ffcr.trigger_event, ffcr.trigger_object,
       REPLACE (REPLACE (ffcr.condition, CHR (10), CHR (32)),
                CHR (39),
                CHR (39) || CHR (39)
               ) condition,
       ffcr.fire_in_enter_query, ffcr.rule_key, ffcr.form_name,
       ffcr.rule_type, (SELECT user_name
                          FROM fnd_user fu
                         WHERE fu.user_id = ffcr.created_by) "Created By ", 
       ffcr.creation_date
  FROM apps.fnd_form_custom_rules ffcr,
       applsys.fnd_form ff,
       fnd_form_functions_vl ffft
 WHERE (ff.form_name) = (ffcr.form_name) AND ffcr.ID = ffft.function_id(+)
 ORDER BY ffcr.ID,ffcr.SEQUENCE,ffcr.creation_date;


SELECT *
  FROM fnd_form_custom_rules;

SELECT *
  FROM fnd_form_custom_actions;

SELECT *
  FROM fnd_form_custom_params;
SELECT *
  FROM fnd_form_custom_prop_list;
SELECT *
  FROM fnd_form_custom_prop_values;

SELECT *
  FROM fnd_form_custom_scopes;
  
SELECT *
  FROM fnd_oam_context_custom;